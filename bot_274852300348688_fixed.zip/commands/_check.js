/**#command
name: /check
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🚀 MANUAL PAYMENT VERIFY TRIGGER COMMAND
// COMMAND: /check
// =========================================================

try {
  var order_id = params ? params.trim() : "";

  // If the params are not found directly, extract them from the callback_query data
  if (!order_id && request && request.callback_query) {
    var cbData = request.callback_query.data;
    order_id = cbData.replace("/check", "").replace("check", "").trim().split(" ")[0];
  }

  if (!order_id) {
    var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
    if (queryId) {
      Api.answerCallbackQuery({
        callback_query_id: queryId,
        text: "❌ Invalid or Missing Order ID!",
        show_alert: true
      });
    } else {
      Bot.sendMessage(
        "<blockquote><tg-emoji emoji-id='5875506366050734240'>➡️</tg-emoji> <b>Invalid or Missing Order ID!</b> Please try initiating the payment again.</blockquote>", 
        { parse_mode: "HTML" }
      );
    }
    return;
  }

  // Gateway API Details
  var api_key = "FAM_516d57f1c24c296c1d9538300cde92c21949681ac7bc5461"; 
  var uniqueTime = new Date().getTime(); // Anti-cache parameter

  HTTP.get({
    url: "https://fampay.anujbots.xyz/verify.php?order_id=" + encodeURIComponent(order_id) + "&api_key=" + api_key + "&cb=" + uniqueTime,
    success: "/onCheck"
  });

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}