/**#command
name: /addstock_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  // If the message is empty
  if (!message) {
    Bot.sendMessage("❌ Format: <code>/addstock_id category_name email|password</code>", {parse_mode: "HTML"});
    return;
  }

  // Split the full text line by line (for bulk upload support)
  var lines = message.split("\n");
  var categories = Bot.getProperty("ff_categories") || {};
  
  var pendingStock = {}; 
  var totalAdded = 0;
  var reportMessage = "⚡ <b>Stock Loaded Successfully!</b>\n\n";

  for (var i = 0; i < lines.length; i++) {
    var currentLine = lines[i].trim();
    if (!currentLine) continue;

    // Remove the command if it is on the first line
    if (currentLine.toLowerCase().indexOf("/addstock_id") === 0) {
      currentLine = currentLine.substring(12).trim(); // the length of "/addstock_id" is 12
    }
    
    if (!currentLine) continue;

    // Find the space between the category and the account data
    var spaceIndex = currentLine.indexOf(" ");
    if (spaceIndex === -1) continue;

    var alias = currentLine.substring(0, spaceIndex).toLowerCase().trim(); 
    var credential = currentLine.substring(spaceIndex + 1).trim(); // email|pass

    // If the credential has no "|", skip the line (valid format check)
    if (credential.indexOf("|") === -1) continue;

    var finalSlug = "";

    // 1. Exact Category Slug Check
    if (categories[alias]) {
      finalSlug = alias;
    } else {
      // 2. Contains Slug Check or Name Match (for example 'lodu' or 'fb')
      for (var key in categories) {
        var cleanKey = key.toLowerCase();
        var catName = categories[key].name ? categories[key].name.toLowerCase() : "";
        
        if (cleanKey.indexOf(alias) !== -1 || alias.indexOf(cleanKey) !== -1 ||
            catName.indexOf(alias) !== -1 || alias.indexOf(catName) !== -1) {
          finalSlug = key;
          break;
        }
      }
    }

    // Queue data if category found
    if (finalSlug !== "") {
      if (!pendingStock[finalSlug]) {
        pendingStock[finalSlug] = [];
      }
      pendingStock[finalSlug].push(credential);
      totalAdded++;
    }
  }

  // Save to the database
  if (totalAdded > 0) {
    for (var slug in pendingStock) {
      var currentStock = Bot.getProperty("ff_stock_" + slug) || [];
      if (!Array.isArray(currentStock)) currentStock = [];

      var newAccounts = pendingStock[slug];
      for (var j = 0; j < newAccounts.length; j++) {
        currentStock.push(newAccounts[j]);
      }

      Bot.setProperty("ff_stock_" + slug, currentStock, "json");

      var catName = categories[slug] && categories[slug].name ? categories[slug].name : slug.toUpperCase();
      reportMessage += "• <code>" + newAccounts.length + " accounts</code> ➔ <b>" + catName + "</b>\n";
    }

    Bot.sendMessage(reportMessage, {parse_mode: "HTML"});
  } else {
    Bot.sendMessage("❌ <b>Stock Not Added!</b>\n\nWhy not?\n1. <code>LODU</code> category has not been created in the system.\n2. You did not put <code>|</code> between the category and the account data.\n\n<b>Correct Format:</b>\n<code>/addstock_id lodu jajaj@gmail.com|Sam72@</code>", {parse_mode: "HTML"});
  }

} catch(e) {
  Bot.sendMessage("Error: " + e.message);
}