/**#command
name: /profile
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 👤 COMMAND = /profile  (Premium Profile — Step 1: fetch user's DP)
// ✅ BUG FIX: previously a separate "Loading your premium profile..." message
// was sent and its ID was saved to delete later — but
// the ID capture did not reliably pass through the chained HTTP.get callback, so
// the "Loading..." message always stayed stuck
// Fix: now no separate loading message is sent — directly
// the DP is fetched and the final profile appears right away (the delay is so short that
// no loading indicator is needed).
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;

  // ✅ Clean up the old menu message (if it came from a button click)
  if (request && request.message && request.message.message_id) {
    try { Api.deleteMessage({ chat_id: chatId, message_id: request.message.message_id }); } catch (e) {}
  }

  // 📸 Fetch the user's Telegram DP — the response will arrive asynchronously at /onProfilePhoto
  HTTP.get({
    url: "https://api.telegram.org/bot" + bot.token + "/getUserProfilePhotos?user_id=" + userId + "&limit=1",
    success: "/onProfilePhoto",
    error: "/onProfilePhoto"
  });

} catch (err) {
  Bot.sendMessage("⚠️ Profile Error: " + err.message, { parse_mode: "HTML" });
}