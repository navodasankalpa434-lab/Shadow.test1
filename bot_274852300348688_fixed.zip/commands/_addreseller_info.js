/**#command
name: /addreseller_info
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 👑 Admin panel button — shows usage instructions for /addreseller
// (a real Telegram command needs to be typed since it takes a User ID param)
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "8500341403";
  var isCoAdmin = isCoAdminId(String(chat.chatid));
  if (String(chat.chatid) !== ownerId) { return; } // only the owner can add resellers

  Bot.sendMessage(
    "<blockquote>👑 <b>DIRECT RESELLER (No Payment)</b></blockquote>\n\n" +
    "<b>Usage:</b> <code>/addreseller USERID</code>\n" +
    "<i>Example:</i> <code>/addreseller 123456789</code>\n\n" +
    "<i>The user becomes a permanent Reseller immediately, with no payment required. They will also receive a premium notification.</i>",
    { parse_mode: "HTML" }
  );
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}