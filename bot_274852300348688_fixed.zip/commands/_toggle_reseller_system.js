/**#command
name: /toggle_reseller_system
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 👑 ADMIN/CO-ADMIN — Enable/Disable Reseller Upgrade System
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "8500341403";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = isCoAdminId(currentChatId);

  if (currentChatId !== ownerId && !isCoAdmin) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  var current = Bot.getProperty("reseller_system_enabled") || false;
  var newState = !current;
  Bot.setProperty("reseller_system_enabled", newState, "boolean");

  var price = Bot.getProperty("reseller_upgrade_price");

  if (newState) {
    Bot.sendMessage(
      "<blockquote>👑 <b>RESELLER SYSTEM ENABLED</b></blockquote>\n\n" +
      (price
        ? "<i>Users will now see the 'Reseller Upgrade' button in the menu — Price: LKR " + price + "</i>"
        : "<tg-emoji emoji-id='6100657257605763582'>⚠️</tg-emoji> <i>The price is not set yet! First use <code>/set_reseller_price AMOUNT</code>.</i>"),
      { parse_mode: "HTML" }
    );
  } else {
    Bot.sendMessage("<blockquote>❌ <b>RESELLER SYSTEM DISABLED</b></blockquote>\n\n<i>The Reseller Upgrade button is no longer shown to anyonehega.</i>", { parse_mode: "HTML" });
  }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}