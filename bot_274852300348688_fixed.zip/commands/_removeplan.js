/**#command
name: /removeplan
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  // Enter your Admin Telegram ID here
  var adminId = "8500341403";

  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  // Format validation verification
  if (!params) {
    Bot.sendMessage("⚠️ Format: `/removeplan PRODUCT NAME | DAYS`\n\n*Example:* `/removeplan FreeFire Hack | 1`", { parse_mode: "Markdown" });
    return;
  }

  var data = params.split("|");
  if (data.length < 2) {
    Bot.sendMessage("⚠️ Wrong format! Product Name and Days must be separated by '|'.");
    return;
  }

  var pName = data[0].trim().toLowerCase();
  var pDays = data[1].trim();

  // Get the list of existing products from the database
  var productList = Bot.getProperty("stored_products") || [];
  var productIndex = -1;

  // 1. First find the product
  for (var i = 0; i < productList.length; i++) {
    if (productList[i].name.toLowerCase() === pName) {
      productIndex = i;
      break;
    }
  }

  if (productIndex === -1) {
    Bot.sendMessage("❌ Product **" + data[0].trim() + "** was not found in the database!", { parse_mode: "Markdown" });
    return;
  }

  var product = productList[productIndex];
  var plans = product.plans || [];
  var planIndex = -1;

  // 2. Find the targeted plan inside that product
  for (var j = 0; j < plans.length; j++) {
    if (String(plans[j].days) === pDays) {
      planIndex = j;
      break;
    }
  }

  if (planIndex === -1) {
    Bot.sendMessage("❌ No plan with **" + pDays + " Days** was found in the product!", { parse_mode: "Markdown" });
    return;
  }

  // 3. Remove (delete) the plan from the array
  plans.splice(planIndex, 1);

  var feedbackMsg = "";
  
  // 4. Verification check: if all plans have been deleted, remove the product too
  if (plans.length === 0) {
    productList.splice(productIndex, 1);
    feedbackMsg = "🗑️ Product **" + product.name + "** was the last plan, so the whole product was removed from the list!";
  } else {
    productList[productIndex].plans = plans;
    feedbackMsg = "✅ Product **" + product.name + "**: the **" + pDays + " Days** plan was successfully removed!";
  }

  // 5. Save the updated list to the database
  Bot.setProperty("stored_products", productList, "json");
  Bot.sendMessage(feedbackMsg, { parse_mode: "Markdown" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}