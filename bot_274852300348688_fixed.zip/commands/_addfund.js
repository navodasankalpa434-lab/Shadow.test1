/**#command
name: /addfund
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}


// Manual Add Top Up: shows bank and cash details. The customer then sends the receipt
// (handled in _start.js). No automatic QR or Telegram Stars payment.
try {
  var bName = String(Bot.getProperty("topup_bank_name") || "Not set yet");
  var bAcc = String(Bot.getProperty("topup_bank_acc") || "Not set yet");
  var bHolder = String(Bot.getProperty("topup_bank_holder") || "Not set yet");
  var ezPhone = String(Bot.getProperty("topup_ezcash") || "Not set yet");
  var topChat = String(chat.chatid);

  User.setProperty("topup_step", "waiting_receipt", "string");
  User.setProperty("topup_file", "", "string");

  Api.sendMessage({
    chat_id: topChat,
    text: "<blockquote><b>💳 ADD TOP UP</b></blockquote>\n\n" +
          "<b>🏦 Bank Transfer</b>\n" +
          "Bank: <code>" + bName + "</code>\n" +
          "Account No: <code>" + bAcc + "</code>\n" +
          "Account Name: <code>" + bHolder + "</code>\n\n" +
          "<b>📱 EZ Cash</b>\n" +
          "Number: <code>" + ezPhone + "</code>\n\n" +
          "<b>After you pay, send:</b>\n" +
          "1️⃣ Your <b>receipt photo</b>\n" +
          "2️⃣ The <b>reference number</b> and <b>amount</b>\n\n" +
          "<i>Example: REF12345 | 500</i>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: [[{ text: "Back", callback_data: "/back", style: "primary" }, { text: "Cancel", callback_data: "/topup_cancel", style: "danger" }]]
    })
  });
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}