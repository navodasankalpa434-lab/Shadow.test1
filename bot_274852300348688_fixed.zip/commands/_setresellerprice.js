/**#command
name: /setresellerprice
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Update a plan's price inside the product list (used by the price-change commands)
function updatePlanPrice(prodName, planName, kind, price) {
  var list = Bot.getProperty("stored_products") || [];
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  if (!Array.isArray(list)) { return false; }
  var pn = String(prodName).trim().toLowerCase();
  var plainPlan = String(planName).trim().toLowerCase();
  var plannum = String(planName).replace(/[^0-9.]/g, "");
  for (var i = 0; i < list.length; i++) {
    if (!list[i] || String(list[i].name).trim().toLowerCase() !== pn) { continue; }
    var plans = Array.isArray(list[i].plans) ? list[i].plans : [];
    for (var j = 0; j < plans.length; j++) {
      var pl = plans[j];
      var label = String(pl.durationDisplay || "").trim().toLowerCase();
      var days = String(pl.days).replace(/[^0-9.]/g, "");
      if (label === plainPlan || (plannum !== "" && days === plannum)) {
        if (kind === "normal") { pl.normal_price = Number(price); } else { pl.reseller_price = Number(price); }
        Bot.setProperty("stored_products", list, "json");
        return true;
      }
    }
  }
  return false;
}

// =========================================================
// 💰 COMMAND = /setresellerprice
// STATUS: 100% ACCURATE KEY MATCHING FIX
// =========================================================

var input = message.replace("/setresellerprice", "").trim(); 
var parts = input.split("|");

if (parts.length === 3) {
  // 1️⃣ PRODUCT NAME: UpperCase + Trim (as in the buyitem script)
  var pName = parts[0].trim().toUpperCase(); 
  
  // 2️⃣ PLAN DAYS: only take the number (from "7_Day" or "7 Days", keep "7")
  var pPlan = String(parts[1]).replace(/[^0-9]/g, "").trim(); 
  
  // 3️⃣ PRICE: Force Floating/Integer Number parsing
  var pPrice = parseFloat(parts[2].trim());

  if (isNaN(pPrice)) {
    Bot.sendMessage("❌ The price must be a number!");
    return;
  }

  if (!updatePlanPrice(pName, pPlan, "reseller", pPrice)) {
    Bot.sendMessage("❌ Plan not found. Use the product name and the plan label exactly, for example: <code>Shadow 1 Day 400</code>");
    return;
  }
  // 🔥 MAIN MATCHING KEY FIX: direct buyitem loop database properties alignment
  var targetDatabaseKey = "price_reseller_" + pName + "_" + pPlan;

  // Save it as a real number so the math response is exact
  Bot.setProperty(targetDatabaseKey, pPrice, "number");
  
  Bot.sendMessage("✅ <b>Reseller Price Updated Successfully!</b>\n\n" +
                  "📦 <b>Product:</b> <code>" + pName + "</code>\n" +
                  "⏱️ <b>Plan:</b> <code>" + pPlan + " Days</code>\n" +
                  "💵 <b>New Price:</b> LKR " + pPrice, { parse_mode: "HTML" });

} else {
  Bot.sendMessage("⚠️ <b>Wrong Format!</b>\n\n" +
                  "📝 <b>Format:</b>\n<code>/setresellerprice PRODUCT NAME | DAYS | PRICE</code>\n\n" +
                  "💡 <b>Example:</b>\n<code>/setresellerprice PRIME HOOK | 7 | 64</code>", { parse_mode: "HTML" });
}