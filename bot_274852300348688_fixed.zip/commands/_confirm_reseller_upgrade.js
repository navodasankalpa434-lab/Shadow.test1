/**#command
name: /confirm_reseller_upgrade
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 👑 Reseller Upgrade — Confirm button handler
// Balance sufficient -> instant upgrade. Insufficient -> shortfall QR
// (payment completion handled automatically in _onCheck.js).
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;

  if (Bot.getProperty("is_reseller_" + userId)) {
    Bot.sendMessage("💎 You are already a Reseller!");
    return;
  }

  var price = Number(Bot.getProperty("reseller_upgrade_price") || 0);
  if (!price) {
    Bot.sendMessage("❌ The admin has not set the Reseller Upgrade price yet.");
    return;
  }

  var unifiedBal = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return resBal + bonusBal;
  })();

  function grantReseller(chatIdTarget) {
    Bot.setProperty("is_reseller_" + userId, true, "boolean");
    var congratsText =
      "<blockquote><tg-emoji emoji-id='6102856637343600044'>🎉</tg-emoji> <b>CONGRATULATIONS!</b></blockquote>\n\n" +
      "<tg-emoji emoji-id='6215386799133433653'>👑</tg-emoji> <b>You are now a Reseller!</b>\n\n" +
      "<i>You now get reseller pricing on every product and plan, priority processing, and access to reseller-only stock. Enjoy your upgraded status!</i>";
    Api.sendMessage({
      chat_id: chatIdTarget,
      text: congratsText,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "Explore Shop", callback_data: "/buy_hack", style: "success", icon_custom_emoji_id: "5866053971960929280" }]] })
    });

    var ownerId = Bot.getProperty("owner_id") || "8500341403";
    try {
      Api.sendMessage({
        chat_id: ownerId,
        text: "👑 <b>NEW RESELLER!</b>\n👤 <b>User:</b> <code>" + userId + "</code>\n💰 <b>Paid:</b> LKR " + price.toFixed(2),
        parse_mode: "HTML"
      });
    } catch (e) {}
  }

  if (unifiedBal >= price) {
    try { Libs.ResourcesLib.userRes("balance").add(-price); } catch (e) {}
    grantReseller(chatId);
  } else {
    var needToPay = price - unifiedBal;
    User.setProperty("buy_reseller_upgrade", true, "boolean");
    User.setProperty("buy_reseller_price", price, "number");

    var genText = "<tg-emoji emoji-id='6100657257605763582'>⏳</tg-emoji> <b>Creating order for LKR " + needToPay.toFixed(2) + ", please wait...</b>";
    if (request && request.message) {
      Api.editMessageText({ chat_id: String(chatId), message_id: Number(request.message.message_id), text: genText, parse_mode: "HTML" });
      try {
        Bot.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
        User.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
      } catch (e) {}
    } else {
      var genMsg = Api.sendMessage({ chat_id: chatId, text: genText, parse_mode: "HTML" });
      try {
        var gmid = (genMsg && genMsg.result && genMsg.result.message_id) ? genMsg.result.message_id : (genMsg && genMsg.message_id ? genMsg.message_id : null);
        if (gmid) {
          Bot.setProperty("gen_msg_id_" + userId, gmid, "string");
          User.setProperty("gen_msg_id_" + userId, gmid, "string");
        }
      } catch (e) {}
    }

    Api.sendMessage({ chat_id: userId, text: "❌ Insufficient wallet balance. Please ask the admin to add funds.", parse_mode: "HTML" }); return;
    var upi_id = "suraj12347singha@fam";
    HTTP.get({
      url: "https://fampay.anujbots.xyz/qr.php?upi=" + encodeURIComponent(upi_id) + "&amount=" + encodeURIComponent(needToPay.toFixed(2)),
      success: "/onQR",
      error: "/onApiError"
    });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}