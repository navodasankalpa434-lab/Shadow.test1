/**#command
name: /menu
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

var SHOP_NAME = String(Bot.getProperty("store_name") || "Shadow and Scrapy Panel Store").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var userId = user.telegramid;

  // ✅ VERIFICATION CHECK
  var isVerified = (Bot.getProperty("verified_" + userId) === true) || (User.getProperty("verified_" + userId) === true);

  if (!isVerified) {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "<blockquote><b>🔰 Please verify your account first.</b>\nUse /start</blockquote>",
      parse_mode: "HTML"
    });
    return;
  }

  // 📊 REAL BALANCE FETCH — ✅ FIXED: now reads from the same wallet store that purchase flows use
  // (Libs.ResourcesLib "balance" resource + admin bonus balance), so the balance looks the same everywhere.
  var userBal = (function() {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return (resBal + bonusBal).toFixed(2);
  })();

  var welcomeMessage =
    "<tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <b>— " + SHOP_NAME + " —</b> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji>\n\n" +
    "<tg-emoji emoji-id=\"6080228009439141516\">💧</tg-emoji> <b>Genuine, limited-stock Free Fire panels. Instant delivery.</b>\n\n" +
    "<tg-emoji emoji-id='5231200819986047254'>💰</tg-emoji> <b>Balance:</b> LKR " + userBal + "\n\n" +
    "<i>Tap any button below to begin:</i> <tg-emoji emoji-id='6057415823222379852'>👇</tg-emoji>";

  var multiColorKeyboard = [
    [{ text: "Shop Now", callback_data: "/buy_hack", style: "primary", icon_custom_emoji_id: "5866053971960929280" }],
    [
      { text: "Profile", callback_data: "/profile", style: "primary", icon_custom_emoji_id: "5260399854500191689" },
      { text: "Add Top Up", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "6147815702163102310" }
    ],
    [
      { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6113743082358841933" },
      { text: "How to use", callback_data: "/how", style: "danger", icon_custom_emoji_id: "6080214566191505147" }
    ],
    [{ text: "Payment Proofs", url: "https://chat.whatsapp.com/JR898GeUCjiKPXF25jDW2D?s=cl&p=a&mlu=4&ilr=4", style: "success", icon_custom_emoji_id: "5330237710655306682" }],
    [{ text: "Support", callback_data: "/support", style: "danger", icon_custom_emoji_id: "5436113877181941026" }]
  ];

  if (Bot.getProperty("reseller_system_enabled") && !Bot.getProperty("is_reseller_" + userId)) {
    multiColorKeyboard.push([
      { text: "Reseller Upgrade", callback_data: "/reseller_upgrade", style: "success", icon_custom_emoji_id: "6102856637343600044" }
    ]);
  }

  if (request && request.callback_query && request.callback_query.id) {
    try { Api.answerCallbackQuery({ callback_query_id: request.callback_query.id }); } catch(qErr){}
    Api.editMessageText({
      chat_id: chat.chatid,
      message_id: request.callback_query.message.message_id,
      text: welcomeMessage,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
    });
  } else {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: welcomeMessage,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
    });
  }

} catch (globalException) {
  Bot.sendMessage("🛑 <b>Menu Debug Error:</b> <code>" + globalException.message + "</code>", { parse_mode: "HTML" });
}