/**#command
name: /addcat_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (!chat || String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  // 🛡️ CRASH FIX: first check that the message is not null
  if (!message) {
    Bot.sendMessage("✍️ <b>Please type the category details and send them!</b>\n\n<b>Correct Format:</b>\n<code>/addcat_id [Emoji_ID] [Category Name]</code>\n\n<b>Example:</b>\n<code>/addcat_id 5323261730283863478 Facebook Id</code>", {parse_mode: "HTML"});
    return;
  }

  var cleanMessage = message.trim();

  // Command string removal
  if (cleanMessage.indexOf("/addcat_id") === 0) {
    cleanMessage = cleanMessage.replace("/addcat_id", "").trim();
  }

  var parts = cleanMessage.split(" ");
  if (parts.length < 2 || !parts[0] || isNaN(parts[0].substring(0, 3))) {
    Bot.sendMessage("⚠️ <b>Wrong Format!</b>\n\n<b>Correct Format:</b>\n<code>[Emoji_ID] [Category Name]</code>\n\n<b>Example:</b>\n<code>5323261730283863478 Facebook Id</code>", {parse_mode: "HTML"});
    return;
  }

  var emojiId = parts[0].trim();
  var catName = parts.slice(1).join(" ").trim();
  
  // Dynamic safe slug creation
  var catSlug = catName.toLowerCase().replace(/[^a-z0-9]/g, "");

  var categories = Bot.getProperty("ff_categories");
  if (!categories || typeof categories !== "object") {
    categories = {};
  }

  // FIXED: The emoji_id property is saved here, synced with the menu script
  categories[catSlug] = {
    name: catName,
    emoji_id: emojiId, 
    normal_price: 0,
    reseller_price: 0
  };

  Bot.setProperty("ff_categories", categories, "json");
  Bot.setProperty("ff_stock_" + catSlug, [], "json");

  Bot.sendMessage("✅ <b>Category Successfully Added!</b>\n\n• <b>Icon:</b> <tg-emoji emoji-id='" + emojiId + "'>✨</tg-emoji>\n• <b>Name:</b> <code>" + catName + "</code>\n• <b>Emoji ID:</b> <code>" + emojiId + "</code>\n• <b>System Slug:</b> <code>" + catSlug + "</code>\n\n<i>Your FF ID menu will now work perfectly!</i>", {parse_mode: "HTML"});

} catch(e) {
  Bot.sendMessage("Error in Add Category: " + e.message);
}