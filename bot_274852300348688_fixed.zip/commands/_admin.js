/**#command
name: /admin
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403"; // Your Admin ID
  
  var currentChatId = (typeof chat !== 'undefined' && chat && chat.chatid) ? String(chat.chatid) : ((typeof user !== 'undefined' && user && user.telegramid) ? String(user.telegramid) : null);
  var isCoAdmin = currentChatId && isCoAdminId(currentChatId);
  if (currentChatId !== adminId && !isCoAdmin) {
    Bot.sendMessage("❌ Restricted command! Only the owner and co-admins can open this.");
    return;
  }

  // Live Database Metrics Extraction
  var userList = Bot.getProperty("all_users_list") || [];
  var totalUsers = userList.length;
  var currentResellerPrice = Bot.getProperty("reseller_upgrade_price") || "Not Set";

  // 📝 PREMIUM ADMINISTRATIVE MASTER INTERFACE
  var adminPanelText = 
    "<blockquote><b><tg-emoji emoji-id='6064138396228392033'>👑</tg-emoji> MASTER ADMINISTRATIVE PANEL</b>\n\n" +
    "<i>Welcome back Boss! Securely manage your store microservices, logs, databases, plans, and inventory control nodes below.</i></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "<blockquote><b><tg-emoji emoji-id='6039605143601680423'>📊</tg-emoji> BOT INFRASTRUCTURE SUMMARY</b>\n\n" +
    "• <b>Total Registered Users:</b> <code>" + totalUsers + " Users</code>\n" +
    "• <b>Reseller Upgrade Price:</b> <code>LKR " + currentResellerPrice + "</code></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji> <b>Select an operational control terminal module:</b>";

  // 🎨 ADVANCED SYSTEM CUSTOM-EMOJI INFRASTRUCTURE
  var adminKeyboard = [
    // Row 1: Product Structure (Success vs Danger Vector)
    [
      { text: "Add Product", callback_data: "/addproduct", style: "success", icon_custom_emoji_id: "5348392971207194994" },
      { text: "Remove Product", callback_data: "/removeproduct", style: "danger", icon_custom_emoji_id: "6143299028655280273" }
    ],
    // Row 2: Plan / Validity Variants
    [
      { text: "Add Plan", callback_data: "/addplan", style: "primary", icon_custom_emoji_id: "6194922667242429131" },
      { text: "Remove Plan", callback_data: "/removeplan", style: "danger", icon_custom_emoji_id: "6143299028655280273" }
    ],
    // Row 3: License Key Inventory System
    [
      { text: "Add Key", callback_data: "/addkey", style: "success", icon_custom_emoji_id: "6195196054795721892" },
      { text: "Remove Key", callback_data: "/removekey", style: "danger", icon_custom_emoji_id: "6143299028655280273" }
    ],
    // Row 4: FF ID Category Configurations
    [
      { text: "Add Cat for ID", callback_data: "/addcat_id", style: "success", icon_custom_emoji_id: "5334890573281114250" },
      { text: "Rem Cat for ID", callback_data: "/remcat_id", style: "danger", icon_custom_emoji_id: "6143299028655280273" }
    ],
    // Row 5: FF ID Stock Controls
    [
      { text: "Add Stock ID", callback_data: "/addstock_id", style: "success", icon_custom_emoji_id: "6195196054795721892" },
      { text: "Remove Stock ID", callback_data: "/remstock_id", style: "danger", icon_custom_emoji_id: "6143299028655280273" }
    ],
    // Row 5b: Stock Monitoring & Clear Control (UPDATED)
    [
      { text: "Check ID Stock", callback_data: "/allstocks", style: "primary", icon_custom_emoji_id: "6039605143601680423" },
      { text: "Clear All ID Stock", callback_data: "/clearstock", style: "danger", icon_custom_emoji_id: "6143299028655280273" }
    ],
    // Row 6: ID Pricing Controls
    [
      { text: "Set Normal Price ID", callback_data: "/normalprice_id", style: "primary", icon_custom_emoji_id: "5778145208411624388" },
      { text: "Set Reseller Price ID", callback_data: "/resellerprice_id", style: "success", icon_custom_emoji_id: "6267068789146260253" }
    ],
    // Row 7: Pricing Matrix Configurations (Global Keys)
    [
      { text: "Set All Products Normal Price", callback_data: "/normalprice", style: "primary", icon_custom_emoji_id: "5778145208411624388" },
      { text: "Set All Products Reseller Price", callback_data: "/setresellerprice", style: "success", icon_custom_emoji_id: "6267068789146260253" }
    ],
    // Row 8: Financial Wallet Controls
    [
      { text: "Add Bal", callback_data: "/addbal", style: "success", icon_custom_emoji_id: "5778145208411624388" },
      { text: "Remove Bal", callback_data: "/rembal", style: "danger", icon_custom_emoji_id: "6143299028655280273" }
    ],
    // Row 8b: Owner-only reseller data
    [
      { text: "Resellers Data", callback_data: "/resellerdata", style: "primary", icon_custom_emoji_id: "6039605143601680423" }
    ],
    // Row 9: Reseller Authorization Cluster
    [
      { text: "Add Reseller", callback_data: "/addreseller", style: "success", icon_custom_emoji_id: "6195245116207143870" },
      { text: "Remove Reseller", callback_data: "/removereseller", style: "danger", icon_custom_emoji_id: "6143299028655280273" },
      { text: "View Role", callback_data: "/role", style: "primary", icon_custom_emoji_id: "6064138396228392033" }
    ],
    // Row 10: Global Parameters & Auditing Tools
    [
      { text: " Set Reseller Upgrade Fee", callback_data: "/setprice", style: "primary", icon_custom_emoji_id: "5463172695132745432" },
      { text: "All Keys", callback_data: "/allkey", style: "success", icon_custom_emoji_id: "6010210211334200822" },
      { text: "Total Users", callback_data: "/check_users", style: "primary", icon_custom_emoji_id: "6039605143601680423" }
    ],
    // Row 11: Core System Communications Hub
    [
      { text: "Broadcast System Terminal", callback_data: "/broadcast", style: "primary", icon_custom_emoji_id: "6041705726206808304" }
    ],
    // Row 12: 🎟 Coupon System (NEW)
    [
      { text: "Generate Coupon", callback_data: "/gencoupon", style: "success", icon_custom_emoji_id: "6093677128295914531" },
      { text: "View Coupons", callback_data: "/coupons", style: "primary", icon_custom_emoji_id: "6102818532393750087" }
    ],
    // Row 13: 👑 Ownership / Co-Admin Controls (NEW — Owner only, not Co-Admins)
    [
      { text: "Manage Co-Admins", callback_data: "/manage_coadmin", style: "primary", icon_custom_emoji_id: "6102856637343600044" },
      { text: "Transfer Ownership", callback_data: "/transfer_ownership", style: "danger", icon_custom_emoji_id: "6215386799133433653" }
    ],
    // Row 14: 🛠 Maintenance Mode
    [
      { text: "Maintenance Mode", callback_data: "/toggle_maintenance", style: "danger", icon_custom_emoji_id: "6100657257605763582" }
    ],
    // Row 15: 💎 Reseller System (NEW)
    [
      { text: "Toggle Reseller System", callback_data: "/toggle_reseller_system", style: "success", icon_custom_emoji_id: "6102856637343600044" },
      { text: "Set Reseller Price", callback_data: "/set_reseller_price", style: "primary", icon_custom_emoji_id: "6312263493051489212" }
    ],
    // Row 16: 👑 Direct Reseller (NEW) — admin types a User ID, no payment needed
    [
      { text: "Direct Reseller (by User ID)", callback_data: "/addreseller_info", style: "success", icon_custom_emoji_id: "6215386799133433653" }
    ],
    // Row 17: 💸 Auto-Discount System (NEW)
    [
      { text: "Set Product/Plan Discount", callback_data: "/set_discount", style: "primary", icon_custom_emoji_id: "6093677128295914531" }
    ]
  ];

  // 🤖 DISPATCH PIPELINE EXECUTION
  // Co-admins do not get the owner-only buttons (Manage Co-Admins, Transfer Ownership, Add/Direct Reseller)
  var OWNER_ONLY_CALLBACKS = ["/manage_coadmin", "/transfer_ownership", "/addreseller", "/addreseller_info", "/resellerdata"];
  var isOwnerRequest = (currentChatId === adminId);
  if (!isOwnerRequest) {
    adminKeyboard = adminKeyboard.map(function (row) {
      return row.filter(function (b) { return OWNER_ONLY_CALLBACKS.indexOf(b.callback_data) === -1; });
    }).filter(function (row) { return row.length > 0; });
  }

  // Send the panel to the person who asked for it (owner or co-admin)
  Api.sendMessage({
    chat_id: currentChatId || adminId,
    text: adminPanelText,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: adminKeyboard
    })
  });

} catch (err) {
  Bot.sendMessage("Admin Panel Premium Cluster Error: " + err.message);
}