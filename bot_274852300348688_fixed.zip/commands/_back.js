/**#command
name: /back
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Role: Admin, Reseller, Customer (unverified shows as Visitor)
function roleFor(id) {
  id = String(id);
  if (id === "8500341403") { return "🛡 Admin"; }
  var cl = Bot.getProperty("co_admin_list") || [];
  if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e) { cl = []; } }
  var isAdmin = String(Bot.getProperty("co_admin_" + id)) === "true" || (Array.isArray(cl) && cl.map(String).indexOf(id) !== -1);
  if (isAdmin) { return "🛡 Admin"; }
  var rl = Bot.getProperty("resellers_list") || [];
  if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e2) { rl = []; } }
  var isRes = String(Bot.getProperty("is_reseller_" + id)) === "true" ||
              (Array.isArray(rl) && rl.some(function (x) { return String(x && x.id !== undefined ? x.id : x) === id; }));
  if (isRes) { return "🔴 Reseller"; }
  var vv = Bot.getProperty("verified_" + id);
  if (!(vv === true || String(vv) === "true")) { return "👀 Visitor"; }
  return "✅ Customer";
}
// Rank: the best top-up tier the customer has reached
function rankFor(id) {
  var total = Number(Bot.getProperty("topup_total_" + id) || 0);
  var tiers = Bot.getProperty("topup_tiers") || [];
  if (typeof tiers === "string") { try { tiers = JSON.parse(tiers); } catch (e) { tiers = []; } }
  if (!Array.isArray(tiers)) { tiers = []; }
  var best = null;
  for (var t = 0; t < tiers.length; t++) {
    if (total >= Number(tiers[t].min) && (!best || Number(tiers[t].pct) > Number(best.pct))) { best = tiers[t]; }
  }
  return best ? (best.name + " · " + best.pct + "% off") : "None · 0% off";
}
// Menu header: role, verification and rank
function statusBlockFor() {
  var sid = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
  var vv = Bot.getProperty("verified_" + sid);
  var ver = (vv === true || String(vv) === "true") ? "✅ Verified account" : "🔴 Not verified (tap Verify Account)";
  return "<blockquote><b>" + roleFor(sid) + "</b>\n" + ver + "\n🏅 Rank: " + rankFor(sid) + "</blockquote>\n";
}
// Sends the menu with the banner photo when one is set (same as /start)
function sendMenuPhoto(opts) {
  var ph = String(Bot.getProperty("menu_photo_file_id") || Bot.getProperty("menu_photo_url") || "");
  var fits = String(opts.text).replace(/<[^>]+>/g, "").length <= 1000;
  if (ph.length > 0 && (ph.indexOf("http") === 0 || /^[A-Za-z0-9_\-]{20,}$/.test(ph)) && fits) {
    try { Api.sendPhoto({ chat_id: opts.chat_id, photo: ph, caption: opts.text, parse_mode: opts.parse_mode, reply_markup: opts.reply_markup }); return; } catch (e) {}
  }
  Api.sendMessage(opts);
}
// Status line shown at the top of the menu: role + verified / not verified
// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

var SHOP_NAME = String(Bot.getProperty("store_name") || "Shadow and Scrapy Panel Store").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 🚀 PREMIUM STORE MASTER DASHBOARD (UPDATED WITH LUDO SPIN)
// STATUS: 100% PRODUCTION READY WITH LIVE BUTTON STYLES
// =========================================================

try {
  var userId = user.telegramid;

  // 💾 BROADCAST SYSTEM: Safe Loop Core
  var userList = [];
  try {
    userList = Bot.getProperty("all_users_list") || [];
    if (!Array.isArray(userList)) { userList = []; }
  } catch (propErr) {
    userList = [];
  }

  var userExists = false;
  for (var i = 0; i < userList.length; i++) {
    if (String(userList[i]) === String(userId)) {
      userExists = true;
      break;
    }
  }
  if (!userExists) {
    userList.push(String(userId));
    Bot.setProperty("all_users_list", userList, "json");
  }

  // 📊 REAL BALANCE FETCH
  var userBal = "0.00";
  try {
    var res = 0;
    if (Libs && Libs.ResourcesLib) {
      res = Libs.ResourcesLib.userRes("balance").value() || 0;
    }
    var adminBal = Bot.getProperty("balance" + userId) || 0;
    userBal = (Number(res) + Number(adminBal)).toFixed(2);
  } catch (balErr) {
    var fallbackBal = Bot.getProperty("balance" + userId) || 0;
    userBal = Number(fallbackBal).toFixed(2);
  }

  // 💎 WELCOME MESSAGE EMOJIS (for the text message only)
  var EMJ_HEADER_ROCKET = "<tg-emoji emoji-id='5217822164362739968'>🚀</tg-emoji>";
  var EMJ_HEADER_NEW    = "<tg-emoji emoji-id='6194809138371904539'>✨</tg-emoji>"; 
  var EMJ_HEADER_SHIELD = "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji>";

  // Variables for all items in the welcome message:
  var MSG_EMJ_STORE     = "<tg-emoji emoji-id='5866053971960929280'>🛒</tg-emoji>";
  var MSG_EMJ_FFID      = "<tg-emoji emoji-id='5334890573281114250'>🎮</tg-emoji>"; 
  var MSG_EMJ_PROFILE   = "<tg-emoji emoji-id='5260399854500191689'>🔰</tg-emoji>";
  var MSG_EMJ_ADDBAL    = "<tg-emoji emoji-id='6147815702163102310'>✨</tg-emoji>";
  var MSG_EMJ_HISTORY   = "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji>";
  var MSG_EMJ_LUDO      = "<tg-emoji emoji-id='5371043439020353782'>🎲</tg-emoji>"; // Ludo Spin Custom Emoji
  var MSG_EMJ_TUTORIAL  = "<tg-emoji emoji-id='5258077307985207053'>📹</tg-emoji>";
  var MSG_EMJ_PROOF     = "<tg-emoji emoji-id='5330237710655306682'>✅</tg-emoji>"; // Payment Proof Custom Emoji
  var MSG_EMJ_SUPPORT   = "<tg-emoji emoji-id='5436113877181941026'>🔰</tg-emoji>";

  // New and updated emojis
  var EMJ_PREMIUM_MENU  = "<tg-emoji emoji-id='5406745015365943482'>✨</tg-emoji>";
  var EMJ_YOUR_BALANCE  = "<tg-emoji emoji-id='5231200819986047254'>💰</tg-emoji>";
  var EMJ_GET_STARTED   = "<tg-emoji emoji-id='6057415823222379852'>👇</tg-emoji>";

  // 📝 FULL WELCOME MESSAGE — synced with /start design Shadow and Scrapy Panel Store
  var welcomeMessage =
        "<b>" + SHOP_NAME + "</b>\n" +
        "━━━━━━━━━━━━━━━━━━━━\n" +
        "Welcome back, <b>" + ((user && user.first_name) ? user.first_name : "there") + "</b>\n\n" +
        "<b>Free Fire Panels</b>  ·  Instant delivery\n" +
        "Secure  ·  Verified  ·  24/7 Support\n" +
        "━━━━━━━━━━━━━━━━━━━━\n" +
        "Balance   <code>LKR " + userBal + "</code>\n" +
        "━━━━━━━━━━━━━━━━━━━━\n\n" +
        "<i>Select an option below.</i>";

  // 🎨 KEYBOARD — same layout as /start
  var multiColorKeyboard = [
    [{ text: "Shop Now", callback_data: "/buy_hack", style: "primary", icon_custom_emoji_id: "5866053971960929280" }],
    [
      { text: "Profile", callback_data: "/profile", style: "primary", icon_custom_emoji_id: "5260399854500191689" },
      { text: "Add Top Up", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "6147815702163102310" }
    ],
    [
      { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6113743082358841933" },
      { text: "How to use", callback_data: "/how", style: "danger", icon_custom_emoji_id: "6080214566191505147" }
    ],
    [{ text: "Payment Proofs", url: "https://chat.whatsapp.com/JR898GeUCjiKPXF25jDW2D?s=cl&p=a&mlu=4&ilr=4", style: "success", icon_custom_emoji_id: "5330237710655306682" }],
    [{ text: "Support", callback_data: "/support", style: "danger", icon_custom_emoji_id: "5436113877181941026" }]
  ];

  // 👑 Conditional Reseller Upgrade button
  if (Bot.getProperty("reseller_system_enabled") && !Bot.getProperty("is_reseller_" + userId)) {
    multiColorKeyboard.push([
      { text: "Reseller Upgrade", callback_data: "/reseller_upgrade", style: "success", icon_custom_emoji_id: "6102856637343600044" }
    ]);
  }

  // 🔄 Safe Callback Loading Controller
  var queryId = null;
  if (request) {
    if (request.id) { queryId = request.id; }
    else if (request.callback_query && request.callback_query.id) { queryId = request.callback_query.id; }
  }

  if (queryId) {
    try { Api.answerCallbackQuery({ callback_query_id: queryId }); } catch(qErr){}
  }

  // ⚡ Native Execution Route (Send vs Edit Handler)
  // ✅ BUG FIX: if the previous message was a PHOTO (like the Profile with a DP),
  // Telegram cannot use editMessageText on it — that is why the Profile
  // "Back" click did nothing. Now, if it is a photo, it is deleted and
  // a fresh text message is sent.
  if (request && request.message && request.message.message_id) {
    if (request.message.photo) {
      try { Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message.message_id }); } catch (delErr) {}
      sendMenuPhoto({
        chat_id: chat.chatid,
        text: statusBlockFor() + welcomeMessage,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
      });
    } else {
      try { Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message.message_id }); } catch (delErr2) {}
      sendMenuPhoto({
        chat_id: chat.chatid,
        text: statusBlockFor() + welcomeMessage,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
      });
    }
  } else {
    sendMenuPhoto({
      chat_id: chat.chatid,
      text: statusBlockFor() + welcomeMessage,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard })
    });
  }

} catch (globalException) {
  Bot.sendMessage("🛑 <b>Dashboard Debug Error:</b> <code>" + globalException.message + "</code>", { parse_mode: "HTML" });
}