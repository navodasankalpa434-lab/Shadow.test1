/**#command
name: /buy_hack
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Keys available for one plan (first saved list that has keys)
function keyCountFor(prod, pi, pj) {
  var nm = String(prod.name).trim();
  var plan = prod.plans[pj];
  var dd = String(plan.days).replace(/[^0-9.]/g, "");
  var cands = ["manual_keys_" + nm.toUpperCase() + "_" + dd, "stock_" + nm + "_" + dd + "_Day",
               "stock_" + nm + "_" + dd, "stock_" + pi + "_" + pj, "stock_" + nm + "_" + dd + "d_Day"];
  for (var c = 0; c < cands.length; c++) {
    var v = Bot.getProperty(cands[c]);
    if (typeof v === "string") { try { v = JSON.parse(v); } catch (e) { v = v.split("\n"); } }
    if (Array.isArray(v)) {
      var n = v.filter(function (k) { return String(k).trim() !== ""; }).length;
      if (n > 0) { return n; }
    }
  }
  return 0;
}
function productHasKeys(prod, pi) {
  if (!prod || !Array.isArray(prod.plans)) { return false; }
  for (var j = 0; j < prod.plans.length; j++) { if (keyCountFor(prod, pi, j) > 0) { return true; } }
  return false;
}
// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 🛒 SHOP MENU — Product listing (entry point of the whole buy flow)
// ✅ BUG FIX: reply_markup was sent as a raw object (JSON.stringify
// was missing) — so product buttons sometimes did not render or work properly
// which broke the whole buy flow before it even started.
// ✅ BUG FIX: when coming from a photo message (like Profile), editMessageText
// failed — now a photo is detected, deleted, and a fresh message is sent.
// ✅ Premium redesign.
// =========================================================

try {
  var rawData = Bot.getProperty("stored_products");
  var productList = [];

  if (Array.isArray(rawData)) {
    productList = rawData;
  } else if (typeof rawData === "string") {
    try {
      productList = JSON.parse(rawData);
      if (!Array.isArray(productList)) { productList = []; }
    } catch (e) {
      productList = [];
    }
  }

  // Empty list: show "no products" instead of inventing a default product.
  // (Default products are never saved, so removed products stay removed.)
  if (productList.length === 0) {
    Api.sendMessage({ chat_id: chat.chatid, parse_mode: "HTML",
      text: "<blockquote><b>🛒 No products available right now.</b></blockquote>\n<i>Please check back later.</i>" });
    return;
  }

  var chatId = chat.chatid;
  var firstName = user && user.first_name ? user.first_name : "User";
  var productButtons = [];

  for (var i = 0; i < productList.length; i++) {
    var item = productList[i];
    var itemName = (item && item.name) ? String(item.name) : "Product " + (i + 1);
    var itemEmoji = (item && item.emoji) ? String(item.emoji) : "5226656353744862682";
    var stockBadge = "";

    productButtons.push([
      {
        text: itemName,
        callback_data: "/viewprod " + i,
        style: productHasKeys(item, i) ? undefined : "danger",
        icon_custom_emoji_id: itemEmoji
      }
    ]);
  }

  productButtons.push([
    {
      text: "Back to Menu",
      callback_data: "/back",
      style: "danger",
      icon_custom_emoji_id: "5893163582194978381"
    }
  ]);

  var storeText =
    "<blockquote>🛒 <b>SELECT A PRODUCT</b> ✨</blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6091571559233755994'>👋</tg-emoji> <b>Yoo " + firstName + "!</b>\n" +
    "<i>Choose any product below to view its price and available duration plans.</i>\n" +
    "━━━━━━━━━━━━━━━━━━━━━";

  var replyMarkupStr = JSON.stringify({ inline_keyboard: productButtons });

  if (request && request.message && request.message.message_id) {
    if (request.message.photo) {
      try { Api.deleteMessage({ chat_id: chatId, message_id: request.message.message_id }); } catch (e) {}
      Api.sendMessage({ chat_id: chatId, text: storeText, parse_mode: "HTML", reply_markup: replyMarkupStr });
    } else {
      Api.editMessageText({
        chat_id: chatId,
        message_id: request.message.message_id,
        text: storeText,
        parse_mode: "HTML",
        reply_markup: replyMarkupStr
      });
    }
  } else {
    Api.sendMessage({ chat_id: chatId, text: storeText, parse_mode: "HTML", reply_markup: replyMarkupStr });
  }

  if (request && request.id) {
    try { Api.answerCallbackQuery({ callback_query_id: request.id }); } catch (e) {}
  }

} catch (err) {
  Bot.sendMessage("⚠️ Shop Menu Error: " + err.message, { parse_mode: "HTML" });
}