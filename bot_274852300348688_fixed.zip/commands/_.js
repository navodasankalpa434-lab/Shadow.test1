/**#command
name: *
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 🛡️ WILDCARD FALLBACK — catches any message/input that doesn't match
// a specific registered command.
// ✅ BUG FIX: previously this was a 241-line STALE duplicate copy (an old
// admin checks, plain crown emoji, any new fix — maintenance mode,
// coupon wizard, and case-insensitive /start was missing). Because this
// is a wildcard command, any unmatched input went through this old/buggy logic
// Now it passes everything straight to /start (where all the
// latest fixes are) — no duplicate or stale logic is left.
// =========================================================

try {
  // Typed commands (text starting with "/") are handled by their own command only
  var typedText = (typeof request !== "undefined" && request && request.message && request.message.text) ? String(request.message.text).trim() : "";
  if (typedText.charAt(0) === "/") { return; }
  Bot.run({ command: "/start" });
} catch (err) {
  try { Bot.sendMessage("⚠️ Please type /start.", { parse_mode: "HTML" }); } catch (e) {}
}