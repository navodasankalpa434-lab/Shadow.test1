/**#command
name: /send_stars_invoice
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}


// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// ⭐ Sends a real Telegram Stars (XTR) invoice.
// Usage via callback_data:
//   /send_stars_invoice deposit <amount>
//   /send_stars_invoice buy <prodIdx> <planIdx>
//
// ⚠️ IMPORTANT: This uses the RAW Telegram Bot API (sendInvoice) directly
// via bot.token, bypassing any platform-specific wrapper, since Stars
// payments (XTR currency, empty provider_token) need exact API compliance.
// For Stars: provider_token MUST be an empty string, currency MUST be "XTR".
// =========================================================

if (String(user.telegramid) !== "8500341403" && !isCoAdminId(String(user.telegramid))) { Api.sendMessage({ chat_id: user.telegramid, text: "🔒 Only the admin can add funds. Please contact the admin to top up your wallet.", parse_mode: "HTML" }); return; }
try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;

  var parts = params ? String(params).trim().split(" ") : [];
  var mode = parts[0];

  var title, description, payload, starsAmount;

  if (mode === "deposit") {
    starsAmount = parseInt(parts[1]);
    if (isNaN(starsAmount) || starsAmount <= 0) {
      Bot.sendMessage("❌ Invalid Stars amount.");
      return;
    }
    title = "Wallet Deposit — " + starsAmount + " Stars";
    description = "Add " + starsAmount + " Telegram Stars to your BALA MOOD OFACHELA STORE wallet balance.";
    payload = "deposit:" + userId + ":" + starsAmount;

  } else if (mode === "buy") {
    var prodIdx = Number(parts[1]);
    var planIdx = Number(parts[2]);
    var productList = Bot.getProperty("stored_products") || [];
    var product = productList[prodIdx];
    if (!product || !product.plans || !product.plans[planIdx]) {
      Bot.sendMessage("❌ Product/Plan not found.");
      return;
    }
    var plan = product.plans[planIdx];
    var cleanProdName = product.name.trim().toUpperCase();
    var planUnit = plan.unit || "day";
    var cleanPlanDays = String(plan.days).replace(/[^0-9.]/g, "").trim();
    var starsKeySuffix = (planUnit === "day") ? cleanPlanDays : (cleanPlanDays + "_" + planUnit);
    var starsPriceKey = "stars_price_" + cleanProdName + "_" + starsKeySuffix;
    starsAmount = Number(Bot.getProperty(starsPriceKey) || 0);

    if (!starsAmount) {
      Bot.sendMessage("❌ The Stars price is not set for this plan yet. Please contact the admin.");
      return;
    }

    var durationDisplay = plan.durationDisplay || (cleanPlanDays + " " + (planUnit === "hour" ? "Hour(s)" : planUnit === "minute" ? "Minute(s)" : "Day(s)"));
    title = product.name + " — " + durationDisplay;
    description = "Instant key delivery for " + product.name + " (" + durationDisplay + "), paid via Telegram Stars.";
    payload = "buy:" + userId + ":" + prodIdx + ":" + planIdx;

  } else {
    Bot.sendMessage("❌ Invalid invoice request.");
    return;
  }

  var invoiceBody = {
    chat_id: chatId,
    title: title,
    description: description,
    payload: payload,
    provider_token: "", // ✅ MUST be empty string for Telegram Stars (XTR)
    currency: "XTR",
    prices: JSON.stringify([{ label: title, amount: starsAmount }])
  };

  HTTP.post({
    url: "https://api.telegram.org/bot" + bot.token + "/sendInvoice",
    body: invoiceBody
  });

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) {
    try { Api.answerCallbackQuery({ callback_query_id: String(queryId), text: "⭐ Invoice sent!" }); } catch (e) {}
  }

} catch (err) {
  Bot.sendMessage("⚠️ Stars Invoice Error: " + err.message, { parse_mode: "HTML" });
}