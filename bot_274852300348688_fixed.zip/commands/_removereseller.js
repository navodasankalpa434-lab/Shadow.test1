/**#command
name: /removereseller
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  var targetId = params ? params.trim() : null;

  if (!targetId) {
    Bot.sendMessage("❌ <b>Usage:</b> <code>/removereseller 123456789</code>", { parse_mode: "HTML" });
    return;
  }

  Bot.setProperty("is_reseller_" + targetId, false, "boolean");

  Bot.sendMessage("<tg-emoji emoji-id='6143299028655280273'>☠</tg-emoji> User <code>" + targetId + "</code> 's reseller role has been removed.", { parse_mode: "HTML" });

  // Notify the user
  var removeNotif = "<blockquote><b><tg-emoji emoji-id='6143299028655280273'>⚠️</tg-emoji> ROLE REMOVED</b>\n\n" +
                    "Your **Reseller Role** has been removed by the admin. You will now see normal prices.</blockquote>";
                    
  Api.sendMessage({
    chat_id: targetId,
    text: removeNotif,
    parse_mode: "HTML"
  });

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}