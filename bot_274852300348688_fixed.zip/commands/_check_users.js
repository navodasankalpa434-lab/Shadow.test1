/**#command
name: /check_users
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 👥 COMMAND: /check_users
// STATUS: 100% OPERATIONAL & ANTI-CRASH CHUNK SYSTEM
// =========================================================

try {
  var adminId = "8500341403"; // Your Admin ID

  // Strict Admin Validation
  if (String(chat.chatid) !== adminId && !isCoAdminId(chat.chatid)) {
    Bot.sendMessage("❌ Access Denied: Only the Owner can view the user database.");
    return;
  }

  // Fetch users array safely
  var userList = Bot.getProperty("all_users_list") || [];
  if (!Array.isArray(userList)) { userList = []; }

  if (userList.length === 0) {
    Bot.sendMessage("⚠️ <b>Database Empty:</b> No users have registered in the bot yet.", { parse_mode: "HTML" });
    return;
  }

  var header = "<blockquote><b>👥 TOTAL REGISTERED USERS LIST</b>\n\n" +
               "📊 <b>Total Growth Node:</b> <code>" + userList.length + " Active Users</code></blockquote>\n" +
               "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";

  var bodyText = "";
  
  // Loop through all users and format
  for (var i = 0; i < userList.length; i++) {
    var userLine = "<b>[" + (i + 1) + "]</b> ID: <code>" + userList[i] + "</code>\n";
    
    // Memory and boundary protection: Split messages if character count exceeds 3500
    if ((header + bodyText + userLine).length > 3500) {
      Bot.sendMessage(header + bodyText, { parse_mode: "HTML" });
      header = ""; // Clear header for subsequent chunks
      bodyText = ""; // Reset temporary storage buffer
    }
    bodyText += userLine;
  }

  // Print final remaining chunk safely
  if (bodyText.trim() !== "") {
    Bot.sendMessage(header + bodyText + "\n━━━━━━━━━━━━━━━━━━━━━━━━━━", { parse_mode: "HTML" });
  }

} catch (err) {
  Bot.sendMessage("🛑 <b>User Audit Error:</b> <code>" + err.message + "</code>", { parse_mode: "HTML" });
}