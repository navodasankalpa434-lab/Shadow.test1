/**#command
name: /how
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  // Instant answer to stop the click loading spinner
  if (request && request.id) {
    HTTP.post({
      url: "https://api.telegram.org/bot" + bot.token + "/answerCallbackQuery",
      body: { callback_query_id: request.id }
    });
  }

  var chatId = chat.chatid;
  var messageId = request && request.message ? request.message.message_id : null;

  // Premium Text with your custom premium emojis
  var text = "━━━━━━━━━━━━━━━━━━━━\n" +
             "<tg-emoji emoji-id='6195222374355311655'>👑</tg-emoji> <b>HOW TO USE THE BOT</b>\n" +
             "━━━━━━━━━━━━━━━━━━━━\n\n" +
             "<blockquote>" +
             "<tg-emoji emoji-id='6219605968846591564'>😎</tg-emoji> Follow these simple steps to use the bot:\n\n" +
             "<tg-emoji emoji-id='6194809138371904539'>📉</tg-emoji> 1. Add balance to your wallet first.\n" +
             "<tg-emoji emoji-id='6298597328022407025'>💰</tg-emoji> 2. Go to products section and pick your plan.\n" +
             "<tg-emoji emoji-id='5316728625465146646'>👆</tg-emoji> 3. Click buy and copy your instant key!\n\n" +
             "<i>Watch the detailed video tutorial below for full guide!</i>" +
             "</blockquote>";

  // Inline Keyboard configuration with direct URL system
  var keyboard = {
    inline_keyboard: [
      [
        {
          text: "Watch Video Guide",
          url: "https://t.me/c/4397881408/13", 
          style: "primary", // ⚡ Style property added here as requested
          icon_custom_emoji_id: "5258077307985207053" 
        }
      ],
      [
        {
          text: "Back",
          callback_data: "/back", 
          style: "danger", 
          icon_custom_emoji_id: "5316623368701623632"
        }
      ]
    ]
  };

  var endpoint = messageId ? "editMessageText" : "sendMessage";
  var requestBody = {
    chat_id: String(chatId),
    text: text,
    parse_mode: "HTML",
    reply_markup: JSON.stringify(keyboard)
  };

  if (messageId) {
    requestBody.message_id = Number(messageId);
  }

  HTTP.post({
    url: "https://api.telegram.org/bot" + bot.token + "/" + endpoint,
    body: requestBody
  });

} catch (err) {}