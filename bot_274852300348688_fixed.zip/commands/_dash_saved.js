/**#command
name: /dash_saved
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Discord accepted the dashboard message: remember its id and tell the owner
try {
  var dj = JSON.parse(content);
  if (dj && dj.id) {
    Bot.setProperty("dash_message_id", String(dj.id), "string");
    Api.sendMessage({ chat_id: "8500341403", parse_mode: "HTML",
      text: "✅ <b>Dashboard is live in Discord.</b>\nIt will update after each sale, top-up and wallet change." });
  }
} catch (e) {}
return;