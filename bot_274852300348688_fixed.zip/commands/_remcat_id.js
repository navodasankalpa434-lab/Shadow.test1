/**#command
name: /remcat_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (!chat || String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  // 🛡️ CRASH FIX: first check that the message is not null
  if (!message) {
    Bot.sendMessage("✍️ <b>Please type the category name and send it!</b>\n\n<b>Correct Format:</b>\n<code>/remcat_id [Category Name]</code>\n\n<b>Example:</b>\n<code>/remcat_id Facebook Id</code>", {parse_mode: "HTML"});
    return;
  }

  var cleanMessage = message.trim();

  // If the command text is at the start of the message, clean it up
  if (cleanMessage.indexOf("/remcat_id") === 0) {
    cleanMessage = cleanMessage.replace("/remcat_id", "").trim();
  }

  if (!cleanMessage) {
    Bot.sendMessage("⚠️ <b>Wrong Format!</b>\n\n<b>Correct Format:</b>\n<code>/remcat_id [Category Name]</code>\n\n<b>Example:</b>\n<code>/remcat_id Facebook Id</code>", {parse_mode: "HTML"});
    return;
  }

  // FIXED: correct slug creation algorithm, exactly the same as in the addcat_id script
  var catSlug = cleanMessage.toLowerCase().replace(/[^a-z0-9]/g, "");
  
  var categories = Bot.getProperty("ff_categories") || {};

  if (!categories[catSlug]) {
    Bot.sendMessage("❌ <b>Category not found!</b>\n\nCheck the name carefully or look in the menu.", {parse_mode: "HTML"});
    return;
  }

  var oldName = categories[catSlug].name;
  
  // Remove the category from the array/object
  delete categories[catSlug];
  Bot.setProperty("ff_categories", categories, "json");
  
  // Completely wipe the associated stock from the database
  Bot.setProperty("ff_stock_" + catSlug, null);

  Bot.sendMessage("🗑️ <b>Category Successfully Deleted!</b>\n\n• <b>Name:</b> <code>" + oldName + "</code>\n• <b>System Slug Wiped:</b> <code>" + catSlug + "</code>\n\n<i>This category and all its stock have now been removed from the database.</i>", {parse_mode: "HTML"});

} catch(e) {
  Bot.sendMessage("Error in Remove Category: " + e.message);
}