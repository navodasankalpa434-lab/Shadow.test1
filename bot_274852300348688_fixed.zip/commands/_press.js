/**#command
name: /press
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}


// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// Command Name: /press (Premium Calculator Keypad Handler)
// ✅ FIXED: the "Back" button used to call "/dmenu", which does not exist in the bot
// (a dead button — clicking it did nothing). Now "/back" (the real menu command) is used.
// ✅ Number buttons now have the same blue "primary" styling as the addfund screen (they were plain before).

if (String(user.telegramid) !== "8500341403" && !isCoAdminId(String(user.telegramid))) { Api.sendMessage({ chat_id: user.telegramid, text: "🔒 Only the admin can add funds. Please contact the admin to top up your wallet.", parse_mode: "HTML" }); return; }
try {
  // Default check: if the user started a new deposit, the default stays 0
  let current_amount = User.getProperty("deposit_amount");
  if (!current_amount) {
    current_amount = "0";
  }

  let pressed = params ? params.trim() : "";
  let queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  // 💎 Premium Emoji Set (same IDs as /addfund — keeps the screen visually identical, no flicker)
  let e_money   = "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji>";
  let e_clear   = "<tg-emoji emoji-id='5348224471050238603'>✏</tg-emoji>";
  let e_confirm = "<tg-emoji emoji-id='5348191451341668809'>✅</tg-emoji>";
  let e_back    = "<tg-emoji emoji-id='5893163582194978381'>⬅️</tg-emoji>";
  let e_hour    = "<tg-emoji emoji-id='6100657257605763582'>✔️</tg-emoji>";
  let e_check   = "<tg-emoji emoji-id='6311870645277825763'>✔️</tg-emoji>";
  let e_gear    = "<tg-emoji emoji-id='5348292765325212780'>⚙</tg-emoji>";

  // --- CONFIRM BUTTON CLICK ---
  if (pressed == "confirm") {
    if (parseInt(current_amount) <= 0 || current_amount == "" || current_amount == "0") {
      if (queryId) {
        Api.answerCallbackQuery({
          callback_query_id: queryId,
          text: "👀 PLEASE ENTER A VALID AMOUNT!",
          show_alert: true
        });
      }
      return;
    }

    let generatingText =
      "<blockquote>" + e_gear + " <b>Generating QR Code for LKR " + current_amount + "...</b>\n" +
      "<i>Please wait a moment</i></blockquote>";

    Api.editMessageText({
      chat_id: chat.chatid,
      message_id: request.message.message_id,
      text: generatingText,
      parse_mode: "HTML"
    });

    // ✅ FIX: save the ID of this "Generating..." message so that when the QR arrives (or is cancelled)
    // it can be removed properly and does not stay as an old message.
    try {
      Bot.setProperty("gen_msg_id_" + user.telegramid, request.message.message_id, "string");
      User.setProperty("gen_msg_id_" + user.telegramid, request.message.message_id, "string");
    } catch (e) {}

    let finalAmount = String(parseInt(current_amount));
    let upiId = "suraj12347singha@fam";

    // Amount reset to 0 so next time it starts fresh
    User.setProperty("deposit_amount", "0", "string");

    HTTP.get({
      url: "https://fampay.anujbots.xyz/qr.php?upi=" + encodeURIComponent(upiId) + "&amount=" + encodeURIComponent(finalAmount),
      success: "/onQR",
      error: "/onApiError"
    });

    return;
  }

  // --- KEYPAD INPUT LOGIC ---
  if (pressed == "clear") {
    if (current_amount.length > 1) {
      current_amount = current_amount.slice(0, -1);
    } else {
      current_amount = "0";
    }
  } else if (pressed !== "") {
    if (current_amount == "0") {
      current_amount = pressed;
    } else {
      if ((current_amount + pressed).length <= 6) {
        current_amount = current_amount + pressed;
      }
    }
  }

  // Save current keypad amount state
  User.setProperty("deposit_amount", current_amount, "string");

  if (queryId) {
    Api.answerCallbackQuery({ callback_query_id: queryId });
  }

  // 🎨 Keypad Buttons — same premium colored styling as /addfund
  let inlineKeyboardPayload = [
    [
      { text: "1", callback_data: "/press 1", style: "primary" },
      { text: "2", callback_data: "/press 2", style: "primary" },
      { text: "3", callback_data: "/press 3", style: "primary" }
    ],
    [
      { text: "4", callback_data: "/press 4", style: "primary" },
      { text: "5", callback_data: "/press 5", style: "primary" },
      { text: "6", callback_data: "/press 6", style: "primary" }
    ],
    [
      { text: "7", callback_data: "/press 7", style: "primary" },
      { text: "8", callback_data: "/press 8", style: "primary" },
      { text: "9", callback_data: "/press 9", style: "primary" }
    ],
    [
      { text: "Clear", callback_data: "/press clear", style: "danger", icon_custom_emoji_id: "5348224471050238603" },
      { text: "0", callback_data: "/press 0", style: "primary" },
      { text: "Confirm", callback_data: "/press confirm", style: "success", icon_custom_emoji_id: "5348191451341668809" }
    ],
    [
      // ✅ FIXED: "/dmenu" -> "/back" (dead command replaced with the real menu handler)
      { text: "Back", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
    ]
  ];

  let keypadMsg =
    "<blockquote>" + e_money + " <b>ADD BALANCE — ENTER AMOUNT</b> <tg-emoji emoji-id='6312263493051489212'>💎</tg-emoji></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6312263493051489212'>💎</tg-emoji> <b>Amount:</b> LKR <code>" + current_amount + "</code>\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    e_check + " <i>Instant Auto-Credit</i>\n" +
    "<tg-emoji emoji-id='6215386799133433653'>🔒</tg-emoji> <i>100% Secure UPI Payment</i>\n" +
    e_hour + " <i>Verified in Seconds</i>\n\n" +
    "<tg-emoji emoji-id='6100170496077204999'>👑</tg-emoji> <i>Use the keypad below to enter amount</i>";

  Api.editMessageText({
    chat_id: chat.chatid,
    message_id: request.message.message_id,
    text: keypadMsg,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineKeyboardPayload })
  });

} catch (err) {
  Bot.sendMessage("⚠️ System Error in Keypad: " + err.message);
}