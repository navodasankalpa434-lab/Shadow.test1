/**#command
name: /addkey
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params) {
    Bot.sendMessage("⚠️ *Format:* `/addkey PRODUCT NAME | DAYS | KEY1`\n`KEY2`\n`KEY3` (Line-by-line)", { parse_mode: "Markdown" });
    return;
  }

  var lines = params.split("\n");
  var firstLineParts = lines[0].split("|");

  if (firstLineParts.length < 3) {
    Bot.sendMessage("⚠️ *Wrong Format!*\nThe first line must be `Product Name | Days | Key`.", { parse_mode: "Markdown" });
    return;
  }

  // 1. Clean and trim the inputs
  var pName = firstLineParts[0].trim().toLowerCase();
  var pDays = firstLineParts[1].trim(); 
  
  // Keep only the number of days ("1d", "1 Day", "1_Day" all become "1")
  var pDaysNumOnly = (pDays.match(/[0-9]+(\.[0-9]+)?/) || [pDays])[0];
  var pDaysClean = pDaysNumOnly + "_Day";

  var keysToAdd = [];
  keysToAdd.push(firstLineParts[2].trim());

  for (var l = 1; l < lines.length; l++) {
    var currentLineKey = lines[l].trim();
    if (currentLineKey !== "") {
      keysToAdd.push(currentLineKey);
    }
  }

  // 2. Products fetching
  var productList = Bot.getProperty("stored_products") || [];
  var prodIdx = -1;
  var planIdx = -1;
  var exactProdName = firstLineParts[0].trim(); // Fallback name

  // Soft loop matching (Case insensitive)
  for (var i = 0; i < productList.length; i++) {
    if (productList[i].name.trim().toLowerCase() === pName) {
      prodIdx = i;
      exactProdName = productList[i].name.trim();
      break;
    }
  }

  // FORCE CORRECTION: if the index is not found in the loop, handle it anyway
  if (prodIdx === -1) {
    Bot.sendMessage("⚠️ Product *" + exactProdName + "* was not found in the lists, but the system is generating via the dynamic key store bypass...", { parse_mode: "Markdown" });
  } else {
    var plans = productList[prodIdx].plans || [];
    for (var j = 0; j < plans.length; j++) {
      if (String(plans[j].days).trim() === pDaysNumOnly) {
        planIdx = j;
        break;
      }
    }
  }

  // 3. Dual-pipeline saving mechanics
  var stockKeyText = "stock_" + exactProdName + "_" + pDaysClean;
  var currentStock = Bot.getProperty(stockKeyText) || [];
  
  // Array merging
  var updatedStock = currentStock.concat(keysToAdd);
  Bot.setProperty(stockKeyText, updatedStock, "json");

  // If a structured index matched, also update that pipeline
  if (prodIdx !== -1 && planIdx !== -1) {
    var stockKeyIndex = "stock_" + prodIdx + "_" + planIdx;
    Bot.setProperty(stockKeyIndex, updatedStock, "json");
  }

  // 4. GUARANTEED SUCCESS CONFIRMATION MESSAGE
  var successMsg = "<blockquote><b>📦 STOCK UPDATED SUCCESSFULLY</b>\n\n" +
                   "• <b>Product:</b> <code>" + exactProdName + "</code>\n" +
                   "• <b>Plan:</b> <code>" + pDaysClean + "</code>\n" +
                   "• <b>Added Keys:</b> <code>" + keysToAdd.length + " Keys</code>\n" +
                   "• <b>Total Stock Now:</b> <code>" + updatedStock.length + " Keys available</code></blockquote>";

  Bot.sendMessage(successMsg, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}