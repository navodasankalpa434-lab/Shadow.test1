/**#command
name: /removekey
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403"; // Your Admin ID
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  if (!params) {
    Bot.sendMessage("❌ <b>Usage:</b>\n<code>/removekey PRODUCT NAME | DAYS</code>\n\n<i>Example: DRIP CLIENT | 1_Day</i>", { parse_mode: "HTML" });
    return;
  }

  var args = params.split("|");
  if (args.length < 2) {
    Bot.sendMessage("❌ <b>Format Error!</b> Use Pipe symbol:\n<code>/removekey PRODUCT NAME | DAYS</code>", { parse_mode: "HTML" });
    return;
  }

  var prodName = args[0].trim();
  var planDays = args[1].trim();
  var cleanPlanDays = planDays.includes("_Day") ? planDays : planDays + "_Day";

  var stockKeyText = "stock_" + prodName + "_" + cleanPlanDays;
  var keyStock = Bot.getProperty(stockKeyText) || [];

  if (keyStock.length === 0) {
    Bot.sendMessage("❌ Product: <b>" + prodName + " (" + cleanPlanDays + ")</b> stock is already empty!", { parse_mode: "HTML" });
    return;
  }

  var inlineButtons = [];
  
  // Create an individual delete button for each key
  for (var i = 0; i < keyStock.length; i++) {
    var fullKey = keyStock[i];
    // Show a short part of the key for display so the button is not too big
    var shortKey = fullKey.length > 15 ? fullKey.substring(0, 12) + "..." : fullKey; 
    
    inlineButtons.push([
      {
        text: "🗑️ Key " + (i + 1) + " [" + shortKey + "]",
        // Pass the parameters in the callback: index_number | prodName | planDays
        callback_data: "/deletekey_now " + i + "|" + prodName + "|" + cleanPlanDays
      }
    ]);
  }

  var menuText = "<blockquote><b>🗑️ SELECT KEY TO REMOVE</b>\n\n" +
                 "• <b>Product:</b> <code>" + prodName + "</code>\n" +
                 "• <b>Plan:</b> <code>" + cleanPlanDays + "</code>\n" +
                 "• <b>Total Keys:</b> <code>" + keyStock.length + "</code>\n\n" +
                 "<i>Click the button below for the key you want to remove:</i></blockquote>";

  Bot.sendMessage(menuText, {
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}