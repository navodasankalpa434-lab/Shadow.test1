/**#command
name: /support
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}


// Support menu: two admin Telegram usernames
try {
  // Stop the button loading spinner
  if (request && request.callback_query) {
    try { Api.answerCallbackQuery({ callback_query_id: request.callback_query.id }); } catch (qErr) {}
  }

  var chatId = chat.chatid;

  var text = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
             "<tg-emoji emoji-id='6039605143601680423'>📞</tg-emoji> <b>CUSTOMER SUPPORT CENTER</b>\n" +
             "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
             "<blockquote>" +
             "Welcome to our support desk. If you are facing any issues regarding keys, payments, or services, feel free to contact us.\n\n" +
             "Choose an admin below to start a chat." +
             "</blockquote>";

  var keyboard = {
    inline_keyboard: [
      [
        {
          text: "Admin 1: @ShadowXcheatZz",
          url: "https://t.me/ShadowXcheatZz",
          style: "primary",
          icon_custom_emoji_id: "5346024644635804737"
        }
      ],
      [
        {
          text: "Admin 2: @ScrapyXiter",
          url: "https://t.me/ScrapyXiter",
          style: "primary",
          icon_custom_emoji_id: "5346024644635804737"
        }
      ],
      [
        {
          text: "Back",
          callback_data: "/back",
          style: "danger",
          icon_custom_emoji_id: "5893163582194978381"
        }
      ]
    ]
  };

  Api.sendMessage({
    chat_id: String(chatId),
    text: text,
    parse_mode: "HTML",
    reply_markup: JSON.stringify(keyboard)
  });

} catch (err) {}