/**#command
name: /confirm_buyitem
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Customer purchase history, keys sold and total spent (saved per customer, included in backups)
function recordPurchase(uid, rec) {
  var h = Bot.getProperty("history_" + uid) || [];
  if (typeof h === "string") { try { h = JSON.parse(h); } catch (e) { h = []; } }
  if (!Array.isArray(h)) { h = []; }
  h.push(rec);
  Bot.setProperty("history_" + uid, h, "json");
  Bot.setProperty("keys_sold_" + uid, String(Number(Bot.getProperty("keys_sold_" + uid) || 0) + 1), "string");
  Bot.setProperty("dash_spent_" + uid, String(Number(Bot.getProperty("dash_spent_" + uid) || 0) + Number(rec.price || 0)), "string");
}
// Full purchase receipt sent to the customer's Telegram chat, with a download button
function sendReceipt(uid, rec, tier) {
  try {
    var nm = (typeof user !== "undefined" && user) ? ((user.first_name || "") + " " + (user.last_name || "")).trim() : "";
    var un = (typeof user !== "undefined" && user && user.username) ? "@" + user.username : "-";
    var ph = Bot.getProperty("phone_" + uid) || "-";
    var jd = Bot.getProperty("joined_date_" + uid) || "-";
    var rk = (tier && tier.name && Number(tier.pct) > 0) ? (tier.name + " (" + tier.pct + "% off)") : "None (0% off)";
    var txt = "<blockquote><b>🧾 PURCHASE RECEIPT</b></blockquote>\n" +
      "<b>Name:</b> " + nm + "\n<b>Username:</b> " + un + "\n<b>Chat ID:</b> <code>" + uid + "</code>\n" +
      "<b>Phone:</b> <code>" + ph + "</code>\n<b>Registered:</b> " + jd + "\n━━━━━━━━━━━━━━━━━━━━\n" +
      "<b>Product:</b> " + rec.product + "\n<b>Duration:</b> " + rec.plan + "\n<b>Price paid:</b> LKR " + rec.price + "\n" +
      "<b>Rank:</b> " + rk + "\n━━━━━━━━━━━━━━━━━━━━\n<b>🔑 YOUR KEY</b>\n<code>" + (rec.key || "-") + "</code>";
    Api.sendMessage({ chat_id: String(uid), text: txt, parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "📥 Download Receipt", callback_data: "/history_receipt", style: "primary" }]] }) });
  } catch (e) {}
}
function salesLogAdd(entry) {
  var slog = Bot.getProperty("sales_log") || [];
  if (typeof slog === "string") { try { slog = JSON.parse(slog); } catch (e) { slog = []; } }
  if (!Array.isArray(slog)) { slog = []; }
  slog.push(entry);
  if (slog.length > 2000) { slog = slog.slice(slog.length - 2000); }
  Bot.setProperty("sales_log", slog, "json");
}
// Discord image: a direct https link set with /settings discord image LINK (or the menu photo link)
function discordImgObj() {
  var u = String(Bot.getProperty("discord_image") || Bot.getProperty("menu_photo_url") || "");
  return (u.indexOf("https://") === 0) ? { url: u } : undefined;
}
// Live Discord dashboard: one message, updated on every sale, top-up and wallet change
function dashInc(key, amt) { Bot.setProperty(key, String(Number(Bot.getProperty(key) || 0) + Number(amt || 0)), "string"); }
function updateDashboard(evt) {
  try {
    if (evt && evt.type === "sale") { dashInc("dash_sales_count", 1); dashInc("dash_sales_total", evt.price);
      if (evt.user) { dashInc("dash_orders_" + evt.user, 1); dashInc("dash_spent_" + evt.user, evt.price); } }
    if (evt && evt.type === "sale") { salesLogAdd({ date: new Date().toISOString(), user: String(evt.user || ""), product: evt.product || "", plan: evt.plan || "", price: evt.price, key: evt.key || "" }); }
    if (evt && evt.type === "topup") { dashInc("dash_topup_count", 1); dashInc("dash_topup_total", evt.amount); }
    if (evt && evt.type === "wallet") { dashInc("dash_wallet_count", 1); dashInc("dash_wallet_total", evt.amount); }
    var hook = String(Bot.getProperty("discord_webhook") || "");
    if (hook.indexOf("https://discord.com/api/webhooks/") !== 0 && hook.indexOf("https://discordapp.com/api/webhooks/") !== 0) { return; }
    var ul = Bot.getProperty("all_users_list") || [];
    if (typeof ul === "string") { try { ul = JSON.parse(ul); } catch (e) { ul = []; } }
    if (!Array.isArray(ul)) { ul = []; }
    var rl = Bot.getProperty("resellers_list") || [];
    if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e2) { rl = []; } }
    var rIds = Array.isArray(rl) ? rl.map(function (x) { return String(x && x.id !== undefined ? x.id : x); }) : [];
    var cl = Bot.getProperty("co_admin_list") || [];
    if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e3) { cl = []; } }
    var cIds = Array.isArray(cl) ? cl.map(String) : [];
    var rows = [], walletTotal = 0, verifiedCount = 0, resellerCount = 0;
    for (var i = 0; i < ul.length; i++) {
      var uid = String(ul[i]);
      if (uid === "8500341403") { continue; }
      var bal = 0;
      try { bal = Number(Libs.ResourcesLib.anotherUserRes("balance", uid).value() || 0); } catch (be) { bal = 0; }
      var vv = Bot.getProperty("verified_" + uid);
      var ver = (vv === true || String(vv) === "true");
      var isR = rIds.indexOf(uid) !== -1 || !!Bot.getProperty("is_reseller_" + uid);
      var role = uid === "8500341403" ? "👑" : (cIds.indexOf(uid) !== -1 ? "🛡" : (isR ? "🔴" : "👤"));
      walletTotal += bal; if (ver) { verifiedCount++; } if (isR) { resellerCount++; }
      rows.push({ id: uid, bal: bal, ver: ver, role: role, tu: Number(Bot.getProperty("topup_total_" + uid) || 0),
                  ord: Number(Bot.getProperty("dash_orders_" + uid) || 0), spent: Number(Bot.getProperty("dash_spent_" + uid) || 0) });
    }
    rows.sort(function (a, b) { return b.bal - a.bal; });
    var lines = rows.slice(0, 20).map(function (r) {
      return r.role + " `" + r.id + "` " + (r.ver ? "✅" : "⬜") + "  💳 " + r.bal + "  ·  💰 top-up " + r.tu + "  ·  🛒 " + r.ord + " (" + r.spent + ")";
    });
    var stockKeys = 0;
    var sprods = Bot.getProperty("stored_products") || [];
    if (typeof sprods === "string") { try { sprods = JSON.parse(sprods); } catch (se) { sprods = []; } }
    if (!Array.isArray(sprods)) { sprods = []; }
    for (var si = 0; si < sprods.length; si++) {
      var sp = sprods[si];
      if (!sp || !sp.name) { continue; }
      var spl = Array.isArray(sp.plans) ? sp.plans : [];
      for (var sj = 0; sj < spl.length; sj++) {
        var sd = String(spl[sj].days).replace(/[^0-9.]/g, "");
        var sn = String(sp.name).trim();
        var scands = ["manual_keys_" + sn.toUpperCase() + "_" + sd, "stock_" + sn + "_" + sd + "_Day",
                      "stock_" + sn + "_" + sd, "stock_" + si + "_" + sj, "stock_" + sn + "_" + sd + "d_Day"];
        for (var sc = 0; sc < scands.length; sc++) {
          var sv = Bot.getProperty(scands[sc]);
          if (typeof sv === "string") { try { sv = JSON.parse(sv); } catch (se2) { sv = sv.split("\n"); } }
          if (Array.isArray(sv) && sv.length > 0) {
            stockKeys += sv.filter(function (k) { return String(k).trim() !== ""; }).length;
            break;
          }
        }
      }
    }
    var now = new Date().toISOString().replace("T", " ").substring(0, 16) + " UTC";
    var embeds = [
      { title: "📊 LIVE DASHBOARD", color: 3447003, thumbnail: discordImgObj(), description: "Updated: **" + now + "**",
        fields: [
          { name: "📦 Keys in stock", value: "**" + stockKeys + "** available", inline: true },
          { name: "🛒 Sales", value: "**" + Number(Bot.getProperty("dash_sales_count") || 0) + "** orders\nLKR " + Number(Bot.getProperty("dash_sales_total") || 0), inline: true },
          { name: "💳 Top-ups", value: "**" + Number(Bot.getProperty("dash_topup_count") || 0) + "** approved\nLKR " + Number(Bot.getProperty("dash_topup_total") || 0), inline: true },
          { name: "👥 Users", value: "**" + rows.length + "** total\n✅ " + verifiedCount + " verified", inline: true },
          { name: "🏦 Wallet total", value: "LKR " + walletTotal, inline: true },
          { name: "🔴 Resellers", value: "**" + resellerCount + "**", inline: true }
        ] },
      { title: "👤 PROFILES (top 20 by balance)", color: 3066993,
        description: lines.length ? lines.join("\n") : "No profiles yet." }
    ];
    var payload = JSON.stringify({ username: "Store Dashboard", embeds: embeds });
    var hdr = { "Content-Type": "application/json" };
    var mid = String(Bot.getProperty("dash_message_id") || "");
    if (mid && typeof HTTP.patch === "function") {
      HTTP.patch({ url: hook + "/messages/" + mid, body: payload, headers: hdr, success: "/discord_ok", error: "/dash_error" });
    } else {
      HTTP.post({ url: hook + "?wait=true", body: payload, headers: hdr, success: "/dash_saved", error: "/dash_error" });
    }
  } catch (e) {}
}
// Discord sale alert: styled embed with buyer role and details
function notifyDiscordSale(info) {
  try {
    var hook = String(Bot.getProperty("discord_webhook") || "");
    if (hook.indexOf("https://discord.com/api/webhooks/") !== 0 && hook.indexOf("https://discordapp.com/api/webhooks/") !== 0) { return; }
    var bid = String(info.user);
    var rl = Bot.getProperty("resellers_list") || [];
    if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e) { rl = []; } }
    var isRes = !!Bot.getProperty("is_reseller_" + bid) || (Array.isArray(rl) && rl.some(function (x) { return String(x && x.id !== undefined ? x.id : x) === bid; }));
    var cl = Bot.getProperty("co_admin_list") || [];
    if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e2) { cl = []; } }
    var role = bid === "8500341403" ? "👑 Owner" : (Array.isArray(cl) && cl.map(String).indexOf(bid) !== -1) ? "🛡 Co-admin" : isRes ? "🔴 Reseller" : "👤 Customer";
    var vv = Bot.getProperty("verified_" + bid);
    var verified = (vv === true || String(vv) === "true") ? "✅ Verified" : "🔴 Not verified";
    var bal = "-";
    try { bal = "LKR " + (Libs.ResourcesLib.anotherUserRes("balance", bid).value() || 0); } catch (be) {}
    var buyer = info.name ? info.name : "Customer";
    var color = (info.source === "manual stock") ? 3066993 : 3447003;
    var payload = {
      username: "Sales Bot",
      embeds: [{
        title: "🛒  NEW SALE",
        description: "**" + info.product + "** — " + info.plan,
        color: color,
        fields: [
          { name: "💰 Price", value: "LKR " + info.price, inline: true },
          { name: "📦 Delivery", value: info.source, inline: true },
          { name: "🏷 Role", value: role, inline: true },
          { name: "👤 Buyer", value: buyer, inline: true },
          { name: "🆔 Chat ID", value: "`" + bid + "`", inline: true },
          { name: "🔐 Account", value: verified, inline: true },
          { name: "💳 Balance now", value: bal, inline: true }
        ],
        footer: { text: "Shadow and Scrapy Panel Store" },
        thumbnail: discordImgObj(),
        timestamp: new Date().toISOString()
      }]
    };
    HTTP.post({ url: hook, body: JSON.stringify(payload), headers: { "Content-Type": "application/json" },
                success: "/discord_ok", error: "/discord_ok" });
  } catch (e) {}
}
// Rank discount: based on the customer's total approved top-ups (set with /settings tier)
function getRankTier(id) {
  var total = Number(Bot.getProperty("topup_total_" + id) || 0);
  var tiers = Bot.getProperty("topup_tiers") || [];
  if (typeof tiers === "string") { try { tiers = JSON.parse(tiers); } catch (e) { tiers = []; } }
  var best = { pct: 0, name: "None", total: total };
  if (Array.isArray(tiers)) {
    for (var t = 0; t < tiers.length; t++) {
      if (total >= Number(tiers[t].min) && Number(tiers[t].pct) > best.pct) {
        best = { pct: Number(tiers[t].pct), name: tiers[t].name || "Member", total: total };
      }
    }
  }
  return best;
}
// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// ✅ ACTUAL PURCHASE EXECUTION — runs after user taps "Confirm" on the
// premium confirmation screen, OR automatically right after a shortfall
// QR payment is verified (see _onCheck.js), so key delivery is fully automatic.
// =========================================================

try {
  var productList = Bot.getProperty("stored_products") || [];
  var chatId = chat.chatid;
  var userId = user.telegramid;

  var parts = params ? String(params).trim().split(" ") : [];
  var prodIdx = Number(parts[0]);
  var planIdx = Number(parts[1]);

  var product = productList[prodIdx];
  if (!product || !product.plans || !product.plans[planIdx]) {
    Api.sendMessage({ chat_id: chatId, text: "❌ Product or Plan configuration missing!" });
    return;
  }

  var plan = product.plans[planIdx];
  var planUnit = plan.unit || "day";
  var isReseller = Bot.getProperty("is_reseller_" + userId) === true;

  var cleanProdName = product.name.trim().toUpperCase();
  var cleanPlanDays = String(plan.days).replace(/[^0-9.]/g, "").trim();
  var unitLabelWord = (planUnit === "hour") ? (Number(cleanPlanDays) === 1 ? "Hour" : "Hours") :
                       (planUnit === "minute") ? (Number(cleanPlanDays) === 1 ? "Minute" : "Minutes") :
                       (Number(cleanPlanDays) === 1 ? "Day" : "Days");
  var durationDisplay = plan.durationDisplay || (cleanPlanDays + " " + unitLabelWord);

  var priceKeySuffix = (planUnit === "day") ? cleanPlanDays : (cleanPlanDays + "_" + planUnit);
  var normalKey = "price_normal_" + cleanProdName + "_" + priceKeySuffix;
  var resellerKey = "price_reseller_" + cleanProdName + "_" + priceKeySuffix;

  var adminNormalPrice = Bot.getProperty(normalKey);
  var adminResellerPrice = Bot.getProperty(resellerKey);

  var currentNormal = (adminNormalPrice !== undefined && adminNormalPrice !== null) ? adminNormalPrice : plan.normal_price;
  var currentReseller = (adminResellerPrice !== undefined && adminResellerPrice !== null) ? adminResellerPrice : plan.reseller_price;

  var originalPrice = isReseller ? Number(currentReseller) : Number(currentNormal);
  var price = originalPrice;

  var planSpecificDiscKey = "auto_discount_" + cleanProdName + "_" + cleanPlanDays + "_" + planUnit.toUpperCase();
  var productWideDiscKey = "auto_discount_" + cleanProdName + "_ALL";
  var autoDiscountPercent = Bot.getProperty(planSpecificDiscKey) || Bot.getProperty(productWideDiscKey) || Bot.getProperty("auto_discount_global") || 0;
  var tierInfo = getRankTier(userId);
  if (tierInfo.pct > Number(autoDiscountPercent || 0)) { autoDiscountPercent = tierInfo.pct; }

  // 🎟 Apply coupon discount (if any was applied for this exact prod/plan) — coupon overrides auto-discount
  var appliedCouponCode = User.getProperty("applied_coupon_" + prodIdx + "_" + planIdx);
  var couponDiscountPercent = 0;
  if (appliedCouponCode) {
    var couponRec0 = Bot.getProperty("coupon_" + appliedCouponCode);
    if (couponRec0 && couponRec0.discountPercent) {
      couponDiscountPercent = couponRec0.discountPercent;
      price = Number((originalPrice * (1 - couponDiscountPercent / 100)).toFixed(2));
    }
    User.setProperty("applied_coupon_" + prodIdx + "_" + planIdx, null, "string");
  } else if (autoDiscountPercent > 0) {
    couponDiscountPercent = autoDiscountPercent;
    price = Number((originalPrice * (1 - autoDiscountPercent / 100)).toFixed(2));
  }

  // 🛡️ Safety re-check: is the balance still sufficient (race-condition guard)
  var unifiedBal = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return resBal + bonusBal;
  })();

  if (unifiedBal < price) {
    Api.sendMessage({
      chat_id: chatId,
      text: "⚠️ <b>Balance is too low now.</b> Please try again.",
      parse_mode: "HTML"
    });
    return;
  }

  // =====================================================
  // 🔑 STEP 0 — MANUAL STOCK FIRST CHECK (✅ NEW)
  // If the admin has already added a key manually, deliver that one directly
  // and do NOT call the PAID EXTERNAL API at all, so that the
  // "2 keys spent for 1 available key" (1 manual + 1 wasted API buy)
  // bug never happens. The API is called only when manual stock is empty.
  // =====================================================
  var pDaysNumOnly = cleanPlanDays;
  // Every place the add-key script can save stock (checked in this order)
  var stockKeyList = [
    "manual_keys_" + cleanProdName + "_" + pDaysNumOnly,
    "stock_" + product.name.trim() + "_" + pDaysNumOnly + "_Day",
    "stock_" + product.name.trim() + "_" + pDaysNumOnly,
    "stock_" + prodIdx + "_" + planIdx,
    // keys added before the fix may have been saved with a "d" suffix (e.g. 1d_Day)
    "stock_" + product.name.trim() + "_" + pDaysNumOnly + "d_Day",
    "stock_" + product.name.trim() + "_" + pDaysNumOnly + "d"
  ];
  function readStockList(k) {
    var v = Bot.getProperty(k);
    if (typeof v === "string") {
      try { v = JSON.parse(v); } catch (e) { v = v.split("\n"); }
    }
    if (!Array.isArray(v)) return [];
    return v.map(function (x) { return String(x).trim(); }).filter(Boolean);
  }
  var manualStock = [];
  for (var sk = 0; sk < stockKeyList.length; sk++) {
    var found = readStockList(stockKeyList[sk]);
    if (found.length > 0) { manualStock = found; break; }
  }

  if (Array.isArray(manualStock) && manualStock.length > 0) {
    var generatedKey = manualStock[0];
    // Remove the used key from every saved copy so it cannot be sold twice
    for (var sk2 = 0; sk2 < stockKeyList.length; sk2++) {
      var copy = readStockList(stockKeyList[sk2]);
      var at = copy.indexOf(generatedKey);
      if (at > -1) {
        copy.splice(at, 1);
        Bot.setProperty(stockKeyList[sk2], copy, "json");
      }
    }

    notifyDiscordSale({ product: product.name, plan: (plan && plan.durationDisplay) ? plan.durationDisplay : cleanPlanDays + " Days", price: price, user: userId, source: "manual stock" });
    updateDashboard({ type: "sale", price: price, user: userId, product: product.name, plan: plan.durationDisplay || cleanPlanDays, key: generatedKey });
    var purchaseRec = { date: new Date().toISOString(), product: product.name, plan: plan.durationDisplay || (cleanPlanDays + " Days"), price: price, key: generatedKey };
    recordPurchase(userId, purchaseRec);
    sendReceipt(userId, purchaseRec, tierInfo);
    // 💰 Deduct balance + record purchase (same accounting as API path)
    Libs.ResourcesLib.userRes("balance").add(-price);
    var pastSpent2 = Bot.getProperty("total_spent_by_" + userId) || 0;
    Bot.setProperty("total_spent_by_" + userId, Number(pastSpent2) + price, "number");

    var keysHistory2 = User.getProperty("my_purchased_keys") || [];
    keysHistory2.push({
      product: String(product.name).trim(),
      product_id: product.id || null,
      days: pDaysNumOnly,
      price: price,
      key: generatedKey,
      date: new Date().toLocaleDateString()
    });
    User.setProperty("my_purchased_keys", keysHistory2, "json");

    var remainingBal2 = Libs.ResourcesLib.userRes("balance").value().toFixed(2);

    // ✅ NEW: An automatic "Join Updates" button is attached with the key (if the admin set a link)
    var updateLinkForKey = Bot.getProperty("update_channel_link");
    var keyDeliveryButtons = [[{ text: "📋 Copy Key", copy_text: { text: generatedKey } }]];
    if (updateLinkForKey) {
      keyDeliveryButtons.push([{ text: "📥 Join Updates", url: updateLinkForKey, style: "primary", icon_custom_emoji_id: "6091571559233755994" }]);
    }
    keyDeliveryButtons.push([{ text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "5893163582194978381" }]);
    var keyDeliveryMarkup = JSON.stringify({ inline_keyboard: keyDeliveryButtons });

    var deliverText2 = "<blockquote>" +
      "<tg-emoji emoji-id='5350447674971660988'>✅</tg-emoji> <b>PURCHASE SUCCESSFUL!</b>\n\n" +
      "<tg-emoji emoji-id='6147767796097884213'>📦</tg-emoji> <b>Product:</b> <code>" + String(product.name).trim() + "</code>\n" +
      "<tg-emoji emoji-id='6284816251143331422'>🗝</tg-emoji> <b>Validity:</b> <code>" + durationDisplay + "</code>\n" +
      "<tg-emoji emoji-id='5352825278672412291'>👆</tg-emoji> <b>Your Key:</b> <code>" + generatedKey + "</code>\n\n" +
      "━━━━━ <tg-emoji emoji-id='6147934084346682063'>#⃣</tg-emoji> <b>BALANCE DETAILS</b> ━━━━━\n" +
      "<b>🏅 Rank:</b> " + tierInfo.name + " (" + tierInfo.pct + "% off)\n" +
      "<tg-emoji emoji-id='6195037488898121775'>✨</tg-emoji> <b>Total Invest:</b> LKR " + price.toFixed(2) + "\n" +
      "<tg-emoji emoji-id='5409048419211682843'>💵</tg-emoji> <b>New Wallet Balance:</b> LKR " + remainingBal2 + "\n\n" +
      "<i>Enjoy your purchase. <tg-emoji emoji-id='6057881002540274780'>🥳</tg-emoji></i>" +
      "</blockquote>";

    if (request && request.message) {
      try {
        Api.editMessageText({
          chat_id: String(chatId),
          message_id: Number(request.message.message_id),
          text: deliverText2,
          parse_mode: "HTML",
          reply_markup: keyDeliveryMarkup
        });
      } catch (e) {
        Api.sendMessage({ chat_id: chatId, text: deliverText2, parse_mode: "HTML", reply_markup: keyDeliveryMarkup });
      }
    } else {
      Api.sendMessage({ chat_id: chatId, text: deliverText2, parse_mode: "HTML", reply_markup: keyDeliveryMarkup });
    }

    var adminId3 = "8500341403";
    Api.sendMessage({
      chat_id: adminId3,
      text: "🔔 <b>NEW PURCHASE DELIVERED (MANUAL STOCK)</b> ✔️\n\n" +
            "👤 <b>Buyer:</b> " + (user.first_name || "User") + " (<code>" + userId + "</code>)\n" +
            "📦 <b>Product:</b> " + String(product.name).trim() + "\n" +
            "⏳ <b>Plan:</b> " + durationDisplay + "\n" +
            "💸 <b>Price Deducted:</b> LKR " + price.toFixed(2) + "\n" +
            "💳 <b>User Remaining Bal:</b> LKR " + remainingBal2 + "\n" +
            "🔑 <b>Key:</b> <code>" + generatedKey + "</code>\n\n" +
            "<i>✅ Delivered from manual stock — external paid API call was SKIPPED.</i>",
      parse_mode: "HTML"
    });

    var qId0 = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
    if (qId0) {
      try { Api.answerCallbackQuery({ callback_query_id: String(qId0), text: "✅ Key Delivered!", show_alert: false }); } catch (e) {}
    }

    return; // 🚫 STOP — external API was not called at all
  }

  var webProductId = String(product.id || "PID_ID").trim();
  var prodNameLower = String(product.name).toLowerCase();

  var durationParam = (planUnit === "hour") ? (cleanPlanDays + " Hour" + (Number(cleanPlanDays) === 1 ? "" : "s")) :
                       (planUnit === "minute") ? (cleanPlanDays + " Minute" + (Number(cleanPlanDays) === 1 ? "" : "s")) :
                       cleanPlanDays + " Days";
  var rawPlanName = plan.name || plan.title || plan.name_on_website || "";

  if (rawPlanName.trim() !== "" && isNaN(rawPlanName)) {
    durationParam = rawPlanName.trim();
  } else {
    if (prodNameLower.indexOf("pato") > -1) {
      durationParam = cleanPlanDays + " DaYs All Colours Mix";
    } else if (prodNameLower.indexOf("prime") > -1 || prodNameLower.indexOf("hook") > -1) {
      durationParam = (cleanPlanDays === "7") ? "7 Days NonRoot" : cleanPlanDays + " Days Nonroot";
    } else if (prodNameLower.indexOf("nonroot") > -1 || prodNameLower.indexOf("non root") > -1) {
      durationParam = cleanPlanDays + " DaYs NONROOT";
    } else if (prodNameLower.indexOf("all android") > -1 || prodNameLower.indexOf("mix") > -1) {
      durationParam = cleanPlanDays + " DaYs All Colours Mix";
    } else {
      durationParam = cleanPlanDays + " Days";
    }
  }

  var postFieldsString = "api_key=" + encodeURIComponent("a12cf270b9df76b981974a120ce1dd7f") +
                         "&action=" + encodeURIComponent("buy") +
                         "&product_id=" + encodeURIComponent(webProductId) +
                         "&duration=" + encodeURIComponent(durationParam);

  var apiHeaders = {
    "Content-Type": "application/x-www-form-urlencoded",
    "x-master-key": "a7f3e8b2c9d1f4a6b8c2d5e9f1a3b6c8"
  };

  User.setProperty("last_pending_price", Number(price), "number");
  User.setProperty("last_pending_prod_id", webProductId, "string");
  User.setProperty("last_pending_prod_name", String(product.name).trim(), "string");
  User.setProperty("last_pending_plan_days", cleanPlanDays, "string");
  User.setProperty("last_pending_plan_unit", planUnit, "string");

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;

  var processingText = "<tg-emoji emoji-id='6147936236125298267'>⏳</tg-emoji> <b>Processing your order... please wait!</b>";
  if (request && request.message) {
    try {
      Api.editMessageText({
        chat_id: String(chatId),
        message_id: Number(request.message.message_id),
        text: processingText,
        parse_mode: "HTML"
      });
      // ✅ FIX: save the ID of this "Processing..." message so that when the key is delivered
      // it is deleted — before, it always stayed stuck in the chat.
      Bot.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
      User.setProperty("gen_msg_id_" + userId, request.message.message_id, "string");
    } catch (e) {
      var pm1 = Api.sendMessage({ chat_id: chatId, text: processingText, parse_mode: "HTML" });
      try {
        var pmid1 = (pm1 && pm1.result && pm1.result.message_id) ? pm1.result.message_id : (pm1 && pm1.message_id ? pm1.message_id : null);
        if (pmid1) { Bot.setProperty("gen_msg_id_" + userId, pmid1, "string"); User.setProperty("gen_msg_id_" + userId, pmid1, "string"); }
      } catch (e2) {}
    }
  } else {
    var pm2 = Api.sendMessage({ chat_id: chatId, text: processingText, parse_mode: "HTML" });
    try {
      var pmid2 = (pm2 && pm2.result && pm2.result.message_id) ? pm2.result.message_id : (pm2 && pm2.message_id ? pm2.message_id : null);
      if (pmid2) { Bot.setProperty("gen_msg_id_" + userId, pmid2, "string"); User.setProperty("gen_msg_id_" + userId, pmid2, "string"); }
    } catch (e2) {}
  }

  // Remember who placed this order so the result handlers can reply to them
  Bot.setProperty("last_order_info", JSON.stringify({
    user_id: String(userId),
    first_name: (typeof user !== "undefined" && user && user.first_name) ? user.first_name : "Unknown",
    prod_name: product.name,
    plan_days: cleanPlanDays,
    price: price
  }), "string");
  Bot.setProperty("last_order_chat", String(chatId), "string");
  Bot.setProperty("last_order_user", String(userId), "string");

  HTTP.post({
    url: "https://xyzcheats.com/api/reseller_v1.php",
    body: postFieldsString,
    headers: apiHeaders,
    success: "/onWebKeyReceive",
    error: "/onWebKeyError"
  });

  if (queryId) {
    try {
      Api.answerCallbackQuery({
        callback_query_id: String(queryId),
        text: "⏳ Processing your order... Please wait!",
        show_alert: false
      });
    } catch (e) {}
  }

} catch (e) {
  var errChatId = (typeof chat !== "undefined" && chat && chat.chatid) ? chat.chatid : null;
  if (errChatId) {
    try { Api.sendMessage({ chat_id: errChatId, text: "❌ <b>Error:</b> <code>" + e.message + "</code>", parse_mode: "HTML" }); } catch (fatal) {}
  }
}