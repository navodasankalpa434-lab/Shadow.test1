/**#command
name: /start
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Role: Admin, Reseller, Customer (unverified shows as Visitor)
function roleFor(id) {
  id = String(id);
  if (id === "8500341403") { return "🛡 Admin"; }
  var cl = Bot.getProperty("co_admin_list") || [];
  if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e) { cl = []; } }
  var isAdmin = String(Bot.getProperty("co_admin_" + id)) === "true" || (Array.isArray(cl) && cl.map(String).indexOf(id) !== -1);
  if (isAdmin) { return "🛡 Admin"; }
  var rl = Bot.getProperty("resellers_list") || [];
  if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e2) { rl = []; } }
  var isRes = String(Bot.getProperty("is_reseller_" + id)) === "true" ||
              (Array.isArray(rl) && rl.some(function (x) { return String(x && x.id !== undefined ? x.id : x) === id; }));
  if (isRes) { return "🔴 Reseller"; }
  var vv = Bot.getProperty("verified_" + id);
  if (!(vv === true || String(vv) === "true")) { return "👀 Visitor"; }
  return "✅ Customer";
}
// Rank: the best top-up tier the customer has reached
function rankFor(id) {
  var total = Number(Bot.getProperty("topup_total_" + id) || 0);
  var tiers = Bot.getProperty("topup_tiers") || [];
  if (typeof tiers === "string") { try { tiers = JSON.parse(tiers); } catch (e) { tiers = []; } }
  if (!Array.isArray(tiers)) { tiers = []; }
  var best = null;
  for (var t = 0; t < tiers.length; t++) {
    if (total >= Number(tiers[t].min) && (!best || Number(tiers[t].pct) > Number(best.pct))) { best = tiers[t]; }
  }
  return best ? (best.name + " · " + best.pct + "% off") : "None · 0% off";
}
// Menu header: role, verification and rank
function statusBlockFor() {
  var sid = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
  var vv = Bot.getProperty("verified_" + sid);
  var ver = (vv === true || String(vv) === "true") ? "✅ Verified account" : "🔴 Not verified (tap Verify Account)";
  return "<blockquote><b>" + roleFor(sid) + "</b>\n" + ver + "\n🏅 Rank: " + rankFor(sid) + "</blockquote>\n";
}
function salesLogAdd(entry) {
  var slog = Bot.getProperty("sales_log") || [];
  if (typeof slog === "string") { try { slog = JSON.parse(slog); } catch (e) { slog = []; } }
  if (!Array.isArray(slog)) { slog = []; }
  slog.push(entry);
  if (slog.length > 2000) { slog = slog.slice(slog.length - 2000); }
  Bot.setProperty("sales_log", slog, "json");
}
// Discord image: a direct https link set with /settings discord image LINK (or the menu photo link)
function discordImgObj() {
  var u = String(Bot.getProperty("discord_image") || Bot.getProperty("menu_photo_url") || "");
  return (u.indexOf("https://") === 0) ? { url: u } : undefined;
}
// Live Discord dashboard: one message, updated on every sale, top-up and wallet change
function dashInc(key, amt) { Bot.setProperty(key, String(Number(Bot.getProperty(key) || 0) + Number(amt || 0)), "string"); }
function updateDashboard(evt) {
  try {
    if (evt && evt.type === "sale") { dashInc("dash_sales_count", 1); dashInc("dash_sales_total", evt.price);
      if (evt.user) { dashInc("dash_orders_" + evt.user, 1); dashInc("dash_spent_" + evt.user, evt.price); } }
    if (evt && evt.type === "sale") { salesLogAdd({ date: new Date().toISOString(), user: String(evt.user || ""), product: evt.product || "", plan: evt.plan || "", price: evt.price, key: evt.key || "" }); }
    if (evt && evt.type === "topup") { dashInc("dash_topup_count", 1); dashInc("dash_topup_total", evt.amount); }
    if (evt && evt.type === "wallet") { dashInc("dash_wallet_count", 1); dashInc("dash_wallet_total", evt.amount); }
    var hook = String(Bot.getProperty("discord_webhook") || "");
    if (hook.indexOf("https://discord.com/api/webhooks/") !== 0 && hook.indexOf("https://discordapp.com/api/webhooks/") !== 0) { return; }
    var ul = Bot.getProperty("all_users_list") || [];
    if (typeof ul === "string") { try { ul = JSON.parse(ul); } catch (e) { ul = []; } }
    if (!Array.isArray(ul)) { ul = []; }
    var rl = Bot.getProperty("resellers_list") || [];
    if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e2) { rl = []; } }
    var rIds = Array.isArray(rl) ? rl.map(function (x) { return String(x && x.id !== undefined ? x.id : x); }) : [];
    var cl = Bot.getProperty("co_admin_list") || [];
    if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e3) { cl = []; } }
    var cIds = Array.isArray(cl) ? cl.map(String) : [];
    var rows = [], walletTotal = 0, verifiedCount = 0, resellerCount = 0;
    for (var i = 0; i < ul.length; i++) {
      var uid = String(ul[i]);
      if (uid === "8500341403") { continue; }
      var bal = 0;
      try { bal = Number(Libs.ResourcesLib.anotherUserRes("balance", uid).value() || 0); } catch (be) { bal = 0; }
      var vv = Bot.getProperty("verified_" + uid);
      var ver = (vv === true || String(vv) === "true");
      var isR = rIds.indexOf(uid) !== -1 || !!Bot.getProperty("is_reseller_" + uid);
      var role = uid === "8500341403" ? "👑" : (cIds.indexOf(uid) !== -1 ? "🛡" : (isR ? "🔴" : "👤"));
      walletTotal += bal; if (ver) { verifiedCount++; } if (isR) { resellerCount++; }
      rows.push({ id: uid, bal: bal, ver: ver, role: role, tu: Number(Bot.getProperty("topup_total_" + uid) || 0),
                  ord: Number(Bot.getProperty("dash_orders_" + uid) || 0), spent: Number(Bot.getProperty("dash_spent_" + uid) || 0) });
    }
    rows.sort(function (a, b) { return b.bal - a.bal; });
    var lines = rows.slice(0, 20).map(function (r) {
      return r.role + " `" + r.id + "` " + (r.ver ? "✅" : "⬜") + "  💳 " + r.bal + "  ·  💰 top-up " + r.tu + "  ·  🛒 " + r.ord + " (" + r.spent + ")";
    });
    var stockKeys = 0;
    var sprods = Bot.getProperty("stored_products") || [];
    if (typeof sprods === "string") { try { sprods = JSON.parse(sprods); } catch (se) { sprods = []; } }
    if (!Array.isArray(sprods)) { sprods = []; }
    for (var si = 0; si < sprods.length; si++) {
      var sp = sprods[si];
      if (!sp || !sp.name) { continue; }
      var spl = Array.isArray(sp.plans) ? sp.plans : [];
      for (var sj = 0; sj < spl.length; sj++) {
        var sd = String(spl[sj].days).replace(/[^0-9.]/g, "");
        var sn = String(sp.name).trim();
        var scands = ["manual_keys_" + sn.toUpperCase() + "_" + sd, "stock_" + sn + "_" + sd + "_Day",
                      "stock_" + sn + "_" + sd, "stock_" + si + "_" + sj, "stock_" + sn + "_" + sd + "d_Day"];
        for (var sc = 0; sc < scands.length; sc++) {
          var sv = Bot.getProperty(scands[sc]);
          if (typeof sv === "string") { try { sv = JSON.parse(sv); } catch (se2) { sv = sv.split("\n"); } }
          if (Array.isArray(sv) && sv.length > 0) {
            stockKeys += sv.filter(function (k) { return String(k).trim() !== ""; }).length;
            break;
          }
        }
      }
    }
    var now = new Date().toISOString().replace("T", " ").substring(0, 16) + " UTC";
    var embeds = [
      { title: "📊 LIVE DASHBOARD", color: 3447003, thumbnail: discordImgObj(), description: "Updated: **" + now + "**",
        fields: [
          { name: "📦 Keys in stock", value: "**" + stockKeys + "** available", inline: true },
          { name: "🛒 Sales", value: "**" + Number(Bot.getProperty("dash_sales_count") || 0) + "** orders\nLKR " + Number(Bot.getProperty("dash_sales_total") || 0), inline: true },
          { name: "💳 Top-ups", value: "**" + Number(Bot.getProperty("dash_topup_count") || 0) + "** approved\nLKR " + Number(Bot.getProperty("dash_topup_total") || 0), inline: true },
          { name: "👥 Users", value: "**" + rows.length + "** total\n✅ " + verifiedCount + " verified", inline: true },
          { name: "🏦 Wallet total", value: "LKR " + walletTotal, inline: true },
          { name: "🔴 Resellers", value: "**" + resellerCount + "**", inline: true }
        ] },
      { title: "👤 PROFILES (top 20 by balance)", color: 3066993,
        description: lines.length ? lines.join("\n") : "No profiles yet." }
    ];
    var payload = JSON.stringify({ username: "Store Dashboard", embeds: embeds });
    var hdr = { "Content-Type": "application/json" };
    var mid = String(Bot.getProperty("dash_message_id") || "");
    if (mid && typeof HTTP.patch === "function") {
      HTTP.patch({ url: hook + "/messages/" + mid, body: payload, headers: hdr, success: "/discord_ok", error: "/dash_error" });
    } else {
      HTTP.post({ url: hook + "?wait=true", body: payload, headers: hdr, success: "/dash_saved", error: "/dash_error" });
    }
  } catch (e) {}
}
// Status line shown at the top of the menu: role + verified / not verified
var SHOP_NAME = String(Bot.getProperty("store_name") || "Shadow and Scrapy Panel Store").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try { 
  var adminId = Bot.getProperty("owner_id") || "8500341403";
  var userId = String(user.telegramid);

  // ⭐ TELEGRAM STARS — fallback event detection (payment events may route here
  // generically depending on the platform, so we check and delegate explicitly)
  if (request && request.pre_checkout_query) {
    Bot.run({ command: "/onPreCheckoutQuery" });
    return;
  }
  if (request && request.message && request.message.successful_payment) {
    Bot.run({ command: "/onSuccessfulPayment" });
    return;
  }
  
  // Safe variable fallbacks for BJS environment
  var msgText = (typeof message !== 'undefined' && message) ? message.trim() : "";
  // ✅ FIXED: previously an undefined global variable named "data" was being read, which was always
  // empty — so any callback button that called "/start" (such as "Back to
  // Menu") failed silently and the user got no response at all.
  var callbackData = (request && request.callback_query && request.callback_query.data) ? request.callback_query.data : "";

  // =====================================================
  // 🛠 MAINTENANCE MODE GATE (✅ NEW)
  // Owners and Co-Admins always pass through; everyone else sees the premium screen.
  // =====================================================
  var isMaintenanceOn = Bot.getProperty("maintenance_mode") || false;
  var isStaffUser = (userId === adminId) || isCoAdminId(userId);
  var isOwnerOrCoAdmin = isStaffUser;

  if (isMaintenanceOn && !isOwnerOrCoAdmin) {
    Bot.sendMessage(
      "<blockquote><tg-emoji emoji-id='6100657257605763582'>🛠</tg-emoji> <b>BOT UNDER MAINTENANCE</b></blockquote>\n\n" +
      "<i>We are making some premium improvements! Please try again in a little while.</i>\n\n" +
      "<tg-emoji emoji-id='6100170496077204999'>👑</tg-emoji> <i>Dhanyawad for your patience!</i>",
      { parse_mode: "HTML" }
    );
    return;
  }

  // ✅ NEW: Maintenance has just ended — give this user the premium "We're Back!" welcome once
  var maintenanceRemovedAt = Bot.getProperty("maintenance_removed_at");
  var userSeenMaintenanceRemoved = User.getProperty("seen_maintenance_removed_at");
  if (!isMaintenanceOn && maintenanceRemovedAt && userSeenMaintenanceRemoved !== maintenanceRemovedAt) {
    User.setProperty("seen_maintenance_removed_at", maintenanceRemovedAt, "number");
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "<blockquote><tg-emoji emoji-id='6102856637343600044'>✅</tg-emoji> <b>MAINTENANCE REMOVED — WE'RE BACK!</b></blockquote>\n\n" +
            "<tg-emoji emoji-id='6091571559233755994'>🚀</tg-emoji> <i>The bot is live again with the fully automated system!</i>\n" +
            "<i>Tap /start to continue, or Buy Now to grab your keys instantly.</i>",
      parse_mode: "HTML",
      reply_markup: JSON.stringify({
        inline_keyboard: [[
          { text: "Buy Now", callback_data: "/buy_hack", style: "success", icon_custom_emoji_id: "6312263493051489212" }
        ]]
      })
    });
  }
  
  var currentStep = User.getProperty("add_product_step");
  var isAwaitingBroadcast = User.getProperty("awaiting_broadcast_data");

  // 🎨 PREMIUM CUSTOM EMOJIS DEFINITION (Fixed with escaped double quotes)
  var EMJ_VERIFIED_CHECK = "<tg-emoji emoji-id=\"5875465628285931233\">✔️</tg-emoji>";
  var EMJ_CROWN          = "<tg-emoji emoji-id=\"6311975081702597046\">👑</tg-emoji>";
  var EMJ_DROP           = "<tg-emoji emoji-id=\"6080228009439141516\">💧</tg-emoji>";
  var EMJ_CHECK          = "<tg-emoji emoji-id=\"6080214566191505147\">✅</tg-emoji>";
  var EMJ_ROCKET         = "<tg-emoji emoji-id=\"6091571559233755994\">🚀</tg-emoji>";
  var EMJ_RADAR          = "<tg-emoji emoji-id=\"6093591495237967001\">📡</tg-emoji>";
  var EMJ_STAR           = "<tg-emoji emoji-id=\"6093677128295914531\">✨</tg-emoji>";
  var EMJ_RED_DOT        = "<tg-emoji emoji-id=\"6093854128193152827\">🔴</tg-emoji>";
  
  // the special premium custom emoji you requested for Access Granted
  var EMJ_NEW_ACCESS     = "<tg-emoji emoji-id=\"5875465628285931233\">✔️</tg-emoji>";

  // ==========================================
  // 🏠 HELPER: DIRECTLY SEND MAIN SHOP MENU
  // (Bot.runCommand("/menu") is unreliable in BJS -> inline it instead)
  // ==========================================
  function sendMainMenu() {
    try {
      // ✅ FIXED: now reads from the same wallet store that purchase flows use
      // (Libs.ResourcesLib "balance" resource + admin bonus balance), so the balance looks the same everywhere.
      var userBal = (function() {
        var resBal = 0;
        try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
        var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
        return (resBal + bonusBal).toFixed(2);
      })();

      var EMJ_HEADER_ROCKET = "<tg-emoji emoji-id='5217822164362739968'>🚀</tg-emoji>";
      var EMJ_HEADER_NEW    = "<tg-emoji emoji-id='6082603117763894396'>✨</tg-emoji>";
      var EMJ_HEADER_SHIELD = "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji>";

      var MSG_EMJ_STORE     = "<tg-emoji emoji-id='5866053971960929280'>🛒</tg-emoji>";
      var MSG_EMJ_FFID      = "<tg-emoji emoji-id='5334890573281114250'>🎮</tg-emoji>";
      var MSG_EMJ_PROFILE   = "<tg-emoji emoji-id='5260399854500191689'>🔰</tg-emoji>";
      var MSG_EMJ_ADDBAL    = "<tg-emoji emoji-id='6147815702163102310'>✨</tg-emoji>";
      var MSG_EMJ_HISTORY   = "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji>";
      var MSG_EMJ_LUDO      = "<tg-emoji emoji-id='5371043439020353782'>🎲</tg-emoji>";
      var MSG_EMJ_TUTORIAL  = "<tg-emoji emoji-id='5258077307985207053'>📹</tg-emoji>";
      var MSG_EMJ_PROOF     = "<tg-emoji emoji-id='5330237710655306682'>✅</tg-emoji>";
      var MSG_EMJ_SUPPORT   = "<tg-emoji emoji-id='5436113877181941026'>🔰</tg-emoji>";

      var EMJ_PREMIUM_MENU  = "<tg-emoji emoji-id='5406745015365943482'>✨</tg-emoji>";
      var EMJ_YOUR_BALANCE  = "<tg-emoji emoji-id='5231200819986047254'>💰</tg-emoji>";
      var EMJ_GET_STARTED   = "<tg-emoji emoji-id='6057415823222379852'>👇</tg-emoji>";

      var welcomeMessage =
        "<b>" + SHOP_NAME + "</b>\n" +
        "━━━━━━━━━━━━━━━━━━━━\n" +
        "Welcome back, <b>" + ((user && user.first_name) ? user.first_name : "there") + "</b>\n\n" +
        "<b>Free Fire Panels</b>  ·  Instant delivery\n" +
        "Secure  ·  Verified  ·  24/7 Support\n" +
        "━━━━━━━━━━━━━━━━━━━━\n" +
        "Balance   <code>LKR " + userBal + "</code>\n" +
        "━━━━━━━━━━━━━━━━━━━━\n\n" +
        "<i>Select an option below.</i>";

      var multiColorKeyboard = [
        [{ text: "Shop Now", callback_data: "/buy_hack", style: "primary", icon_custom_emoji_id: "5866053971960929280" }],
        [
          { text: "Profile", callback_data: "/profile", style: "primary", icon_custom_emoji_id: "6145572393499762737" },
          { text: "Add Top Up", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "5409048419211682843" }
        ],
        [
          { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6215386799133433653" },
          { text: "How to use", callback_data: "/how", style: "danger", icon_custom_emoji_id: "6192842983948162969" }
        ],
        [{ text: "Payment Proofs", url: "https://chat.whatsapp.com/JR898GeUCjiKPXF25jDW2D?s=cl&p=a&mlu=4&ilr=4", style: "success", icon_custom_emoji_id: "5330237710655306682" }],
        [{ text: "Support", callback_data: "/support", style: "danger", icon_custom_emoji_id: "6267129592998270736" }]
      ];

      if (Bot.getProperty("reseller_system_enabled") && !Bot.getProperty("is_reseller_" + userId)) {
        multiColorKeyboard.push([
          { text: "Reseller Upgrade", callback_data: "/reseller_upgrade", style: "success", icon_custom_emoji_id: "6102856637343600044" }
        ]);
      }

      // Shop banner: photo, text and buttons are sent together as ONE message
      var MENU_PHOTO_URL = String(Bot.getProperty("menu_photo_file_id") || Bot.getProperty("menu_photo_url") || "");
      var menuKb = JSON.stringify({ inline_keyboard: multiColorKeyboard });
      var menuText = statusBlockFor() + String(welcomeMessage);
      var photoOk = false;
      if (MENU_PHOTO_URL.length > 0 && (MENU_PHOTO_URL.indexOf("http") === 0 || /^[A-Za-z0-9_\-]{20,}$/.test(MENU_PHOTO_URL)) && menuText.replace(/<[^>]+>/g, "").length <= 1000) {
        try {
          Api.sendPhoto({ chat_id: chat.chatid, photo: MENU_PHOTO_URL, caption: menuText, parse_mode: "HTML", reply_markup: menuKb });
          photoOk = true;
        } catch (photoErr) { photoOk = false; }
      }
      if (!photoOk) {
        Api.sendMessage({ chat_id: chat.chatid, text: menuText, parse_mode: "HTML", reply_markup: menuKb });
      }
    } catch (menuErr) {
      Bot.sendMessage("🛑 <b>Menu Send Error:</b> <code>" + menuErr.message + "</code>", { parse_mode: "HTML" });
    }
  }

  // [Auto-Track User] to track the user in the list
  var trackedUsers = Bot.getProperty("all_users_list") || [];
  if (!trackedUsers.includes(userId)) {
    trackedUsers.push(userId);
    Bot.setProperty("all_users_list", trackedUsers, "json");
  }

  // 🛡️ [ANTI-DUPLICATE CHECK] If the user is already verified, send them straight to the menu
  // ✅ FIXED: previously only an exact "msgText === '/start'" ya "callbackData === '/trigger_contact_popup'"
  // match sent the menu. Any button whose callback_data called "/start"
  // (such as "Back to Menu" after cancel-order), the match failed and the user got
  // no response. This check is now robust — as long as it is not a real contact-share
  // event and the admin is not in a mid-flow step, a verified user always gets the menu.
  var couponGenStep = User.getProperty("coupon_gen_step");
  var awaitingCouponFor = User.getProperty("awaiting_coupon_for");
  var isAlreadyVerified = Bot.getProperty("verified_" + userId);
  if (user && user.telegramid) {
    Bot.setProperty("name_" + userId, ((user.first_name || "") + " " + (user.last_name || "")).trim() || "No Name", "string");
    Bot.setProperty("username_" + userId, user.username ? "@" + user.username : "N/A", "string");
  }
  var isContactShareEvent = !!(request && request.contact && request.contact.user_id);
  var isAdminMidFlow = (isStaffUser && (currentStep || isAwaitingBroadcast || couponGenStep ||
    User.getProperty("addbal_step") || User.getProperty("rembal_step") || User.getProperty("checkbal_step")));
  var isUserMidFlow = !!awaitingCouponFor;
  // ✅ NEW: Whatever "/start"/"/START"/"/Start" the user typed, after the menu appears
  // delete that typed command message so the chat stays clean.
  if (msgText.toLowerCase() === "/start" && request && request.message_id) {
    try { Api.deleteMessage({ chat_id: chat.chatid, message_id: request.message_id }); } catch (delStartErr) {}
  }

  // ==========================================
  // 💳 MODULE: MANUAL TOP-UP (bank / cash receipts)
  // ==========================================
  if (callbackData.indexOf("/rdview_") === 0) {
    if (!isStaffUser) { return; }
    Bot.run({ command: "/resellerdata", options: { message: callbackData } });
    return;
  }
  if (callbackData.indexOf("/addplan_") === 0) {
    Bot.run({ command: "/addplan", options: { message: callbackData } });
    return;
  }
  if (callbackData === "/topup_cancel") {
    User.setProperty("topup_step", "", "string");
    User.setProperty("topup_file", "", "string");
    Api.sendMessage({ chat_id: chat.chatid, text: "❌ Top-up cancelled.", parse_mode: "HTML" });
    return;
  }
  if (callbackData.indexOf("/topup_ok_") === 0 || callbackData.indexOf("/topup_no_") === 0) {
    if (!isStaffUser) { return; }
    var tDecision = (callbackData.indexOf("/topup_ok_") === 0) ? "ok" : "no";
    var tReqId = callbackData.replace(/^\/topup_(ok|no)_/, "");
    var tReq = {};
    try { tReq = JSON.parse(Bot.getProperty("topup_req_" + tReqId) || "{}"); } catch (tpE) { tReq = {}; }
    if (!tReq.user_id) {
      Api.sendMessage({ chat_id: chat.chatid, text: "❌ Top-up request not found.", parse_mode: "HTML" });
      return;
    }
    if (tReq.status !== "pending") {
      Api.sendMessage({ chat_id: chat.chatid, text: "ℹ️ This request was already " + tReq.status + ".", parse_mode: "HTML" });
      return;
    }
    if (tDecision === "ok") {
      var tRes = Libs.ResourcesLib.anotherUserRes("balance", tReq.user_id);
      if (typeof tRes.add === "function") { tRes.add(Number(tReq.amount)); }
      else { tRes.set(Number(tRes.value() || 0) + Number(tReq.amount)); }
      var tNewBal = Libs.ResourcesLib.anotherUserRes("balance", tReq.user_id).value();
      Bot.setProperty("topup_total_" + tReq.user_id, String(Number(Bot.getProperty("topup_total_" + tReq.user_id) || 0) + Number(tReq.amount)), "string");
      updateDashboard({ type: "topup", amount: tReq.amount, user: tReq.user_id });
      tReq.status = "approved";
      Bot.setProperty("topup_req_" + tReqId, JSON.stringify(tReq), "string");
      try {
        Api.sendMessage({ chat_id: tReq.user_id, parse_mode: "HTML",
          text: "<blockquote>✅ <b>Top-up approved</b>\nAdded: <b>LKR " + tReq.amount + "</b>\nYour balance: <code>LKR " + tNewBal + "</code></blockquote>" });
      } catch (tnE) {}
      Api.sendMessage({ chat_id: chat.chatid, parse_mode: "HTML",
        text: "✅ <b>Approved</b> top-up #" + tReqId + ": LKR " + tReq.amount + " added to <code>" + tReq.user_id + "</code>." });
    } else {
      tReq.status = "rejected";
      Bot.setProperty("topup_req_" + tReqId, JSON.stringify(tReq), "string");
      try {
        Api.sendMessage({ chat_id: tReq.user_id, parse_mode: "HTML",
          text: "<blockquote>❌ <b>Top-up rejected</b>\nPlease check your payment and reference, then try again or contact support.</blockquote>" });
      } catch (tnE2) {}
      Api.sendMessage({ chat_id: chat.chatid, parse_mode: "HTML",
        text: "❌ <b>Rejected</b> top-up #" + tReqId + "." });
    }
    return;
  }

  // Owner sends a photo to the bot -> it becomes the start-menu photo (unless a top-up or plan step is waiting)
  if (userId === adminId && request && request.message && request.message.photo && request.message.photo.length &&
      !callbackData && !String(User.getProperty("topup_step") || "") && !String(User.getProperty("addplan_step") || "")) {
    var newMenuPhoto = request.message.photo[request.message.photo.length - 1].file_id;
    Bot.setProperty("menu_photo_file_id", String(newMenuPhoto), "string");
    Api.sendMessage({ chat_id: chat.chatid, parse_mode: "HTML",
      text: "✅ <b>Menu photo saved.</b>\nIt will show on /start and after verification. For Discord, also set a link: <code>/settings discord image LINK</code>. To remove: <code>/settings photo remove</code>" });
    return;
  }

  var bulkTarget = String(User.getProperty("bulkkey_target") || "");
  if (bulkTarget && isStaffUser && request && request.message && !request.callback_query && !callbackData &&
      String(request.message.text || "").charAt(0) !== "/") {
    Bot.run({ command: "/addkeys", options: { message: String(request.message.text) } });
    return;
  }
  var addPlanStep = String(User.getProperty("addplan_step") || "");
  if (addPlanStep && isStaffUser && request && request.message && !request.callback_query && !callbackData &&
      String(request.message.text || "").charAt(0) !== "/") {
    Bot.run({ command: "/addplan", options: { message: String(request.message.text).trim() } });
    return;
  }
  var topupStep = String(User.getProperty("topup_step") || "");
  var tm = (request && request.message && !request.callback_query && !callbackData) ? request.message : null;
  var tmText = (tm && tm.text) ? String(tm.text).trim() : "";
  var tmCaption = (tm && tm.caption) ? String(tm.caption).trim() : "";
  var tmPhoto = (tm && tm.photo && tm.photo.length) ? tm.photo[tm.photo.length - 1].file_id : "";
  var isCmdText = tmText.charAt(0) === "/";
  if (topupStep && tm && !isCmdText && !isContactShareEvent) {
    var tDetails = tmCaption || tmText;
    if (tmPhoto) { User.setProperty("topup_file", tmPhoto, "string"); }
    var tFile = String(User.getProperty("topup_file") || "");

    if (!tFile) {
      Api.sendMessage({ chat_id: chat.chatid, parse_mode: "HTML",
        text: "📸 Please send your <b>receipt photo</b> first." });
      return;
    }
    if (tDetails.indexOf("|") === -1) {
      User.setProperty("topup_step", "waiting_details", "string");
      Api.sendMessage({ chat_id: chat.chatid, parse_mode: "HTML",
        text: "🧾 Receipt received. Now send the <b>reference code and amount</b>.\n<i>Example: REF12345 | 500</i>" });
      return;
    }

    var tParts = tDetails.split("|");
    var tRef = tParts[0].trim();
    var tAmt = parseFloat(String(tParts[1] || "").trim());
    if (tRef.length < 3) {
      Api.sendMessage({ chat_id: chat.chatid, parse_mode: "HTML", text: "❌ Reference code is too short. Try again: <i>REF12345 | 500</i>" });
      return;
    }
    if (isNaN(tAmt) || tAmt <= 0) {
      Api.sendMessage({ chat_id: chat.chatid, parse_mode: "HTML", text: "❌ Invalid amount. Try again: <i>REF12345 | 500</i>" });
      return;
    }

    var tCounter = Number(Bot.getProperty("topup_counter") || 0) + 1;
    Bot.setProperty("topup_counter", String(tCounter), "string");
    var tRecord = { id: String(tCounter), user_id: userId, name: ((user.first_name || "") + " " + (user.last_name || "")).trim() || "No Name",
                    ref: tRef, amount: tAmt, file: tFile, status: "pending" };
    Bot.setProperty("topup_req_" + tCounter, JSON.stringify(tRecord), "string");

    var tAdminText = "💳 <b>NEW TOP-UP REQUEST #" + tCounter + "</b>\n" +
                     "👤 " + tRecord.name + " (<code>" + userId + "</code>)\n" +
                     "🧾 Reference: <code>" + tRef + "</code>\n" +
                     "💰 Amount: <b>LKR " + tAmt + "</b>";
    var tKeys = { inline_keyboard: [[
      { text: "✅ Accept", callback_data: "/topup_ok_" + tCounter, style: "success" },
      { text: "❌ Reject", callback_data: "/topup_no_" + tCounter, style: "danger" }
    ]] };
    try {
      Api.sendPhoto({ chat_id: "8500341403", photo: tFile, caption: tAdminText, parse_mode: "HTML", reply_markup: JSON.stringify(tKeys) });
    } catch (tpSendErr) {
      Api.sendMessage({ chat_id: "8500341403", text: tAdminText, parse_mode: "HTML", reply_markup: JSON.stringify(tKeys) });
    }

    User.setProperty("topup_step", "", "string");
    User.setProperty("topup_file", "", "string");
    Api.sendMessage({ chat_id: chat.chatid, parse_mode: "HTML",
      text: "<blockquote>⏳ <b>Top-up request sent</b>\nReference: <code>" + tRef + "</code>\nAmount: <b>LKR " + tAmt + "</b>\nThe admin will review it shortly.</blockquote>" });
    return;
  }

  if (isAlreadyVerified && !isContactShareEvent && !isAdminMidFlow && !isUserMidFlow) {
    sendMainMenu();
    return;
  }

  // ==========================================
  // ⚡ MODULE: LIVE CONTACT RECEIVER & VERIFIER
  // ==========================================
  if (request && request.contact && request.contact.user_id) {
    if (String(request.contact.user_id) === userId) {
      
      var phoneNumber = request.contact.phone_number;
      var fullName = ((user.first_name || "") + " " + (user.last_name || "")).trim() || "No Name";
      var username = user.username ? "@" + user.username : "No Username";

      // Permanently mark user as verified globally
      Bot.setProperty("verified_" + userId, true, "boolean");
      Bot.setProperty("phone_" + userId, phoneNumber, "string");
      // ✅ NEW: Save the joined date (to show in the Profile section)
      if (!Bot.getProperty("joined_date_" + userId)) {
        Bot.setProperty("joined_date_" + userId, new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }), "string");
      }
      
      // 1. USER DETAILS TO ADMIN
      var adminNotification = 
        "<blockquote><b>" + EMJ_CROWN + " NEW USER VERIFIED " + EMJ_VERIFIED_CHECK + "</b></blockquote>\n" +
        "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
        "<b>👤 Name:</b> " + fullName + "\n" +
        "<b>🆔 User ID:</b> <code>" + userId + "</code>\n" +
        "<b>🌐 Username:</b> " + username + "\n" +
        "<b>📞 Number:</b> <code>" + phoneNumber + "</code>\n" +
        "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>";

      Api.sendMessage({
        chat_id: adminId,
        text: adminNotification,
        parse_mode: "HTML"
      });

      // 2. USER SUCCESS MESSAGE (With your exact requested custom emojis)
      var successMessage = 
        "<blockquote><b>" + EMJ_NEW_ACCESS + " ACCESS GRANTED " + EMJ_NEW_ACCESS + "</b></blockquote>\n" +
        "<b>" + EMJ_VERIFIED_CHECK + " Verification Successful!</b>\n" +
        "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
        "<b>Welcome to " + SHOP_NAME + " </b>\n" +
        "<b>Your profile is now securely fully verified.</b>\n\n" +
        "<b>" + EMJ_ROCKET + " Store Loaded Successfully Use Now! " + EMJ_CROWN + "</b>";

      Api.sendMessage({
        chat_id: chat.chatid,
        text: successMessage,
        parse_mode: "HTML",
        reply_markup: JSON.stringify({ remove_keyboard: true }) 
      });

      // ✅ FIX: Direct inline menu instead of unreliable Bot.runCommand("/menu")
      sendMainMenu();
      return; 
    } else {
      Bot.sendMessage("❌ <b>Verification Failed!</b> Please share your own contact number only.", { parse_mode: "HTML" });
      return;
    }
  }

  // ==========================================
  // 📱 MODULE 0: VERIFICATION CALLBACK HANDLER
  // ==========================================
  if (msgText.toLowerCase() === "/start" || callbackData === "/trigger_contact_popup") {
    
    var verifyMessage = 
      "<blockquote><b>" + EMJ_ROCKET + " " + SHOP_NAME + " " + EMJ_RADAR + "</b></blockquote>\n" +
      "<b>" + EMJ_STAR + " Welcome, " + (user.first_name || "User") + " " + EMJ_DROP + "</b>\n" +
      "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
      "<b>" + EMJ_RED_DOT + " VERIFICATION REQUIRED " + EMJ_CHECK + "</b>\n" +
      "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n" +
      "<b>" + EMJ_RADAR + " To start shopping, please verify your phone number.</b>\n\n" +
      "<b>" + EMJ_ROCKET + " Why we need this:</b>\n" +
      "<b>  • Secure your purchases " + EMJ_CHECK + "</b>\n" +
      "<b>  • Deliver your panels to you " + EMJ_DROP + "</b>\n" +
      "<b>  • Protect your account " + EMJ_STAR + "</b>\n\n" +
      "<b>" + EMJ_RED_DOT + " Tap the blue button below to verify your account:</b>";

    // Standard native reply keyboard because contact sharing works securely here
    var nativeKeyboard = {
      keyboard: [
        [{ text: "✅ Verify Account", request_contact: true }]
      ],
      resize_keyboard: true,
      one_time_keyboard: true
    };

    Api.sendMessage({
      chat_id: chat.chatid,
      text: verifyMessage,
      parse_mode: "HTML",
      reply_markup: JSON.stringify(nativeKeyboard)
    });
    return; 
  }

  // ==========================================
  // 📦 MODULE 1: STEP-BY-STEP PRODUCT CREATION (UPDATED FOR WEBSITE API ID)
  // ==========================================
  if (isStaffUser && currentStep) {
    if (currentStep === "waiting_for_name") {
      if (!msgText) {
        Bot.sendMessage("⚠️ Invalid name. Please type a valid Product Name:");
        return;
      }
      User.setProperty("temp_product_name", msgText, "string");
      User.setProperty("add_product_step", "waiting_for_emoji", "string");
      Bot.sendMessage("💎 Great! Now send the <b>Premium Emoji ID</b> for this product:", { parse_mode: "HTML" });
      return; 
    }
    
    if (currentStep === "waiting_for_emoji") {
      if (!msgText) {
        Bot.sendMessage("⚠️ Invalid Emoji ID. Please send a valid Telegram Premium Emoji ID:");
        return;
      }
      User.setProperty("temp_product_emoji", msgText, "string");
      User.setProperty("add_product_step", "waiting_for_pid", "string");
      Bot.sendMessage("🔑 Nice! Now please enter the <b>Website API Product ID (PID)</b> for this item:", { parse_mode: "HTML" });
      return;
    }

    if (currentStep === "waiting_for_pid") {
      if (!msgText) {
        Bot.sendMessage("⚠️ Invalid Product ID. Please type a valid Website PID:");
        return;
      }

      var savedName = User.getProperty("temp_product_name");
      var savedEmoji = User.getProperty("temp_product_emoji");
      var savedPid = msgText; // The PID the user just sent

      var productList = Bot.getProperty("stored_products") || [];
      if (!Array.isArray(productList)) { productList = []; }
      
      // Saving Name, Emoji and Website API ID (id) inside database object
      productList.push({ 
        name: savedName, 
        emoji: savedEmoji, 
        id: savedPid, 
        plans: [] 
      });

      Bot.setProperty("stored_products", productList, "json");
      
      // Cleanup temporary states
      User.setProperty("add_product_step", null, "string");
      User.setProperty("temp_product_name", null, "string");
      User.setProperty("temp_product_emoji", null, "string");
      
      var successMsg = "✅ <b>Product Added Successfully!</b>\n\n" +
                       "📦 <b>Name:</b> " + savedName + "\n" +
                       "💎 <b>Emoji ID:</b> <code>" + savedEmoji + "</code>\n" +
                       "🔑 <b>API Product ID (PID):</b> <code>" + savedPid + "</code>\n\n" +
                       "<i>You can configure plans for this product later. The website integration was completed automatically!</i>";
                       
      Bot.sendMessage(successMsg, { parse_mode: "HTML" });
      return; 
    }
  }

  // ==========================================
  // 💵 MODULE 5: ADMIN BALANCE TOOLS (Add Bal / Remove Bal / Check Bal
  // button-click continuation — fixes buttons that previously just
  // showed a "Wrong Format" error with no way to actually complete it)
  // ==========================================
  if (isStaffUser) {
    var addbalStep = User.getProperty("addbal_step");
    var rembalStep = User.getProperty("rembal_step");
    var checkbalStep = User.getProperty("checkbal_step");

    if (addbalStep === "waiting_input" && msgText) {
      User.setProperty("addbal_step", null, "string");
      Bot.run({ command: "/addbal", options: { message: "/addbal " + msgText.trim() } });
      return;
    }
    if (rembalStep === "waiting_input" && msgText) {
      User.setProperty("rembal_step", null, "string");
      Bot.run({ command: "/rembal", options: { message: "/rembal " + msgText.trim() } });
      return;
    }
    if (checkbalStep === "waiting_input" && msgText) {
      User.setProperty("checkbal_step", null, "string");
      Bot.run({ command: "/checkbal", options: { params: msgText.trim() } });
      return;
    }
  }

  // ==========================================
  // 🎟 MODULE 3: ADMIN COUPON GENERATOR (step-by-step wizard)
  // ==========================================
  if (isStaffUser && couponGenStep) {

    if (couponGenStep === "code") {
      if (!msgText) { Bot.sendMessage("⚠️ Please send a valid coupon code."); return; }
      var couponCodeUpper = msgText.trim().toUpperCase();
      if (Bot.getProperty("coupon_" + couponCodeUpper)) {
        Bot.sendMessage("❌ This coupon code already exists! Try a different name.");
        return;
      }
      User.setProperty("coupon_gen_code", couponCodeUpper, "string");
      User.setProperty("coupon_gen_step", "maxclaims", "string");
      Bot.sendMessage("<tg-emoji emoji-id='6091571559233755994'>👥</tg-emoji> <b>How many users can use (claim) this coupon?</b>\n<i>Send only a number, for example: 50</i>", { parse_mode: "HTML" });
      return;
    }

    if (couponGenStep === "maxclaims") {
      var maxClaimsVal = parseInt(msgText.trim());
      if (isNaN(maxClaimsVal) || maxClaimsVal <= 0) { Bot.sendMessage("❌ Please send a valid number (for example 50)."); return; }
      User.setProperty("coupon_gen_maxclaims", maxClaimsVal, "number");
      User.setProperty("coupon_gen_step", "discount", "string");
      Bot.sendMessage("<tg-emoji emoji-id='6093591495237967001'>💸</tg-emoji> <b>What percentage discount should be given?</b>\n<i>Send only a number (1-100), for example: 10</i>", { parse_mode: "HTML" });
      return;
    }

    if (couponGenStep === "discount") {
      var discountVal = parseFloat(msgText.trim());
      if (isNaN(discountVal) || discountVal <= 0 || discountVal > 100) { Bot.sendMessage("❌ The discount must be between 1 and 100."); return; }
      User.setProperty("coupon_gen_discount", discountVal, "number");
      User.setProperty("coupon_gen_step", "scope", "string");
      Bot.sendMessage(
        "<tg-emoji emoji-id='6093677128295914531'>🎯</tg-emoji> <b>Scope batayein:</b>\n\n" +
        "• For all products/plans: type <code>global</code> and send it\n" +
        "• For one specific product and plan only: <code>Product Name | Duration</code>\n" +
        "  <i>Example:</i> <code>Free Fire Panel | 1d</code>",
        { parse_mode: "HTML" }
      );
      return;
    }

    if (couponGenStep === "scope") {
      var scopeInput = msgText.trim();
      var couponData = {
        code: User.getProperty("coupon_gen_code"),
        maxClaims: User.getProperty("coupon_gen_maxclaims"),
        discountPercent: User.getProperty("coupon_gen_discount"),
        claimedBy: [],
        isPaused: false,
        createdAt: new Date().toLocaleDateString()
      };

      if (scopeInput.toLowerCase() === "global") {
        couponData.scope = "global";
      } else if (scopeInput.indexOf("|") > -1) {
        var scopeParts = scopeInput.split("|");
        couponData.scope = "specific";
        couponData.productName = scopeParts[0].trim();
        couponData.duration = scopeParts[1].trim();
      } else {
        Bot.sendMessage("❌ Wrong format! Type 'global' or send it in the 'Product Name | Duration' format.");
        return;
      }

      Bot.setProperty("coupon_" + couponData.code, couponData, "json");

      // ✅ NEW: also add it to the master list, so the /coupons admin command can list everything
      var couponList = Bot.getProperty("coupon_list") || [];
      if (couponList.indexOf(couponData.code) === -1) {
        couponList.push(couponData.code);
        Bot.setProperty("coupon_list", couponList, "json");
      }

      // Cleanup wizard state
      User.setProperty("coupon_gen_step", null, "string");
      User.setProperty("coupon_gen_code", null, "string");
      User.setProperty("coupon_gen_maxclaims", null, "number");
      User.setProperty("coupon_gen_discount", null, "number");

      Bot.sendMessage(
        "<blockquote>🎟 <b>COUPON CREATED SUCCESSFULLY!</b></blockquote>\n\n" +
        "🏷 <b>Code:</b> <code>" + couponData.code + "</code>\n" +
        "👥 <b>Max Claims:</b> " + couponData.maxClaims + "\n" +
        "💸 <b>Discount:</b> " + couponData.discountPercent + "%\n" +
        "🎯 <b>Scope:</b> " + (couponData.scope === "global" ? "🌍 Global (All Plans)" : "📦 " + couponData.productName + " (" + couponData.duration + ")"),
        { parse_mode: "HTML" }
      );
      return;
    }
  }

  // ==========================================
  // 🎟 MODULE 4: USER — APPLY COUPON CODE TEXT ENTRY
  // ==========================================
  if (awaitingCouponFor) {
    var enteredCode = msgText.trim().toUpperCase();
    var couponRec = Bot.getProperty("coupon_" + enteredCode);

    User.setProperty("awaiting_coupon_for", null, "string");

    if (!couponRec) {
      Bot.sendMessage("❌ <b>Invalid Coupon Code!</b>", { parse_mode: "HTML" });
      return;
    }
    if (couponRec.isPaused) {
      Bot.sendMessage("⏸ This coupon is paused right now, please try again later.", { parse_mode: "HTML" });
      return;
    }
    if (!Array.isArray(couponRec.claimedBy)) { couponRec.claimedBy = []; }
    if (couponRec.claimedBy.indexOf(userId) > -1) {
      Bot.sendMessage("⚠️ You have already used this coupon!", { parse_mode: "HTML" });
      return;
    }
    if (couponRec.claimedBy.length >= couponRec.maxClaims) {
      Bot.sendMessage("❌ The claim limit for this coupon has been reached!", { parse_mode: "HTML" });
      return;
    }

    var couponTargetParts = awaitingCouponFor.split(" ");
    var cTargetProdIdx = couponTargetParts[0];
    var cTargetPlanIdx = couponTargetParts[1];

    if (couponRec.scope === "specific") {
      var cProductList = Bot.getProperty("stored_products") || [];
      var cProduct = cProductList[Number(cTargetProdIdx)];
      var cPlan = cProduct ? cProduct.plans[Number(cTargetPlanIdx)] : null;
      var cDurationDisplay = cPlan ? (cPlan.durationDisplay || (cPlan.days + " Days")) : "";
      var matchesProduct = cProduct && cProduct.name.trim().toLowerCase() === couponRec.productName.trim().toLowerCase();
      var matchesDuration = cDurationDisplay.toLowerCase().indexOf(String(couponRec.duration).toLowerCase().replace(/[^a-z0-9]/g, "")) > -1 ||
                             String(couponRec.duration).replace(/[^0-9]/g, "") === String(cPlan ? cPlan.days : "");
      if (!matchesProduct) {
        Bot.sendMessage("❌ This coupon is not valid for this product!", { parse_mode: "HTML" });
        return;
      }
    }

    // ✅ Valid — apply and mark claimed
    couponRec.claimedBy.push(userId);
    Bot.setProperty("coupon_" + enteredCode, couponRec, "json");
    User.setProperty("applied_coupon_" + cTargetProdIdx + "_" + cTargetPlanIdx, enteredCode, "string");

    Bot.sendMessage("🎉 <b>Coupon Applied!</b> -" + couponRec.discountPercent + "% discount added.", { parse_mode: "HTML" });

    Bot.run({
      command: "buyitem",
      options: { params: cTargetProdIdx + " " + cTargetPlanIdx }
    });
    return;
  }

  // ==========================================
  // 📢 MODULE 2: PREMIUM BROADCAST SYSTEM
  // ==========================================
  if (isStaffUser && isAwaitingBroadcast) {
    User.setProperty("awaiting_broadcast_data", false, "boolean");
    var userList = Bot.getProperty("all_users_list") || [];

    if (userList.length === 0) {
      Bot.sendMessage("❌ No users are registered in the bot yet.");
      return;
    }

    var targetMessageId = null;
    if (request) {
      if (request.message_id) { targetMessageId = request.message_id; }
      else if (request.message && request.message.message_id) { targetMessageId = request.message.message_id; }
    }

    if (!targetMessageId) {
      Bot.sendMessage("❌ Unable to fetch message ID for broadcast.");
      return;
    }

    Bot.sendMessage("⏳ Sending premium broadcast to " + userList.length + " users... Please wait.");

    // ✅ FIXED: previously one blocked/invalid user made Api.copyMessage() throw
    // and the error went up to the outer catch(), which stopped the loop midway
    // (the other users did not get the broadcast) and the admin saw a scary "Error in handling"
    // even though most users had already received the message. Now each send has its own
    // try/catch, and an accurate success/fail count is shown at the end.
    var sentCount = 0;
    var failedCount = 0;
    for (var i = 0; i < userList.length; i++) {
      try {
        Api.copyMessage({
          chat_id: String(userList[i]),
          from_chat_id: adminId,
          message_id: Number(targetMessageId)
        });
        sentCount++;
      } catch (perUserErr) {
        failedCount++;
      }
    }
    Bot.sendMessage(
      "✅ <b>Broadcast Complete!</b>\n" +
      "📤 <b>Sent:</b> " + sentCount + " users\n" +
      (failedCount > 0 ? "⚠️ <b>Failed/Blocked:</b> " + failedCount + " users" : "🎉 <b>No failures!</b>"),
      { parse_mode: "HTML" }
    );
  }

} catch (err) {
  Bot.sendMessage("Error in handling: " + err.message);
}