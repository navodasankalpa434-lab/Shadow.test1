/**#command
name: /select_id_product
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  // 🔥 CALLBACK DATA CLEARING & PARAM EXTRACTION PIPELINE
  var rawParams = "";
  if (typeof params !== "undefined" && params) {
    rawParams = String(params).trim();
  }

  // Fallback check in case the dynamic params system was bypassed
  if (!rawParams && typeof request !== "undefined" && request) {
    var callbackQuery = request.callback_query || request;
    if (callbackQuery && callbackQuery.data) {
      var dataStr = String(callbackQuery.data).trim();
      var parts = dataStr.split(" ");
      if (parts.length > 1) {
        rawParams = parts.slice(1).join(" ").trim();
      } else {
        rawParams = dataStr;
      }
    }
    
    // Clear loading spinner instantly
    let queryId = request.id || (request.callback_query && request.callback_query.id);
    if (queryId) {
      try { Api.answerCallbackQuery({ callback_query_id: queryId }); } catch (qErr){}
    }
  }

  // Safe Chat ID fallback
  var targetChatId = (chat && chat.chatid) ? chat.chatid : ((chat && chat.id) ? chat.id : (user ? user.telegramid : null));

  if (!targetChatId) return; // Silent guard if no context exists

  // 🛡️ SECURITY & EMPTY PARAM CHECK FIX
  if (!rawParams || rawParams.indexOf("/") === 0) { 
    Api.sendMessage({
      chat_id: targetChatId,
      text: "<tg-emoji emoji-id='5244837092042750681'>⚠️</tg-emoji> <b>Session Expired or Invalid Selection.</b>\n\nPlease select the product again from the main menu.",
      parse_mode: "HTML"
    });
    return;
  }

  var categories = Bot.getProperty("ff_categories") || {};

  if (!categories[rawParams]) {
    Api.sendMessage({
      chat_id: targetChatId,
      text: "❌ <b>Product not found or has been removed!</b>\nSelected Slug: <code>" + rawParams + "</code>",
      parse_mode: "HTML"
    });
    return;
  }

  var item = categories[rawParams];
  var stockList = Bot.getProperty("ff_stock_" + rawParams) || [];

  if (!Array.isArray(stockList)) stockList = [];

  // Safe user role derivation
  var userId = (user && user.telegramid) ? user.telegramid : targetChatId;
  var isReseller = Bot.getProperty("is_reseller_" + userId);
  var hasResellerAccess = (isReseller === true || String(isReseller).toLowerCase() === "true");

  var price = hasResellerAccess
    ? (item.reseller_price !== undefined && item.reseller_price !== null ? item.reseller_price : (item.normal_price || 0))
    : (item.normal_price || 0);

  // 💎 MULTIPLE PREMIUM EMOJIS INTEGRATION & BOLD LAYOUT (NEW EMOJIS MIXED)
  var text =
    "┏━━━━━━━━━━━━━━━━━━━━━━━━┓\n" +
    "┃ <tg-emoji emoji-id='6267140231632262769'>❤️‍🔥</tg-emoji> <b>ALL DETAILS</b> <tg-emoji emoji-id='6267140231632262769'>❤️‍🔥</tg-emoji> ┃\n" +
    "┗━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='5244837092042750681'>✨</tg-emoji> <b>PRODUCT DETAILS:</b>\n\n" +
    "<tg-emoji emoji-id='6267129592998270736'>📣</tg-emoji> <b>Product Name :</b> <code>" + item.name + "</code>\n\n" +
    "<tg-emoji emoji-id='6062310436672377598'>🪐</tg-emoji> <b>Current Stocks :</b> <code>" + stockList.length + " accounts</code>\n\n" +
    "<tg-emoji emoji-id='6266995104687330978'>📈</tg-emoji> <b>Price:</b> <code>LKR " + price + "</code>\n\n" +
    "<tg-emoji emoji-id='4967656361073574498'>👑</tg-emoji> <b>Account Type :</b> <b>" + (hasResellerAccess ? "Reseller" : "User") + "</b>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6057728771719435723'>⚡</tg-emoji> <i>Please click the button below to confirm.</i>";

  // Dynamic Button Configuration
  var purchaseButtonText = "Confirm Purchase";
  var purchaseButtonStyle = "success"; 
  var purchaseEmojiId = "6062310436672377598"; 

  if (stockList.length === 0) {
    purchaseButtonText = "❌ Out of Stock";
    purchaseButtonStyle = "danger"; 
    purchaseEmojiId = "5197288647275071607"; 
  }

  var buttons = {
    inline_keyboard: [
      [
        {
          text: purchaseButtonText,
          callback_data: stockList.length > 0 ? "/execute_id_buy " + rawParams : "/ff_id_menu",
          style: purchaseButtonStyle,
          icon_custom_emoji_id: purchaseEmojiId
        }
      ],
      [
        {
          text: "Back to Menu",
          callback_data: "/ff_id_menu",
          style: "danger",
          icon_custom_emoji_id: "5893163582194978381"
        }
      ]
    ]
  };

  var targetMessageId = (typeof request !== "undefined" && request && request.message) ? request.message.message_id : null;

  // Render logic handling
  if (targetMessageId) {
    try {
      Api.editMessageText({
        chat_id: targetChatId,
        message_id: targetMessageId,
        text: text,
        parse_mode: "HTML",
        reply_markup: JSON.stringify(buttons)
      });
    } catch (err) {
      Api.sendMessage({
        chat_id: targetChatId,
        text: text,
        parse_mode: "HTML",
        reply_markup: JSON.stringify(buttons)
      });
    }
  } else {
    Api.sendMessage({
      chat_id: targetChatId,
      text: text,
      parse_mode: "HTML",
      reply_markup: JSON.stringify(buttons)
    });
  }

} catch (e) {
  var errorChatId = (chat && chat.chatid) ? chat.chatid : ((user && user.telegramid) ? user.telegramid : "8500341403");
  try {
    Api.sendMessage({
      chat_id: errorChatId,
      text: "❌ <b>Checkout Error:</b>\n<code>" + e.message + "</code>",
      parse_mode: "HTML"
    });
  } catch(fatal){}
}