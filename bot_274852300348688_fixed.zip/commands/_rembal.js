/**#command
name: /rembal
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

let admin_id = "8500341403"; 

if (user.telegramid == admin_id) {
    
    let raw = (typeof message !== "undefined" && message) ? String(message).trim() : "";
    let data = raw.replace(/^\/rembal\s*/i, "").replace(/\s+/g, "");
    
    // ✅ FIXED: same button-click bug as /addbal — the prompt now appears.
    if (!data || !data.includes("|")) {
        User.setProperty("rembal_step", "waiting_input", "string");
        Bot.sendMessage(
            "<tg-emoji emoji-id='5409048419211682843'>💵</tg-emoji> <b>Remove Balance</b>\n\n" +
            "<i>Reply in this format with the User ID and amount:</i>\n<code>user_id|amount</code>\n\n" +
            "<i>Example:</i> <code>8500341403|50</code>",
            {parse_mode: "HTML"}
        );
        return;
    }
    
    let splitData = data.split("|");
    let targetUserId = splitData[0].trim();
    let amountToRemove = parseFloat(splitData[1].trim());
    
    if (isNaN(amountToRemove)) {
        Bot.sendMessage("❌ *Invalid Amount!*", {parse_mode: "Markdown"});
        return;
    }
    
    try {
        // Remove/deduct balance
        let targetUserBalance = Libs.ResourcesLib.anotherUserRes("balance", targetUserId);
        targetUserBalance.remove(amountToRemove);
        
        // Admin notification
        Bot.sendMessage("✅ Success! Removed " + amountToRemove + " from user " + targetUserId);
        
        // New 3 Premium Emojis in Quote Style
        let notificationText = 
            "<blockquote>" +
            "<tg-emoji emoji-id='5893163582194978381'>❌</tg-emoji> Admin Remove: " + amountToRemove + "\n" +
            "<tg-emoji emoji-id='6071272104978814192'>😞</tg-emoji> Check your balance now\n" +
            "<tg-emoji emoji-id='5257963315258204021'>ℹ️</tg-emoji> Use /balance To Check" +
            "</blockquote>";
            
        // Direct Telegram API Method for instant delivery
        HTTP.post({
            url: "https://api.telegram.org/bot" + bot.token + "/sendMessage",
            body: {
                chat_id: targetUserId,
                text: notificationText,
                parse_mode: "HTML"
            }
        });
        
    } catch (err) {
        Bot.sendMessage("⚠️ *Error:* " + err.message, {parse_mode: "Markdown"});
    }

} else {
    Bot.sendMessage("❌ You are not authorized to use this command.");
}