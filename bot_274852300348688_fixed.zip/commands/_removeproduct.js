/**#command
name: /removeproduct
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403"; // Your Admin ID
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  // Fetch existing products from the database
  var productList = Bot.getProperty("stored_products") || [];

  if (productList.length === 0) {
    Bot.sendMessage("❌ <b>No product found in the database!</b> Add a product first before removing one.", { parse_mode: "HTML" });
    return;
  }

  var inlineButtons = [];

  // Build dynamic buttons for all products using a loop
  for (var i = 0; i < productList.length; i++) {
    var product = productList[i];
    if (!product || !product.name) continue;

    inlineButtons.push([
      {
        text: "🗑️ Remove: " + product.name.toUpperCase(),
        // Pass the array index number in the callback data
        callback_data: "/confirm_rem_prod " + i
      }
    ]);
  }

  var menuText = "<blockquote><b>🗑️ CHOOSE PRODUCT TO REMOVE</b>\n\n" +
                 "• <b>Total Registered:</b> <code>" + productList.length + " Products</code>\n\n" +
                 "<i>Click the button below for the product you want to delete completely:</i></blockquote>";

  Bot.sendMessage(menuText, {
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Remove Product Menu Error: " + err.message);
}