/**#command
name: /set_update_link
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 🔧 ADMIN — Configure the "Download Updates" redirect link
// Usage: /set_update_link https://t.me/YourUpdateChannel
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "8500341403";
  var isCoAdmin0 = isCoAdminId(String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  if (!params || params.trim() === "") {
    var currentLink = Bot.getProperty("update_channel_link") || "Not set";
    Bot.sendMessage(
      "⚠️ <b>Format:</b> <code>/set_update_link https://t.me/YourChannel</code>\n\n" +
      "<b>Current link:</b> " + currentLink,
      { parse_mode: "HTML" }
    );
    return;
  }

  var link = params.trim();
  if (link.indexOf("http") !== 0) {
    Bot.sendMessage("❌ The link must start with http:// or https://!");
    return;
  }

  Bot.setProperty("update_channel_link", link, "string");
  Bot.sendMessage("✅ <b>Update channel link set:</b>\n" + link, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}