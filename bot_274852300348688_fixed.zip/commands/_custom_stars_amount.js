/**#command
name: /custom_stars_amount
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}


// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// ⭐ "Custom Amount" button — asks user to type a Stars amount
// (reply handled in _start.js MODULE 5)
// =========================================================

if (String(user.telegramid) !== "8500341403" && !isCoAdminId(String(user.telegramid))) { Api.sendMessage({ chat_id: user.telegramid, text: "🔒 Only the admin can add funds. Please contact the admin to top up your wallet.", parse_mode: "HTML" }); return; }
try {
  User.setProperty("awaiting_stars_amount", true, "boolean");

  var text = "<blockquote>⭐ <b>ENTER STARS AMOUNT</b></blockquote>\n\n<i>How many Stars do you want to deposit? Type a number and send it (e.g. 150)</i>";

  if (request && request.message && !request.message.photo) {
    Api.editMessageText({ chat_id: String(chat.chatid), message_id: Number(request.message.message_id), text: text, parse_mode: "HTML" });
  } else {
    Api.sendMessage({ chat_id: chat.chatid, text: text, parse_mode: "HTML" });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}