/**#command
name: /addkeys
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Bulk keys: /addkeys PRODUCT | PLAN  (then paste the keys, one per line).  Send /addkeys done when finished.
try {
  if (String(chat.chatid) !== "8500341403" && !isCoAdminId(String(chat.chatid))) { Bot.sendMessage("❌ Only the owner and co-admins can add keys."); return; }
  var raw = (typeof message !== "undefined" && message) ? String(message).trim() : "";
  raw = raw.replace(/^\/addkeys\s*/i, "").trim();
  var target = String(User.getProperty("bulkkey_target") || "");

  if (raw.toLowerCase() === "done") {
    var added = Number(User.getProperty("bulkkey_count") || 0);
    User.setProperty("bulkkey_target", "", "string");
    User.setProperty("bulkkey_count", "0", "string");
    Bot.sendMessage("✅ <b>Bulk add finished.</b> Keys added in this session: <b>" + added + "</b>", { parse_mode: "HTML" });
    return;
  }

  var products = Bot.getProperty("stored_products") || [];
  if (typeof products === "string") { try { products = JSON.parse(products); } catch (e) { products = []; } }
  if (!Array.isArray(products)) { products = []; }

  var isHeader = raw.indexOf("|") > -1 && raw.indexOf("\n") === -1 && raw.split("|").length === 2;
  if (isHeader || (raw.indexOf("|") > -1 && raw.indexOf("\n") === -1 && !target)) {
    var hp = raw.split("|").map(function (x) { return x.trim(); });
    var pi = -1, pj = -1;
    for (var i = 0; i < products.length; i++) {
      if (products[i] && String(products[i].name).trim().toLowerCase() === hp[0].toLowerCase()) { pi = i; break; }
    }
    if (pi < 0) { Bot.sendMessage("❌ Product <b>" + hp[0] + "</b> not found. Add it first with <code>/addproduct</code>.", { parse_mode: "HTML" }); return; }
    var plans = Array.isArray(products[pi].plans) ? products[pi].plans : [];
    var wantNum = hp[1].replace(/[^0-9.]/g, "");
    for (var j = 0; j < plans.length; j++) {
      if (String(plans[j].durationDisplay || "").trim().toLowerCase() === hp[1].toLowerCase() || (wantNum !== "" && String(plans[j].days).replace(/[^0-9.]/g, "") === wantNum)) { pj = j; break; }
    }
    if (pj < 0) { Bot.sendMessage("❌ Plan <b>" + hp[1] + "</b> not found for " + products[pi].name + ".", { parse_mode: "HTML" }); return; }
    User.setProperty("bulkkey_target", pi + ":" + pj, "string");
    User.setProperty("bulkkey_count", "0", "string");
    Bot.sendMessage("📦 <b>Bulk add: " + products[pi].name + " — " + plans[pj].durationDisplay + "</b>\n\nPaste the keys now, one per line, in one or more messages.\nSend <code>/addkeys done</code> when finished.", { parse_mode: "HTML" });
    return;
  }

  if (!target) {
    Bot.sendMessage("🔑 <b>Bulk add keys</b>\nSend: <code>/addkeys PRODUCT | PLAN</code>\nExample: <code>/addkeys Shadow | 1 Day</code>\nThen paste the keys, one per line.", { parse_mode: "HTML" });
    return;
  }

  var tp = target.split(":");
  var tProd = products[Number(tp[0])];
  var tPlan = tProd && tProd.plans ? tProd.plans[Number(tp[1])] : null;
  if (!tPlan) { User.setProperty("bulkkey_target", "", "string"); Bot.sendMessage("❌ Plan not found. Start again with <code>/addkeys PRODUCT | PLAN</code>.", { parse_mode: "HTML" }); return; }

  var keyLines = raw.split("\n").map(function (x) { return x.trim(); }).filter(function (x) { return x !== ""; });
  if (keyLines.length === 0) { return; }
  var dd = String(tPlan.days).replace(/[^0-9.]/g, "");
  var keyName = "stock_" + String(tProd.name).trim() + "_" + dd + "_Day";
  var idxName = "stock_" + tp[0] + "_" + tp[1];
  var stockList = Bot.getProperty(keyName) || [];
  if (typeof stockList === "string") { try { stockList = JSON.parse(stockList); } catch (e2) { stockList = []; } }
  if (!Array.isArray(stockList)) { stockList = []; }
  var addedNow = 0;
  for (var k = 0; k < keyLines.length; k++) {
    if (stockList.indexOf(keyLines[k]) === -1) { stockList.push(keyLines[k]); addedNow++; }
  }
  Bot.setProperty(keyName, stockList, "json");
  Bot.setProperty(idxName, stockList, "json");
  var sofar = Number(User.getProperty("bulkkey_count") || 0) + addedNow;
  User.setProperty("bulkkey_count", String(sofar), "string");
  Bot.sendMessage("✅ Added <b>" + addedNow + "</b> keys to " + tProd.name + " — " + tPlan.durationDisplay +
                  ".\nTotal in this plan now: <b>" + stockList.length + "</b>\nSend more keys, or <code>/addkeys done</code>.", { parse_mode: "HTML" });
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}