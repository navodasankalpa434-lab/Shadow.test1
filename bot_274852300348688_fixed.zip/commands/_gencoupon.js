/**#command
name: /gencoupon
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 🎟 ADMIN — Coupon Generator Wizard (Step 1: kicks off in _start.js MODULE 3)
// =========================================================

try {
  var adminId = Bot.getProperty("owner_id") || "8500341403";
  var isCoAdmin0 = isCoAdminId(String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ You are not the admin!");
    return;
  }

  User.setProperty("coupon_gen_step", "code", "string");

  Bot.sendMessage(
    "<blockquote>🎟 <b>COUPON GENERATOR</b></blockquote>\n\n" +
    "<tg-emoji emoji-id='6080214566191505147'>🏷</tg-emoji> <b>What should the coupon code be?</b>\n" +
    "<i>Type and send it, for example: SAVE10</i>",
    { parse_mode: "HTML" }
  );

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}