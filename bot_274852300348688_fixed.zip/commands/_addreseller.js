/**#command
name: /addreseller
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = Bot.getProperty("owner_id") || "8500341403";
  var isCoAdmin0 = isCoAdminId(String(chat.chatid));
  if (String(chat.chatid) !== adminId) return; // only the owner can add resellers

  // Get the User ID from the input
  var targetId = params ? params.trim() : null;

  if (!targetId) {
    Bot.sendMessage("❌ <b>Usage:</b> <code>/addreseller 123456789</code>", { parse_mode: "HTML" });
    return;
  }

  // First check whether this user is already a reseller
  var alreadyReseller = Bot.getProperty("is_reseller_" + targetId);

  if (alreadyReseller === true) {
    Bot.sendMessage("<tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji> This user (<code>" + targetId + "</code>) is <b>already a Reseller!</b>", { parse_mode: "HTML" });
    return; // Code stops here
  }

  // If the user is not a reseller, save them
  Bot.setProperty("is_reseller_" + targetId, true, "boolean");

  Bot.sendMessage("<tg-emoji emoji-id='6064138396228392033'>✅</tg-emoji> User <code>" + targetId + "</code> has been successfully added to the reseller role!", { parse_mode: "HTML" });

  // Send a premium notification to the reseller
  var notifText = "<blockquote><b><tg-emoji emoji-id='6064138396228392033'>✨</tg-emoji> CONGRATULATIONS <tg-emoji emoji-id='6064138396228392033'>✨</tg-emoji></b>\n\n" +
                  "<tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji> You Are Now A Reseller.\n" +
                  "Check Your Discounted Store /start To Check Now<tg-emoji emoji-id='6298298582982199311'>💰</tg-emoji></blockquote>";
                  
  Api.sendMessage({
    chat_id: targetId,
    text: notifText,
    parse_mode: "HTML"
  });

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}