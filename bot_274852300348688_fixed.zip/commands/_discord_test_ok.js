/**#command
name: /discord_test_ok
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  Api.sendMessage({ chat_id: "8500341403", parse_mode: "HTML", text: "✅ Discord accepted the test alert. Sales alerts will work." });
} catch (e) {}
return;