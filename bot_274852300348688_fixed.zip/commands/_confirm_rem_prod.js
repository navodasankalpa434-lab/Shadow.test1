/**#command
name: /confirm_rem_prod
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  var callbackId = request ? request.id : null;
  var targetIndex = params ? Number(params.trim()) : -1;

  if (targetIndex === -1 || isNaN(targetIndex)) {
    if (callbackId) Api.answerCallbackQuery({ callback_query_id: callbackId, text: "❌ Invalid product data index!", show_alert: true });
    return;
  }

  var productList = Bot.getProperty("stored_products") || [];

  if (productList.length === 0 || targetIndex >= productList.length) {
    if (callbackId) {
      Api.answerCallbackQuery({ callback_query_id: callbackId, text: "❌ Product already removed or missing!", show_alert: true });
    }
    return;
  }

  // Get the target product from the data array (delete action)
  var removedProduct = productList[targetIndex];
  var removedName = removedProduct.name;
  
  productList.splice(targetIndex, 1); // Array modification

  // Save the updated array registry again
  Bot.setProperty("stored_products", productList, "json");

  var successText = "<blockquote><b>🗑️ PRODUCT SUCCESSFULLY REMOVED</b>\n\n" +
                    "• <b>Product Name:</b> <code>" + removedName.toUpperCase() + "</code>\n" +
                    "• <b>Status:</b> Completely wiped from database matrix.\n" +
                    "• <b>Remaining Products:</b> <code>" + productList.length + " Left</code></blockquote>";

  // Edit the message window to update the text live
  if (request && request.message) {
    HTTP.post({
      url: "https://api.telegram.org/bot" + bot.token + "/editMessageText",
      body: {
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: successText,
        parse_mode: "HTML"
      }
    });
  } else {
    Bot.sendMessage(successText, { parse_mode: "HTML" });
  }

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: callbackId, text: "✅ Product Wiped!" });
  }

} catch (err) {
  Bot.sendMessage("⚠️ Execution Error: " + err.message);
}