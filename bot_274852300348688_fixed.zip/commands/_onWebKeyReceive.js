/**#command
name: /onWebKeyReceive
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Customer purchase history, keys sold and total spent (saved per customer, included in backups)
function recordPurchase(uid, rec) {
  var h = Bot.getProperty("history_" + uid) || [];
  if (typeof h === "string") { try { h = JSON.parse(h); } catch (e) { h = []; } }
  if (!Array.isArray(h)) { h = []; }
  h.push(rec);
  Bot.setProperty("history_" + uid, h, "json");
  Bot.setProperty("keys_sold_" + uid, String(Number(Bot.getProperty("keys_sold_" + uid) || 0) + 1), "string");
  Bot.setProperty("dash_spent_" + uid, String(Number(Bot.getProperty("dash_spent_" + uid) || 0) + Number(rec.price || 0)), "string");
}
function salesLogAdd(entry) {
  var slog = Bot.getProperty("sales_log") || [];
  if (typeof slog === "string") { try { slog = JSON.parse(slog); } catch (e) { slog = []; } }
  if (!Array.isArray(slog)) { slog = []; }
  slog.push(entry);
  if (slog.length > 2000) { slog = slog.slice(slog.length - 2000); }
  Bot.setProperty("sales_log", slog, "json");
}
// Discord image: a direct https link set with /settings discord image LINK (or the menu photo link)
function discordImgObj() {
  var u = String(Bot.getProperty("discord_image") || Bot.getProperty("menu_photo_url") || "");
  return (u.indexOf("https://") === 0) ? { url: u } : undefined;
}
// Live Discord dashboard: one message, updated on every sale, top-up and wallet change
function dashInc(key, amt) { Bot.setProperty(key, String(Number(Bot.getProperty(key) || 0) + Number(amt || 0)), "string"); }
function updateDashboard(evt) {
  try {
    if (evt && evt.type === "sale") { dashInc("dash_sales_count", 1); dashInc("dash_sales_total", evt.price);
      if (evt.user) { dashInc("dash_orders_" + evt.user, 1); dashInc("dash_spent_" + evt.user, evt.price); } }
    if (evt && evt.type === "sale") { salesLogAdd({ date: new Date().toISOString(), user: String(evt.user || ""), product: evt.product || "", plan: evt.plan || "", price: evt.price, key: evt.key || "" }); }
    if (evt && evt.type === "topup") { dashInc("dash_topup_count", 1); dashInc("dash_topup_total", evt.amount); }
    if (evt && evt.type === "wallet") { dashInc("dash_wallet_count", 1); dashInc("dash_wallet_total", evt.amount); }
    var hook = String(Bot.getProperty("discord_webhook") || "");
    if (hook.indexOf("https://discord.com/api/webhooks/") !== 0 && hook.indexOf("https://discordapp.com/api/webhooks/") !== 0) { return; }
    var ul = Bot.getProperty("all_users_list") || [];
    if (typeof ul === "string") { try { ul = JSON.parse(ul); } catch (e) { ul = []; } }
    if (!Array.isArray(ul)) { ul = []; }
    var rl = Bot.getProperty("resellers_list") || [];
    if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e2) { rl = []; } }
    var rIds = Array.isArray(rl) ? rl.map(function (x) { return String(x && x.id !== undefined ? x.id : x); }) : [];
    var cl = Bot.getProperty("co_admin_list") || [];
    if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e3) { cl = []; } }
    var cIds = Array.isArray(cl) ? cl.map(String) : [];
    var rows = [], walletTotal = 0, verifiedCount = 0, resellerCount = 0;
    for (var i = 0; i < ul.length; i++) {
      var uid = String(ul[i]);
      if (uid === "8500341403") { continue; }
      var bal = 0;
      try { bal = Number(Libs.ResourcesLib.anotherUserRes("balance", uid).value() || 0); } catch (be) { bal = 0; }
      var vv = Bot.getProperty("verified_" + uid);
      var ver = (vv === true || String(vv) === "true");
      var isR = rIds.indexOf(uid) !== -1 || !!Bot.getProperty("is_reseller_" + uid);
      var role = uid === "8500341403" ? "👑" : (cIds.indexOf(uid) !== -1 ? "🛡" : (isR ? "🔴" : "👤"));
      walletTotal += bal; if (ver) { verifiedCount++; } if (isR) { resellerCount++; }
      rows.push({ id: uid, bal: bal, ver: ver, role: role, tu: Number(Bot.getProperty("topup_total_" + uid) || 0),
                  ord: Number(Bot.getProperty("dash_orders_" + uid) || 0), spent: Number(Bot.getProperty("dash_spent_" + uid) || 0) });
    }
    rows.sort(function (a, b) { return b.bal - a.bal; });
    var lines = rows.slice(0, 20).map(function (r) {
      return r.role + " `" + r.id + "` " + (r.ver ? "✅" : "⬜") + "  💳 " + r.bal + "  ·  💰 top-up " + r.tu + "  ·  🛒 " + r.ord + " (" + r.spent + ")";
    });
    var stockKeys = 0;
    var sprods = Bot.getProperty("stored_products") || [];
    if (typeof sprods === "string") { try { sprods = JSON.parse(sprods); } catch (se) { sprods = []; } }
    if (!Array.isArray(sprods)) { sprods = []; }
    for (var si = 0; si < sprods.length; si++) {
      var sp = sprods[si];
      if (!sp || !sp.name) { continue; }
      var spl = Array.isArray(sp.plans) ? sp.plans : [];
      for (var sj = 0; sj < spl.length; sj++) {
        var sd = String(spl[sj].days).replace(/[^0-9.]/g, "");
        var sn = String(sp.name).trim();
        var scands = ["manual_keys_" + sn.toUpperCase() + "_" + sd, "stock_" + sn + "_" + sd + "_Day",
                      "stock_" + sn + "_" + sd, "stock_" + si + "_" + sj, "stock_" + sn + "_" + sd + "d_Day"];
        for (var sc = 0; sc < scands.length; sc++) {
          var sv = Bot.getProperty(scands[sc]);
          if (typeof sv === "string") { try { sv = JSON.parse(sv); } catch (se2) { sv = sv.split("\n"); } }
          if (Array.isArray(sv) && sv.length > 0) {
            stockKeys += sv.filter(function (k) { return String(k).trim() !== ""; }).length;
            break;
          }
        }
      }
    }
    var now = new Date().toISOString().replace("T", " ").substring(0, 16) + " UTC";
    var embeds = [
      { title: "📊 LIVE DASHBOARD", color: 3447003, thumbnail: discordImgObj(), description: "Updated: **" + now + "**",
        fields: [
          { name: "📦 Keys in stock", value: "**" + stockKeys + "** available", inline: true },
          { name: "🛒 Sales", value: "**" + Number(Bot.getProperty("dash_sales_count") || 0) + "** orders\nLKR " + Number(Bot.getProperty("dash_sales_total") || 0), inline: true },
          { name: "💳 Top-ups", value: "**" + Number(Bot.getProperty("dash_topup_count") || 0) + "** approved\nLKR " + Number(Bot.getProperty("dash_topup_total") || 0), inline: true },
          { name: "👥 Users", value: "**" + rows.length + "** total\n✅ " + verifiedCount + " verified", inline: true },
          { name: "🏦 Wallet total", value: "LKR " + walletTotal, inline: true },
          { name: "🔴 Resellers", value: "**" + resellerCount + "**", inline: true }
        ] },
      { title: "👤 PROFILES (top 20 by balance)", color: 3066993,
        description: lines.length ? lines.join("\n") : "No profiles yet." }
    ];
    var payload = JSON.stringify({ username: "Store Dashboard", embeds: embeds });
    var hdr = { "Content-Type": "application/json" };
    var mid = String(Bot.getProperty("dash_message_id") || "");
    if (mid && typeof HTTP.patch === "function") {
      HTTP.patch({ url: hook + "/messages/" + mid, body: payload, headers: hdr, success: "/discord_ok", error: "/dash_error" });
    } else {
      HTTP.post({ url: hook + "?wait=true", body: payload, headers: hdr, success: "/dash_saved", error: "/dash_error" });
    }
  } catch (e) {}
}
// Discord sale alert: styled embed with buyer role and details
function notifyDiscordSale(info) {
  try {
    var hook = String(Bot.getProperty("discord_webhook") || "");
    if (hook.indexOf("https://discord.com/api/webhooks/") !== 0 && hook.indexOf("https://discordapp.com/api/webhooks/") !== 0) { return; }
    var bid = String(info.user);
    var rl = Bot.getProperty("resellers_list") || [];
    if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e) { rl = []; } }
    var isRes = !!Bot.getProperty("is_reseller_" + bid) || (Array.isArray(rl) && rl.some(function (x) { return String(x && x.id !== undefined ? x.id : x) === bid; }));
    var cl = Bot.getProperty("co_admin_list") || [];
    if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e2) { cl = []; } }
    var role = bid === "8500341403" ? "👑 Owner" : (Array.isArray(cl) && cl.map(String).indexOf(bid) !== -1) ? "🛡 Co-admin" : isRes ? "🔴 Reseller" : "👤 Customer";
    var vv = Bot.getProperty("verified_" + bid);
    var verified = (vv === true || String(vv) === "true") ? "✅ Verified" : "🔴 Not verified";
    var bal = "-";
    try { bal = "LKR " + (Libs.ResourcesLib.anotherUserRes("balance", bid).value() || 0); } catch (be) {}
    var buyer = info.name ? info.name : "Customer";
    var color = (info.source === "manual stock") ? 3066993 : 3447003;
    var payload = {
      username: "Sales Bot",
      embeds: [{
        title: "🛒  NEW SALE",
        description: "**" + info.product + "** — " + info.plan,
        color: color,
        fields: [
          { name: "💰 Price", value: "LKR " + info.price, inline: true },
          { name: "📦 Delivery", value: info.source, inline: true },
          { name: "🏷 Role", value: role, inline: true },
          { name: "👤 Buyer", value: buyer, inline: true },
          { name: "🆔 Chat ID", value: "`" + bid + "`", inline: true },
          { name: "🔐 Account", value: verified, inline: true },
          { name: "💳 Balance now", value: bal, inline: true }
        ],
        footer: { text: "Shadow and Scrapy Panel Store" },
        thumbnail: discordImgObj(),
        timestamp: new Date().toISOString()
      }]
    };
    HTTP.post({ url: hook, body: JSON.stringify(payload), headers: { "Content-Type": "application/json" },
                success: "/discord_ok", error: "/discord_ok" });
  } catch (e) {}
}

try { 
  // Parse response safely only if content exists
  var response = null;
  if (typeof content === "string" && content.trim() !== "") {
    try {
      response = JSON.parse(content);
    } catch (e) {
      // Keep response as null if JSON parsing fails
    }
  }

  var userId = (typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : Bot.getProperty("last_order_user");
  var chatId = (typeof chat !== "undefined" && chat && chat.chatid) ? chat.chatid : Bot.getProperty("last_order_chat");

  // 🔄 PRODUCT DATA ACCURACY CORE (DYNAMIC)
  var dataOptions = options || {}; 
  try {
    var lastOrder = JSON.parse(Bot.getProperty("last_order_info") || "{}");
    notifyDiscordSale({ product: lastOrder.prod_name || "API product", plan: lastOrder.plan_days ? lastOrder.plan_days + " Days" : "-",
                        price: lastOrder.price, user: lastOrder.user_id || userId, source: "reseller API", name: lastOrder.first_name });
    updateDashboard({ type: "sale", price: lastOrder.price, user: lastOrder.user_id || userId, product: lastOrder.prod_name, plan: lastOrder.plan_days });
    recordPurchase(lastOrder.user_id || userId, { date: new Date().toISOString(), product: lastOrder.prod_name, plan: lastOrder.plan_days, price: lastOrder.price, key: "" });
  } catch (dsE) {}
  
  // 🆔 1. PRODUCT ID LAYER (Added for flawless API requests)
  var prodId = dataOptions.prod_id || dataOptions.id || dataOptions.product_id || User.getProperty("last_pending_prod_id") || null;

  // 2. Raw options fallback mechanisms
  var rawProdName = dataOptions.prod_name || dataOptions.product || dataOptions.name || User.getProperty("last_pending_prod_name") || "Product";
  var planDays = String(dataOptions.plan_days || dataOptions.days || User.getProperty("last_pending_plan_days") || "1");
  var pDaysNumOnly = planDays.replace(/[^0-9]/g, "").trim(); 
  var planUnit = dataOptions.plan_unit || User.getProperty("last_pending_plan_unit") || "day";
  var unitLabelWordW = (planUnit === "hour") ? (Number(pDaysNumOnly) === 1 ? "Hour" : "Hours") :
                        (planUnit === "minute") ? (Number(pDaysNumOnly) === 1 ? "Minute" : "Minutes") :
                        (Number(pDaysNumOnly) === 1 ? "Day" : "Days");
  var durationDisplayW = pDaysNumOnly + " " + unitLabelWordW;

  // 3. Database validation layer to completely kill the "Product" fallback string bug
  var productList = Bot.getProperty("stored_products") || [];
  var prodName = rawProdName.trim(); 

  // ⚡ DEEP ADVANCED DATABASE SEARCH MATCH (Matches by ID first if available, then name)
  if (productList.length > 0) {
    var checkTerm = prodName.toLowerCase();
    var foundMatch = false;

    for (var i = 0; i < productList.length; i++) {
      var dbItem = productList[i];
      var dbName = dbItem.name ? dbItem.name.trim() : "";
      var dbId = dbItem.id || null;
      
      // If ID matches directly, use it!
      if (prodId && dbId && String(prodId) === String(dbId)) {
        prodName = dbName;
        foundMatch = true;
        break;
      }

      if (!dbName) continue;
      
      if (dbName.toLowerCase() === checkTerm || 
          (checkTerm !== "product" && (checkTerm.indexOf(dbName.toLowerCase()) > -1 || dbName.toLowerCase().indexOf(checkTerm) > -1))) {
        prodName = dbName; 
        if (dbId) { prodId = dbId; } // Backfill ID if name matched
        foundMatch = true;
        break;
      }
    }

    if (!foundMatch || prodName.toLowerCase() === "product") {
      var lastPending = User.getProperty("last_pending_prod_name");
      if (lastPending && lastPending.toLowerCase() !== "product") {
        prodName = lastPending.trim();
      } else if (productList.length === 1) {
        prodName = productList[0].name.trim();
        if (productList[0].id) { prodId = productList[0].id; }
      }
    }
  }

  var price = Number(dataOptions.price) || Number(User.getProperty("last_pending_price")) || 0;
  var firstName = dataOptions.first_name || user.first_name || "User";
  var usernameText = user.username ? "@" + user.username : "No Username";
  var currentWalletBal = Libs.ResourcesLib.userRes("balance").value().toFixed(2);

  var generatedKey = null;
  var isApiDelivery = false;
  var isBackupUsed = false;

  var cleanProdNameUpper = prodName.trim().toUpperCase();
  var manualKeysStorageKey = "manual_keys_" + cleanProdNameUpper + "_" + pDaysNumOnly;
  var backupStockKey = "stock_" + prodName.trim() + "_" + pDaysNumOnly + "_Day";
  
  // ⚡ STEP 1: FORCE CHECK MANUAL STOCK (CRITICAL OVERRIDE)
  var manualStock = Bot.getProperty(manualKeysStorageKey);

  if (!manualStock || (Array.isArray(manualStock) && manualStock.length === 0)) {
    manualStock = Bot.getProperty(backupStockKey);
    isBackupUsed = true;
  }

  if (typeof manualStock === "string" && manualStock.trim() !== "") {
    try {
      manualStock = JSON.parse(manualStock);
    } catch(err) {
      manualStock = manualStock.split("\n").map(function(k) { return k.trim(); }).filter(Boolean);
    }
  }

  if (Array.isArray(manualStock) && manualStock.length > 0) {
    generatedKey = manualStock.shift(); 
    
    if (isBackupUsed) {
      Bot.setProperty(backupStockKey, manualStock, "json");
      var mainStock = Bot.getProperty(manualKeysStorageKey) || [];
      if (typeof mainStock === "string") { mainStock = mainStock.split("\n").map(function(k) { return k.trim(); }).filter(Boolean); }
      if (Array.isArray(mainStock)) {
        var idx = mainStock.indexOf(generatedKey);
        if (idx > -1) { mainStock.splice(idx, 1); }
        Bot.setProperty(manualKeysStorageKey, mainStock, "json");
      }
    } else {
      Bot.setProperty(manualKeysStorageKey, manualStock, "json");
      var backupStock = Bot.getProperty(backupStockKey) || [];
      if (typeof backupStock === "string") { backupStock = backupStock.split("\n").map(function(k) { return k.trim(); }).filter(Boolean); }
      if (Array.isArray(backupStock)) {
        var idx = backupStock.indexOf(generatedKey);
        if (idx > -1) { backupStock.splice(idx, 1); }
        Bot.setProperty(backupStockKey, backupStock, "json");
      }
    }
  }

  // ⚡ STEP 2: FALLBACK TO API KEYS (IF NO MANUAL STOCK WAS FOUND)
  if (!generatedKey && response && response.status === "success") {
    generatedKey = response.key || response.code || response.serial;
    if (generatedKey) {
      isApiDelivery = true;
    }
  }

  // STEP 3: SUCCESS DELIVERY MECHANICS
  if (generatedKey) {
    Libs.ResourcesLib.userRes("balance").add(-price);

    var pastSpent = Bot.getProperty("total_spent_by_" + userId) || 0;
    Bot.setProperty("total_spent_by_" + userId, Number(pastSpent) + price, "number");

    var userKeysHistory = User.getProperty("my_purchased_keys") || [];
    userKeysHistory.push({
      product: prodName,
      product_id: prodId,
      days: pDaysNumOnly,
      price: price,
      key: generatedKey,
      date: new Date().toLocaleDateString()
    });
    User.setProperty("my_purchased_keys", userKeysHistory, "json");

    var remainingBal = Libs.ResourcesLib.userRes("balance").value().toFixed(2);
    
    var updateLinkForKey = Bot.getProperty("update_channel_link");
    var keyDeliveryButtons = [[{ text: "📋 Copy Key", copy_text: { text: generatedKey } }]];
    if (updateLinkForKey) {
      keyDeliveryButtons.push([{ text: "📥 Join Updates", url: updateLinkForKey, style: "primary", icon_custom_emoji_id: "6091571559233755994" }]);
    }
    keyDeliveryButtons.push([{ text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "5893163582194978381" }]);
    var keyDeliveryMarkup = JSON.stringify({ inline_keyboard: keyDeliveryButtons });

    var deliverText = "<blockquote>" +
                      "<tg-emoji emoji-id='5350447674971660988'>✅</tg-emoji> <b>PURCHASE SUCCESSFUL!</b>\n\n" +
                      "<tg-emoji emoji-id='6147767796097884213'>📦</tg-emoji> <b>Product:</b> <code>" + prodName + "</code>\n" +
                      "<tg-emoji emoji-id='6284816251143331422'>🗝</tg-emoji> <b>Validity:</b> <code>" + durationDisplayW + "</code>\n" +
                      "<tg-emoji emoji-id='5352825278672412291'>👆</tg-emoji> <b>Your Key:</b> <code>" + generatedKey + "</code>\n\n" +
                      "━━━━━ <tg-emoji emoji-id='6147934084346682063'>#⃣</tg-emoji> <b>BALANCE DETAILS</b> ━━━━━\n" +
                      "<tg-emoji emoji-id='6195037488898121775'>✨</tg-emoji> <b>Total Invest:</b> LKR " + price.toFixed(2) + "\n" +
                      "<tg-emoji emoji-id='5409048419211682843'>💵</tg-emoji> <b>New Wallet Balance:</b> LKR " + remainingBal + "\n\n" +
                      "<i>Enjoy your purchase. <tg-emoji emoji-id='6057881002540274780'>🥳</tg-emoji></i>" +
                      "</blockquote>";
                      
    // ✅ FIX: "the old "Processing your order..." message is now deleted
    // so only the final key-delivery message remains in the chat.
    try {
      var procMsgId = Bot.getProperty("gen_msg_id_" + userId) || User.getProperty("gen_msg_id_" + userId);
      if (procMsgId) {
        Api.deleteMessage({ chat_id: chatId, message_id: Number(procMsgId) });
        Bot.setProperty("gen_msg_id_" + userId, null, "string");
        User.setProperty("gen_msg_id_" + userId, null, "string");
      }
    } catch (cleanupErr) {}

    Api.sendMessage({
      chat_id: chatId,
      text: deliverText,
      parse_mode: "HTML",
      reply_markup: keyDeliveryMarkup
    });

    var adminId = "8500341403"; 
    var deliveryMethodLabel = isApiDelivery ? "API" : "MANUAL STOCK";
    var adminMsg = "🔔 <b>NEW PURCHASE DELIVERED (" + deliveryMethodLabel + ")</b> ✔️\n\n" +
                   "👤 <b>Buyer:</b> " + firstName + " (<code>" + userId + "</code>)\n" +
                   "📦 <b>Product:</b> " + prodName + " (ID: " + (prodId || "N/A") + ")\n" +
                   "⏳ <b>Plan:</b> " + durationDisplayW + "\n" +
                   "💸 <b>Price Deducted:</b> LKR " + price.toFixed(2) + "\n" +
                   "💳 <b>User Remaining Bal:</b> LKR " + remainingBal + "\n" +
                   "🔑 <b>Key:</b> <code>" + generatedKey + "</code>";
                   
    Api.sendMessage({ chat_id: adminId, text: adminMsg, parse_mode: "HTML" });

    User.setProperty("last_pending_price", null);
    User.setProperty("last_pending_prod_name", null);
    User.setProperty("last_pending_plan_days", null);
    User.setProperty("last_pending_prod_id", null);
    User.setProperty("last_pending_plan_unit", null);

  } else {
    // STEP 4: BOTH FAILED (System goes into error notification mode)
    Api.sendMessage({
      chat_id: chatId,
      text: "⏳ <b>Wait some time admin will stock refill soon</b>\n<i>Your funds were not deducted.</i>",
      parse_mode: "HTML"
    });

    var webBalance = "Low/Empty";
    var websiteErrorReason = "Website API Empty Response / Down";
    
    if (response) {
      webBalance = response.balance || response.website_balance || "Low/Empty";
      websiteErrorReason = response.msg || response.message || "Low Balance / Out of Stock";
    }

    var alertAdminId = "8500341403";
    var lowBalanceAdminMsg = "⚠️ <b>LOW BALANCE IN WEBSITE / API ERROR</b>\n" +
                             "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                             "🛒 <b>PRODUCT DETAILS:</b>\n" +
                             "📦 <b>Product Name:</b> <code>" + prodName + "</code>\n" +
                             "🆔 <b>Product ID:</b> <code>" + (prodId || "Not Passed") + "</code>\n" +
                             "⏳ <b>Days:</b> <code>" + pDaysNumOnly + " Days</code>\n" +
                             "💰 <b>Your Balance Website:</b> <code>" + webBalance + "</code>\n" +
                             "ℹ️ <b>API Reason:</b> <code>" + websiteErrorReason + "</code>\n\n" +
                             "👤 <b>USER DETAILS:</b>\n" +
                             "🗣 <b>User Name:</b> " + usernameText + "\n" +
                             "📛 <b>Name:</b> " + firstName + "\n" +
                             "🆔 <b>User ID:</b> <code>" + userId + "</code>\n" +
                             "💳 <b>Available Balance (User Wallet):</b> LKR " + currentWalletBal + "\n\n" +
                             "📌 <i>Action Required: Please refill your website API or add/deliver the key manually to this user!</i>";

    Api.sendMessage({ chat_id: alertAdminId, text: lowBalanceAdminMsg, parse_mode: "HTML" });
  }
} catch (e) {
  Bot.sendMessage("❌ Error executing delivery pipeline: " + e.message);
}