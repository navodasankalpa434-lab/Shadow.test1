/**#command
name: /allkey
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403"; // Your Admin ID
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  var productList = [];
  try {
    productList = Bot.getProperty("stored_products") || [];
  } catch (err) {
    productList = [];
  }

  var inlineButtons = [];

  // 🛡️ SYSTEM SAFEGUARD: if the master product data crashes, use the standard hardcoded check as a fallback
  if (!productList || productList.length === 0) {
    // If the list is empty, show the list paths manually
    inlineButtons.push([
      { text: "🔄 Load DRIP CLIENT (1 Day)", callback_data: "/view_keys_list DRIP CLIENT|1_Day" }
    ]);
  } else {
    // Standard dynamic listing execution loop
    for (var i = 0; i < productList.length; i++) {
      var product = productList[i];
      if (!product || !product.name) continue;

      var plans = product.plans || [];
      // Default configurations display if plans empty
      if (plans.length === 0) {
        plans = [{ days: "1" }, { days: "7" }];
      }

      for (var j = 0; j < plans.length; j++) {
        var plan = plans[j];
        if (!plan || !plan.days) continue;
        
        var cleanProdName = product.name.trim();
        var cleanPlanDays = String(plan.days).trim() + "_Day";
        
        var stockKeyText = "stock_" + cleanProdName + "_" + cleanPlanDays;
        var currentStock = Bot.getProperty(stockKeyText) || [];

        inlineButtons.push([
          {
            text: cleanProdName.toUpperCase() + " (" + plan.days + " Days) - [" + currentStock.length + " Keys]",
            callback_data: "/view_keys_list " + cleanProdName + "|" + cleanPlanDays
          }
        ]);
      }
    }
  }

  // Final menu check interface safety attachment
  if (inlineButtons.length === 0) {
    inlineButtons.push([{ text: "🔄 Refresh Stock Matrix", callback_data: "/allkey" }]);
  }

  var menuText = "<blockquote><b>🔑 GLOBAL STOCK AUDIT LOGS</b>\n\n" +
                 "<i>The buttons below show the live stock status of each product and its plan. Click to see all keys:</i></blockquote>";

  Bot.sendMessage(menuText, {
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: inlineButtons })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Master Inventory Render Error: " + err.message);
}