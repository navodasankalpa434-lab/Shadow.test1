/**#command
name: /dash_error
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Dashboard update failed in Discord: forget the old message so the next update creates a fresh one
try {
  Bot.setProperty("dash_message_id", "", "string");
  Api.sendMessage({ chat_id: "8500341403", parse_mode: "HTML",
    text: "⚠️ <b>Discord dashboard update failed.</b>\nSend <code>/dashboard</code> to create a new one. If it keeps failing, check the webhook with <code>/settings discord URL</code>." });
} catch (e) {}
return;