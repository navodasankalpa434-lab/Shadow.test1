/**#command
name: /history_receipt
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

var SHOP_NAME = String(Bot.getProperty("store_name") || "Shadow and Scrapy Panel Store").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 🧾 Sends the user's full purchase history as a downloadable .txt file
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;
  var userKeys = User.getProperty("my_purchased_keys") || [];

  if (userKeys.length === 0) {
    Bot.sendMessage("<blockquote>🧾 <b>No purchase history found!</b>\n<i>You have not bought anything yet.</i></blockquote>", { parse_mode: "HTML" });
    return;
  }

  var lines = [];
  lines.push("=========================================");
  lines.push("       FF PANEL ADMIN — PURCHASE RECEIPT");
  lines.push("=========================================");
  lines.push("User ID     : " + userId);
  lines.push("Name        : " + ((user.first_name || "") + (user.last_name ? " " + user.last_name : "")));
  lines.push("Username    : " + (user.username ? "@" + user.username : "N/A"));
  lines.push("Generated   : " + new Date().toLocaleString());
  lines.push("Total Orders: " + userKeys.length);
  lines.push("=========================================\n");

  var totalSpent = 0;
  for (var i = 0; i < userKeys.length; i++) {
    var k = userKeys[i];
    var pName = k.productName || k.product || "N/A";
    var pPrice = Number(k.cost || k.price || 0);
    var pKey = k.key || "N/A";
    var pDays = k.days || "N/A";
    var pDate = k.date || "N/A";
    totalSpent += pPrice;

    lines.push("Order #" + (i + 1));
    lines.push("-----------------------------------------");
    lines.push("Product   : " + pName);
    lines.push("Duration  : " + pDays);
    lines.push("Price     : Rs. " + pPrice.toFixed(2));
    lines.push("Key       : " + pKey);
    lines.push("Date      : " + pDate);
    lines.push("");
  }

  lines.push("=========================================");
  lines.push("Total Amount Spent: Rs. " + totalSpent.toFixed(2));
  lines.push("=========================================");
  lines.push("Thank you for shopping with " + SHOP_NAME + "!");

  var receiptText = lines.join("\n");

  Api.sendDocument({
    chat_id: chatId,
    document: {
      content: receiptText,
      filename: "Receipt_" + userId + ".txt"
    },
    caption: "<blockquote>🧾 <b>YOUR PURCHASE RECEIPT</b></blockquote>\n<i>Your full purchase history is in this file.</i>",
    parse_mode: "HTML"
  });

  Api.sendMessage({
    chat_id: chatId,
    text: "<i>The receipt file has been sent above 👆</i>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: [[
        { text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "5893163582194978381" }
      ]]
    })
  });

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Receipt Error: " + err.message, { parse_mode: "HTML" });
}