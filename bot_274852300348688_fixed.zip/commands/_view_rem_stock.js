/**#command
name: /view_rem_stock
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  // Get the slug from the callback data
  var slug = params ? params.trim() : "";
  if (!slug) return;

  var currentStock = Bot.getProperty("ff_stock_" + slug) || [];
  var categories = Bot.getProperty("ff_categories") || {};
  var catName = categories[slug] && categories[slug].name ? categories[slug].name : slug.toUpperCase();

  if (!Array.isArray(currentStock) || currentStock.length === 0) {
    Bot.sendMessage("📭 <b>" + catName + "</b> has no stock right now.", {parse_mode: "HTML"});
    return;
  }

  var keyboard = [];
  
  // Create one button for each account
  for (var i = 0; i < currentStock.length; i++) {
    var accountData = currentStock[i]; // Format: email|pass|price
    
    keyboard.push([
      { 
        text: "❌ " + accountData, 
        callback_data: "/confirm_rem_stock " + slug + " " + i 
      }
    ]);
  }

  // Back button to return to the main list
  keyboard.push([{ text: "🔙 Back to Categories", callback_data: "/remstock_id" }]);

  Api.sendMessage({
    chat_id: adminId,
    text: "🛒 <b>" + catName + " Stock List:</b>\n\n<i>Click any account button below to delete it:</i>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: keyboard })
  });

} catch (e) {
  Bot.sendMessage("Error: " + e.message);
}