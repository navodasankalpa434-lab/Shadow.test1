/**#command
name: /addplan
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// Add a plan with buttons:
//   /addplan                 -> pick a product
//   /addplan_pick_N          -> pick a length (minutes, hours, days, months, years, lifetime)
//   /addplan_unit_N_UNIT     -> type "LENGTH | PRICE | RESELLER PRICE" (lifetime: "PRICE | RESELLER PRICE")
try {
  var callerId = String(chat.chatid);
  if (!isCoAdminId(callerId)) { Bot.sendMessage("❌ Only the owner and co-admins can add plans."); return; }

  var products = Bot.getProperty("stored_products") || [];
  if (typeof products === "string") { try { products = JSON.parse(products); } catch (e) { products = []; } }
  if (!Array.isArray(products)) { products = []; }

  // Button presses pass their value in "params"; typed text arrives in "message"
  var typedMsg = (typeof message !== "undefined" && message) ? String(message).trim() : "";
  var btnVal = (typeof params !== "undefined" && params) ? String(params).trim() : "";
  var waitingStep = String(User.getProperty("addplan_step") || "");
  // While a plan is waiting for numbers, typed text is the input. Otherwise use the button value.
  var raw = (waitingStep && typedMsg && typedMsg.charAt(0) !== "/") ? typedMsg : (btnVal || typedMsg);
  raw = raw.replace(/^\/addplan_?/i, "").trim();
  User.setProperty("addplan_step", "", "string");

  var UNITS = [
    { key: "minute", label: "Minutes" }, { key: "hour", label: "Hours" }, { key: "day", label: "Days" },
    { key: "month", label: "Months" }, { key: "year", label: "Years" }, { key: "lifetime", label: "Lifetime" }
  ];

  // One-line format:  Product | Length | Normal price | Reseller price
  //   e.g.  Shadow | 1d | 500 | 400     (length: 1d, 1h, 30m, 1mo, 1y, or lifetime)
  if (raw.indexOf("|") > -1) {
    var lp = raw.split("|").map(function (x) { return x.trim(); });
    var lpProd = null;
    for (var li = 0; li < products.length; li++) {
      if (products[li] && String(products[li].name).trim().toLowerCase() === lp[0].toLowerCase()) { lpProd = products[li]; break; }
    }
    if (!lpProd) { Bot.sendMessage("❌ Product <b>" + lp[0] + "</b> not found. Add it first: <code>/addproduct " + lp[0] + "</code>", { parse_mode: "HTML" }); return; }
    var lpKey = null, lpLen = 0, lpPrice = NaN, lpRes = NaN;
    if (lp[1] && lp[1].toLowerCase() === "lifetime") { lpKey = "lifetime"; lpLen = 36500; lpPrice = parseFloat(lp[2]); lpRes = parseFloat(lp[3]); }
    else {
      var lm = (lp[1] || "").match(/^([0-9.]+)\s*([a-zA-Z]*)$/);
      if (!lm) { Bot.sendMessage("❌ Length must look like <code>1d</code>, <code>1h</code>, <code>30m</code>, <code>1mo</code>, <code>1y</code> or <code>lifetime</code>.", { parse_mode: "HTML" }); return; }
      lpLen = parseFloat(lm[1]); var lu = lm[2].toLowerCase();
      if (lu === "" || lu === "d" || lu.indexOf("day") === 0) { lpKey = "day"; }
      else if (lu === "h" || lu.indexOf("hour") === 0) { lpKey = "hour"; }
      else if (lu === "mo" || lu.indexOf("mon") === 0) { lpKey = "month"; }
      else if (lu === "m" || lu.indexOf("min") === 0) { lpKey = "minute"; }
      else if (lu === "y" || lu.indexOf("year") === 0) { lpKey = "year"; }
      else { Bot.sendMessage("❌ Unknown length unit. Use d, h, m, mo, y or lifetime.", { parse_mode: "HTML" }); return; }
      lpPrice = parseFloat(lp[2]); lpRes = parseFloat(lp[3]);
    }
    if (isNaN(lpPrice) || lpPrice <= 0) { Bot.sendMessage("❌ Normal price must be a number greater than 0.", { parse_mode: "HTML" }); return; }
    if (isNaN(lpRes) || lpRes <= 0) { lpRes = lpPrice; }
    var lpDays = lpLen, lpDisplay;
    if (lpKey === "month") { lpDays = lpLen * 30; lpDisplay = lpLen + " " + (lpLen === 1 ? "Month" : "Months"); }
    else if (lpKey === "year") { lpDays = lpLen * 365; lpDisplay = lpLen + " " + (lpLen === 1 ? "Year" : "Years"); }
    else if (lpKey === "lifetime") { lpDays = 36500; lpDisplay = "Lifetime"; }
    else {
      var lw = { minute: ["Minute", "Minutes"], hour: ["Hour", "Hours"], day: ["Day", "Days"] }[lpKey];
      lpDisplay = lpLen + " " + (lpLen === 1 ? lw[0] : lw[1]);
    }
    if (!Array.isArray(lpProd.plans)) { lpProd.plans = []; }
    lpProd.plans.push({ days: lpDays, unit: lpKey, durationDisplay: lpDisplay,
                        normal_price: lpPrice, reseller_price: lpRes, name_on_website: lpDisplay });
    Bot.setProperty("stored_products", products, "json");
    Bot.sendMessage("✅ <b>Plan added</b>\n📦 " + lpProd.name + "\n🕒 " + lpDisplay +
      "\n💰 Normal: LKR " + lpPrice + "\n🏷 Reseller: LKR " + lpRes, { parse_mode: "HTML" });
    return;
  }

  if (raw === "") {
    Bot.sendMessage("📦 <b>Add a plan</b>\n\nSend in one line:\n<code>/addplan PRODUCT | LENGTH | NORMAL PRICE | RESELLER PRICE</code>\n\n" +
      "Examples:\n<code>/addplan Shadow | 1d | 500 | 400</code>\n<code>/addplan Shadow | 1mo | 1500 | 1200</code>\n<code>/addplan Shadow | lifetime | 9000 | 8000</code>\n\n" +
      "Length units: d = days, h = hours, m = minutes, mo = months, y = years", { parse_mode: "HTML" });
    return;
  }

  // Step 1: pick a product
  if (raw === "") {
    User.setProperty("addplan_step", "", "string");
    if (products.length === 0) {
      Bot.sendMessage("❌ No products yet. Add one first: <code>/addproduct PRODUCT NAME</code>", { parse_mode: "HTML" });
      return;
    }
    var pickRows = [];
    for (var i = 0; i < products.length; i++) {
      if (!products[i]) continue;
      pickRows.push([{ text: products[i].name, callback_data: "/addplan pick " + i, style: "primary" }]);
    }
    Api.sendMessage({ chat_id: callerId, parse_mode: "HTML",
      text: "📦 <b>Choose a product for the new plan:</b>", reply_markup: JSON.stringify({ inline_keyboard: pickRows }) });
    return;
  }

  // Step 2: pick a length
  if (/^pick\s+\d+$/.test(raw)) {
    var pIdx = raw.split(/\s+/)[1];
    var pickProd = products[Number(pIdx)];
    if (!pickProd) { Bot.sendMessage("❌ Product not found. Start again with <code>/addplan</code>.", { parse_mode: "HTML" }); return; }
    var unitRows = [[], [], []];
    for (var u = 0; u < UNITS.length; u++) {
      unitRows[Math.floor(u / 2)].push({ text: UNITS[u].label, callback_data: "/addplan unit " + pIdx + " " + UNITS[u].key, style: "primary" });
    }
    Api.sendMessage({ chat_id: callerId, parse_mode: "HTML",
      text: "🕒 <b>" + pickProd.name + "</b>\nChoose the plan length:", reply_markup: JSON.stringify({ inline_keyboard: unitRows }) });
    return;
  }

  // Step 3: ask for the numbers
  if (/^unit\s+\d+\s+\w+$/.test(raw)) {
    var uParts = raw.split(/\s+/);
    var uIdx = uParts[1];
    var uKey = uParts[2];
    var uProd = products[Number(uIdx)];
    if (!uProd) { Bot.sendMessage("❌ Product not found. Start again with <code>/addplan</code>.", { parse_mode: "HTML" }); return; }
    User.setProperty("addplan_step", uIdx + ":" + uKey, "string");
    var askText = (uKey === "lifetime")
      ? "Send the <b>PRICE</b> and optional <b>RESELLER PRICE</b>.\n<i>Example: 1500 | 1200</i>"
      : "Send the <b>LENGTH | PRICE | RESELLER PRICE</b>.\n<i>Example: 7 | 500 | 400</i>\n(Reseller price is optional.)";
    Api.sendMessage({ chat_id: callerId, parse_mode: "HTML",
      text: "✏️ <b>" + uProd.name + "</b> - " + uKey.charAt(0).toUpperCase() + uKey.slice(1) + "\n\n" + askText });
    return;
  }

  // Step 4: typed numbers -> save the plan
  var step = String(User.getProperty("addplan_step") || "");
  if (step && raw !== "") {
    var sp = step.split(":");
    var sIdx = Number(sp[0]);
    var sKey = sp[1];
    var sProd = products[sIdx];
    User.setProperty("addplan_step", "", "string");
    if (!sProd) { Bot.sendMessage("❌ Product not found. Start again with <code>/addplan</code>.", { parse_mode: "HTML" }); return; }

    var nums = raw.split("|").map(function (x) { return x.trim(); });
    var len = 0, price = NaN, resPrice = NaN;
    if (sKey === "lifetime") { price = parseFloat(nums[0]); resPrice = parseFloat(nums[1]); len = 36500; }
    else { len = parseFloat(nums[0]); price = parseFloat(nums[1]); resPrice = parseFloat(nums[2]); }

    if (sKey !== "lifetime" && (isNaN(len) || len <= 0)) {
      Bot.sendMessage("❌ Length must be a number greater than 0. Start again with <code>/addplan</code>.", { parse_mode: "HTML" }); return;
    }
    if (isNaN(price) || price <= 0) {
      Bot.sendMessage("❌ Price must be a number greater than 0. Start again with <code>/addplan</code>.", { parse_mode: "HTML" }); return;
    }
    if (isNaN(resPrice) || resPrice <= 0) { resPrice = price; }

    var storedDays = len;
    var display;
    if (sKey === "month") { storedDays = len * 30; display = len + " " + (len === 1 ? "Month" : "Months"); }
    else if (sKey === "year") { storedDays = len * 365; display = len + " " + (len === 1 ? "Year" : "Years"); }
    else if (sKey === "lifetime") { storedDays = 36500; display = "Lifetime"; }
    else {
      var word = { minute: ["Minute", "Minutes"], hour: ["Hour", "Hours"], day: ["Day", "Days"] }[sKey];
      display = len + " " + (len === 1 ? word[0] : word[1]);
    }

    if (!Array.isArray(sProd.plans)) { sProd.plans = []; }
    sProd.plans.push({ days: storedDays, unit: sKey, durationDisplay: display,
                       normal_price: price, reseller_price: resPrice, name_on_website: display });
    Bot.setProperty("stored_products", products, "json");

    Bot.sendMessage("✅ <b>Plan added</b>\n📦 " + sProd.name + "\n🕒 " + display +
      "\n💰 Price: LKR " + price + "\n🏷 Reseller: LKR " + resPrice, { parse_mode: "HTML" });
    return;
  }

  Bot.sendMessage("ℹ️ Start with <code>/addplan</code>.", { parse_mode: "HTML" });
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}