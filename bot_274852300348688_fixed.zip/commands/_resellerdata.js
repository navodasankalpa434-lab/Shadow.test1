/**#command
name: /resellerdata
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Owner-only: numbered reseller buttons, tap one to see that reseller's full data
var OWNER_ID = "8500341403";

function asList(v) {
  if (typeof v === "string") { try { v = JSON.parse(v); } catch (e) { v = []; } }
  return Array.isArray(v) ? v : [];
}
function esc(s) {
  return String(s === undefined || s === null || s === "" ? "N/A" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function isReseller(id) {
  return String(Bot.getProperty("is_reseller_" + id)) === "true";
}
function rankTierFor(total) {
  var tiers = asList(Bot.getProperty("topup_tiers"));
  var best = null;
  for (var t = 0; t < tiers.length; t++) {
    if (total >= Number(tiers[t].min) && (!best || Number(tiers[t].pct) > Number(best.pct))) { best = tiers[t]; }
  }
  return best;
}
function resellerIds() {
  var resellerListIds = asList(Bot.getProperty("resellers_list")).map(function (x) {
    return String(x && x.id !== undefined ? x.id : x);
  });
  var candidates = asList(Bot.getProperty("all_users_list")).map(String).concat(resellerListIds);
  var ids = [], seen = {};
  for (var c = 0; c < candidates.length; c++) {
    var cid = candidates[c];
    if (seen[cid] || cid === OWNER_ID) { continue; }
    seen[cid] = true;
    if (isReseller(cid) || resellerListIds.indexOf(cid) !== -1) { ids.push(cid); }
  }
  return ids;
}
function nameOf(id) {
  return Bot.getProperty("name_" + id) || "N/A";
}

try {
  if (request && request.id) {
    HTTP.post({ url: "https://api.telegram.org/bot" + bot.token + "/answerCallbackQuery", body: { callback_query_id: request.id } });
  }
  var ownerChat = String(chat.chatid);
  if (ownerChat !== OWNER_ID) {
    Bot.sendMessage("❌ Only the owner can view reseller data.", { parse_mode: "HTML" });
    return;
  }

  // Which reseller was tapped? (button sends /rdview_<id>)
  var raw = (typeof message !== "undefined" && message) ? String(message) : "";
  if (!raw && request && request.callback_query && request.callback_query.data) { raw = String(request.callback_query.data); }
  var m = raw.match(/rdview_(\d+)/);
  var ids = resellerIds();

  // ---------- DETAIL VIEW: one reseller's full data ----------
  if (m) {
    var id = m[1];
    var vv = Bot.getProperty("verified_" + id);
    var verified = (vv === true || String(vv) === "true");
    var topup = Number(Bot.getProperty("topup_total_" + id) || 0);
    var spent = Number(Bot.getProperty("total_spent_by_" + id) || 0);
    var keys = Number(Bot.getProperty("keys_sold_" + id) || 0);
    var orders = Number(Bot.getProperty("dash_orders_" + id) || 0);
    var bal = 0;
    try { bal = Number(Libs.ResourcesLib.anotherUserRes("balance", id).value() || 0); } catch (e) { bal = 0; }
    var tier = rankTierFor(topup);
    var rank = tier ? esc(tier.name || "Member") : "None";
    var disc = tier ? Number(tier.pct) : 0;
    var uname = Bot.getProperty("username_" + id) || "N/A";

    var text = "<blockquote><b>👤 RESELLER DETAILS</b></blockquote>\n" +
      "<b>Name:</b> " + esc(nameOf(id)) + "\n" +
      "<b>Username:</b> " + esc(uname) + "\n" +
      "<b>Chat ID:</b> <code>" + esc(id) + "</code>\n" +
      "<b>Verified number:</b> <code>" + esc(Bot.getProperty("phone_" + id)) + "</code> " + (verified ? "✅" : "❌") + "\n" +
      "<b>Joined:</b> " + esc(Bot.getProperty("joined_date_" + id)) + "\n" +
      "━━━━━━━━━━━━━━━━━━━━\n" +
      "<b>Rank:</b> " + rank + "\n" +
      "<b>Discount level:</b> " + disc + "% off\n" +
      "<b>Total top-ups:</b> LKR " + topup.toFixed(2) + "\n" +
      "<b>Wallet balance:</b> LKR " + bal.toFixed(2) + "\n" +
      "<b>Total orders:</b> " + orders + "\n" +
      "<b>Total keys bought:</b> " + keys + "\n" +
      "<b>Total spent:</b> LKR " + spent.toFixed(2) + "\n" +
      "━━━━━━━━━━━━━━━━━━━━\n" +
      "<b>🧾 Purchase history</b>\n";

    var hist = asList(Bot.getProperty("history_" + id));
    if (hist.length === 0) {
      text += "<i>No purchases yet.</i>";
    } else {
      var shown = hist.slice(-20);
      for (var h = shown.length - 1; h >= 0; h--) {
        var r = shown[h] || {};
        var when = r.date ? String(r.date).replace("T", " ").substring(0, 16) : "-";
        text += "• " + esc(when) + " | " + esc(r.product) + " | " + esc(r.plan) +
                " | LKR " + Number(r.price || 0).toFixed(2) + "\n" +
                (r.key ? "  🔑 <code>" + esc(r.key) + "</code>\n" : "");
      }
      if (hist.length > 20) { text += "<i>Showing last 20 of " + hist.length + " purchases.</i>"; }
    }

    Api.sendMessage({
      chat_id: ownerChat,
      text: text,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: [[{ text: "⬅️ Back to Resellers", callback_data: "/resellerdata", style: "primary" }]] })
    });
    return;
  }

  // ---------- LIST VIEW: numbered buttons, one per reseller ----------
  if (ids.length === 0) {
    Bot.sendMessage("⚠️ <b>No resellers yet.</b>", { parse_mode: "HTML" });
    return;
  }

  var rows = [];
  for (var i = 0; i < ids.length && rows.length < 100; i++) {
    var label = (i + 1) + ". " + String(nameOf(ids[i])).substring(0, 40);
    rows.push([{ text: label, callback_data: "/rdview_" + ids[i], style: "primary" }]);
  }

  Api.sendMessage({
    chat_id: ownerChat,
    text: "<blockquote><b>💎 RESELLERS DATA</b>\n<i>Total resellers: " + ids.length +
          "</i></blockquote>\nTap a reseller to see their full data.",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: rows })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}
