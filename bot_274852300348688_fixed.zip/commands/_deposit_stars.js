/**#command
name: /deposit_stars
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}


// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// ⭐ TELEGRAM STARS — Deposit screen (Wallet top-up in Stars)
// Note: Stars balance is tracked SEPARATELY from the Rupee/UPI wallet,
// since Telegram Stars (XTR) is its own currency and can't be mixed 1:1
// with rupee balance without a fixed conversion rate.
// =========================================================

if (String(user.telegramid) !== "8500341403" && !isCoAdminId(String(user.telegramid))) { Api.sendMessage({ chat_id: user.telegramid, text: "🔒 Only the admin can add funds. Please contact the admin to top up your wallet.", parse_mode: "HTML" }); return; }
try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;
  var starsBalance = Number(Bot.getProperty("stars_balance_" + userId) || 0);

  var text =
    "<blockquote>⭐ <b>DEPOSIT TELEGRAM STARS</b></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "⭐ <b>Current Stars Balance:</b> <code>" + starsBalance + "</code>\n\n" +
    "<i>Choose an amount below, or enter a custom amount. Payment goes through Telegram's official Stars checkout — instant &amp; secure.</i>\n" +
    "━━━━━━━━━━━━━━━━━━━━━";

  var buttons = [
    [
      { text: "⭐ 50", callback_data: "/send_stars_invoice deposit 50", style: "primary" },
      { text: "⭐ 100", callback_data: "/send_stars_invoice deposit 100", style: "primary" },
      { text: "⭐ 250", callback_data: "/send_stars_invoice deposit 250", style: "primary" }
    ],
    [
      { text: "⭐ 500", callback_data: "/send_stars_invoice deposit 500", style: "primary" },
      { text: "⭐ 1000", callback_data: "/send_stars_invoice deposit 1000", style: "primary" }
    ],
    [
      { text: "Custom Amount", callback_data: "/custom_stars_amount", style: "success", icon_custom_emoji_id: "6312263493051489212" }
    ],
    [
      { text: "Back to Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
    ]
  ];

  if (request && request.message && !request.message.photo) {
    Api.editMessageText({ chat_id: String(chatId), message_id: Number(request.message.message_id), text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  } else {
    if (request && request.message && request.message.photo) {
      try { Api.deleteMessage({ chat_id: chatId, message_id: request.message.message_id }); } catch (e) {}
    }
    Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}