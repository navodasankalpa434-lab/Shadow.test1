/**#command
name: /transfer_ownership
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👑 OWNER-ONLY — Transfer Ownership
// Usage: /transfer_ownership USERID
// ⚠️ IMPORTANT LIMITATION: this updates the dynamic "owner_id" property that
// NEW commands (admin panel, coupon, co-admin, maintenance) check. Older
// admin-only commands in this bot (addproduct, addkey, addbal, etc.) still
// have the original owner ID hardcoded as literal text in ~30 files — those
// would need a separate one-time refactor to fully recognize a new owner too.
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "8500341403";
  var currentChatId = String(chat.chatid);

  if (currentChatId !== ownerId) {
    Bot.sendMessage("❌ Only the current Owner can transfer ownership!");
    return;
  }

  if (!params || params.trim() === "") {
    Bot.sendMessage("⚠️ <b>Format:</b> <code>/transfer_ownership USERID</code>", { parse_mode: "HTML" });
    return;
  }

  var newOwnerId = params.trim();
  if (isNaN(Number(newOwnerId))) {
    Bot.sendMessage("❌ A valid numeric User ID is required!");
    return;
  }
  if (newOwnerId === ownerId) {
    Bot.sendMessage("❌ That is already you!");
    return;
  }

  User.setProperty("pending_ownership_transfer_to", newOwnerId, "string");

  Api.sendMessage({
    chat_id: chat.chatid,
    text: "<blockquote>⚠️ <b>CONFIRM OWNERSHIP TRANSFER</b></blockquote>\n\n" +
          "You are about to transfer ownership to <code>" + newOwnerId + "</code>.\n" +
          "<b>This action applies immediately and you will no longer be the Owner!</b>\n\n" +
          "<i>Are you sure?</i>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: [[
        { text: "Confirm Transfer", callback_data: "/confirm_ownership_transfer", style: "danger", icon_custom_emoji_id: "6215386799133433653" },
        { text: "Cancel", callback_data: "/cancel_ownership_transfer", style: "primary" }
      ]]
    })
  });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}