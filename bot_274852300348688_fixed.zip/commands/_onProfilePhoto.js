/**#command
name: /onProfilePhoto
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Role: Admin, Reseller, Customer (unverified shows as Visitor)
function roleFor(id) {
  id = String(id);
  if (id === "8500341403") { return "🛡 Admin"; }
  var cl = Bot.getProperty("co_admin_list") || [];
  if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e) { cl = []; } }
  var isAdmin = String(Bot.getProperty("co_admin_" + id)) === "true" || (Array.isArray(cl) && cl.map(String).indexOf(id) !== -1);
  if (isAdmin) { return "🛡 Admin"; }
  var rl = Bot.getProperty("resellers_list") || [];
  if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e2) { rl = []; } }
  var isRes = String(Bot.getProperty("is_reseller_" + id)) === "true" ||
              (Array.isArray(rl) && rl.some(function (x) { return String(x && x.id !== undefined ? x.id : x) === id; }));
  if (isRes) { return "🔴 Reseller"; }
  var vv = Bot.getProperty("verified_" + id);
  if (!(vv === true || String(vv) === "true")) { return "👀 Visitor"; }
  return "✅ Customer";
}
// Rank: the best top-up tier the customer has reached
function rankFor(id) {
  var total = Number(Bot.getProperty("topup_total_" + id) || 0);
  var tiers = Bot.getProperty("topup_tiers") || [];
  if (typeof tiers === "string") { try { tiers = JSON.parse(tiers); } catch (e) { tiers = []; } }
  if (!Array.isArray(tiers)) { tiers = []; }
  var best = null;
  for (var t = 0; t < tiers.length; t++) {
    if (total >= Number(tiers[t].min) && (!best || Number(tiers[t].pct) > Number(best.pct))) { best = tiers[t]; }
  }
  return best ? (best.name + " · " + best.pct + "% off") : "None · 0% off";
}
// Menu header: role, verification and rank
function statusBlockFor() {
  var sid = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
  var vv = Bot.getProperty("verified_" + sid);
  var ver = (vv === true || String(vv) === "true") ? "✅ Verified account" : "🔴 Not verified (tap Verify Account)";
  return "<blockquote><b>" + roleFor(sid) + "</b>\n" + ver + "\n🏅 Rank: " + rankFor(sid) + "</blockquote>\n";
}

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 👤 COMMAND = /onProfilePhoto (Premium Profile — Step 2: final render)
// ✅ BUG FIX: reply_markup was sending a raw object (JSON.stringify was not
// used) when a DP was available — that is why the "Back to Menu" button
// did not work or render when sent with a DP.
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;
  var adminId = "8500341403";

  // 📸 Get the DP file_id (if the user has a public profile photo)
  var dpFileId = null;
  try {
    var res = (typeof content === "object" && content) ? content : JSON.parse(content);
    if (res && res.ok && res.result && res.result.total_count > 0) {
      var sizes = res.result.photos[0];
      dpFileId = sizes[sizes.length - 1].file_id;
    }
  } catch (e) {}

  // 💎 Premium Emoji Set
  var e_profile = "<tg-emoji emoji-id='6102818532393750087'>👤</tg-emoji>";
  var e_id       = "<tg-emoji emoji-id='5902002809573740949'>🆔</tg-emoji>";
  var e_money    = "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji>";
  var e_crown    = "<tg-emoji emoji-id='6102856637343600044'>👑</tg-emoji>";
  var e_calendar = "<tg-emoji emoji-id='6266866272848321043'>📅</tg-emoji>";
  var e_key      = "<tg-emoji emoji-id='6284816251143331422'>🔑</tg-emoji>";
  var e_invest   = "<tg-emoji emoji-id='5330237710655306682'>📊</tg-emoji>";
  var e_back     = "<tg-emoji emoji-id='5893163582194978381'>⬅️</tg-emoji>";

  var userBalance = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return (resBal + bonusBal).toFixed(2);
  })();

  var username = user.username ? "@" + user.username : "Not Set";
  var fullName = (user.first_name || "") + (user.last_name ? " " + user.last_name : "");

  var role, roleEmojiHtml;
  if (userId === adminId) {
    role = "Admin"; roleEmojiHtml = e_crown;
  } else if (isCoAdminId(userId)) {
    role = "Co-Admin"; roleEmojiHtml = e_crown;
  } else {
    var isReseller = Bot.getProperty("is_reseller_" + userId);
    var hasReseller = (isReseller === true || String(isReseller).toLowerCase() === "true");
    role = hasReseller ? "Reseller 🔰" : "Regular User";
    roleEmojiHtml = hasReseller ? "<tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji>" : "🙋";
  }

  var joinedDate = Bot.getProperty("joined_date_" + userId) || "N/A";
  var purchasedKeys = User.getProperty("my_purchased_keys") || [];
  var totalKeys = Array.isArray(purchasedKeys) ? purchasedKeys.length : 0;
  var totalInvested = Number(Bot.getProperty("total_spent_by_" + userId) || 0).toFixed(2);

  // 🎨 Premium profile layout (matches the reference design)
  role = roleFor(userId);
  var caption =
    "<blockquote>" + e_profile + " <b>USER PROFILE</b> " + e_profile + "</blockquote>\n\n" +
    e_id + " <b>ID:</b> <code>" + userId + "</code>\n" +
    "<b>Name:</b> " + fullName + "\n" +
    "<b>Username:</b> " + username + "\n" +
    e_calendar + " <b>Joined:</b> " + joinedDate + "\n" +
    roleEmojiHtml + " <b>Account Type:</b> " + role + "\n" +
    "<b>Rank:</b> " + rankFor(userId) + "\n" +
    "<b>Total top-up:</b> LKR " + Number(Bot.getProperty("topup_total_" + userId) || 0) + "\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    e_money + " <b>Balance:</b> LKR " + userBalance + "\n" +
    e_invest + " <b>Spent:</b> LKR " + totalInvested + "\n" +
    e_key + " <b>Keys:</b> " + totalKeys + "\n\n" +
    "<i>" + (dpFileId ? "Profile photo fetched from Telegram." : "No profile photo set.") + "</i>";

  var keyboard = [
    [
      { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6284816251143331422" },
      { text: "Add Top Up", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "6312263493051489212" }
    ],
    [
      { text: "Back", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
    ]
  ];

  if (dpFileId) {
    Api.sendPhoto({
      chat_id: chatId,
      photo: dpFileId,
      caption: caption,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: keyboard })
    });
  } else {
    Api.sendMessage({
      chat_id: chatId,
      text: caption,
      parse_mode: "HTML",
      reply_markup: JSON.stringify({ inline_keyboard: keyboard })
    });
  }

} catch (err) {
  Bot.sendMessage("⚠️ Profile Error: " + err.message, { parse_mode: "HTML" });
}