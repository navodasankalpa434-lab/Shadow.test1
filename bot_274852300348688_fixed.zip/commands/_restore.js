/**#command
name: /restore
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Owner restore: send the backup parts in order (each part starts with /restore N/TOTAL)
try {
  if (String(chat.chatid) !== "8500341403") { Bot.sendMessage("❌ Only the owner can restore a backup."); return; }

  var raw = (typeof message !== "undefined" && message) ? String(message).trim() : "";
  raw = raw.replace(/^\/restore\s*/i, "").trim();
  var pm = raw.match(/^(\d+)\/(\d+)\s+([\s\S]*)$/);
  var fullText = raw;

  if (pm) {
    var pn = Number(pm[1]);
    var ptotal = Number(pm[2]);
    if (pn === 1) { for (var c = 1; c <= 200; c++) { Bot.setProperty("restore_buf_" + c, "", "string"); } }
    Bot.setProperty("restore_buf_" + pn, pm[3].trim(), "string");
    var joined = "";
    var have = 0;
    for (var i = 1; i <= ptotal; i++) {
      var piece = String(Bot.getProperty("restore_buf_" + i) || "");
      if (!piece) { break; }
      joined += piece;
      have++;
    }
    if (have < ptotal) {
      Bot.sendMessage("📥 Part " + pn + "/" + ptotal + " received. Send the remaining parts (" + (ptotal - have) + " left).", { parse_mode: "HTML" });
      return;
    }
    fullText = joined;
    for (var cl = 1; cl <= ptotal; cl++) { Bot.setProperty("restore_buf_" + cl, "", "string"); }
  }

  fullText = fullText.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  var data;
  try { data = JSON.parse(fullText); } catch (pe) {
    Bot.sendMessage("❌ That is not a complete backup. Send all parts in order, starting with /restore 1/N.", { parse_mode: "HTML" });
    return;
  }
  if (!data || ["SHADOW-BACKUP-1", "SHADOW-BACKUP-2", "SHADOW-BACKUP-3"].indexOf(data.version) === -1) {
    Bot.sendMessage("❌ Unknown backup version.", { parse_mode: "HTML" });
    return;
  }

  // Settings, rank levels, discounts and coupons
  var sKeys = Object.keys(data.settings || {});
  for (var si = 0; si < sKeys.length; si++) {
    var sv = data.settings[sKeys[si]];
    Bot.setProperty(sKeys[si], sv, typeof sv === "string" ? "string" : "json");
  }
  var dKeys = Object.keys(data.discounts || {});
  for (var di = 0; di < dKeys.length; di++) { Bot.setProperty(dKeys[di], data.discounts[dKeys[di]], "string"); }
  var cKeys = Object.keys(data.coupons || {});
  for (var coi = 0; coi < cKeys.length; coi++) { Bot.setProperty(cKeys[coi], data.coupons[cKeys[coi]], "json"); }

  // Stock keys: set what the backup has, clear the rest for every product and plan
  var rprods = Array.isArray(data.settings && data.settings.stored_products) ? data.settings.stored_products : [];
  var rstock = data.stock || {};
  for (var ri = 0; ri < rprods.length; ri++) {
    var rp = rprods[ri];
    if (!rp || !rp.name) { continue; }
    var rplans = Array.isArray(rp.plans) ? rp.plans : [];
    for (var rj = 0; rj < rplans.length; rj++) {
      var rd = String(rplans[rj].days).replace(/[^0-9.]/g, "");
      var rn = String(rp.name).trim();
      var rcands = ["manual_keys_" + rn.toUpperCase() + "_" + rd, "stock_" + rn + "_" + rd + "_Day",
                    "stock_" + rn + "_" + rd, "stock_" + ri + "_" + rj, "stock_" + rn + "_" + rd + "d_Day"];
      for (var rk = 0; rk < rcands.length; rk++) {
        if (rstock[rcands[rk]] !== undefined) { Bot.setProperty(rcands[rk], rstock[rcands[rk]], "json"); }
        else { Bot.setProperty(rcands[rk], [], "json"); }
      }
    }
  }

  // Pending top-up requests
  var pKeys = Object.keys(data.pending || {});
  for (var pi = 0; pi < pKeys.length; pi++) { Bot.setProperty(pKeys[pi], data.pending[pKeys[pi]], "string"); }

  // Customers
  var users = data.users || [];
  var restored = 0;
  for (var j = 0; j < users.length; j++) {
    var ru = users[j];
    if (!ru || !ru.id) { continue; }
    var rid = String(ru.id);
    Bot.setProperty("verified_" + rid, ru.verified === true || String(ru.verified) === "true", "boolean");
    if (ru.phone) { Bot.setProperty("phone_" + rid, String(ru.phone), "string"); }
    if (ru.joined) { Bot.setProperty("joined_date_" + rid, String(ru.joined), "string"); }
    Bot.setProperty("topup_total_" + rid, String(ru.topup_total || 0), "string");
    Bot.setProperty("is_reseller_" + rid, ru.reseller === true || String(ru.reseller) === "true", "boolean");
    Bot.setProperty("co_admin_" + rid, ru.co_admin === true || String(ru.co_admin) === "true", "boolean");
    Bot.setProperty("dash_orders_" + rid, String(ru.orders || 0), "string");
    Bot.setProperty("keys_sold_" + rid, String(ru.keys_sold || 0), "string");
    Bot.setProperty("dash_spent_" + rid, String(ru.spent || 0), "string");
    if (ru.history && ru.history.length) { Bot.setProperty("history_" + rid, ru.history, "json"); }
    Libs.ResourcesLib.anotherUserRes("balance", rid).set(Number(ru.balance || 0));
    restored++;
  }
  Bot.setProperty("all_users_list", users.map(function (x) { return String(x.id); }), "json");

  Bot.sendMessage("✅ <b>Restore complete</b>\nSettings: " + sKeys.length + "\nStock keys: " + Object.keys(rstock).length +
                  "\nCustomers: " + restored + "\nPending top-ups: " + pKeys.length, { parse_mode: "HTML" });
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}