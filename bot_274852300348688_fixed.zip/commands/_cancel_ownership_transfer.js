/**#command
name: /cancel_ownership_transfer
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// ❌ Cancel button on the Ownership Transfer confirmation screen
// ✅ BUG FIX: previously this button used /cancel_plan_buy (wrong context — "Purchase
// Cancelled" text) and the pending transfer state was not cleared
// so by mistake, "Confirm Transfer" could be clicked again
// and an old/stale transfer could run. Both are fixed now.
// =========================================================

try {
  User.setProperty("pending_ownership_transfer_to", null, "string");

  var text = "<blockquote>❌ <b>OWNERSHIP TRANSFER CANCELLED</b></blockquote>\n\n<i>Nothing changed, you are still the Owner.</i>";

  if (request && request.message) {
    try {
      Api.editMessageText({
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: text,
        parse_mode: "HTML"
      });
    } catch (e) {
      Api.sendMessage({ chat_id: chat.chatid, text: text, parse_mode: "HTML" });
    }
  } else {
    Api.sendMessage({ chat_id: chat.chatid, text: text, parse_mode: "HTML" });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}