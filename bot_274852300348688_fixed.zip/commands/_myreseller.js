/**#command
name: /myreseller
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var userId = user.telegramid;
  var isReseller = Bot.getProperty("is_reseller_" + userId);

  if (!isReseller) {
    Bot.sendMessage("<tg-emoji emoji-id='6143299028655280273'>❌</tg-emoji> You do not have the reseller role.", { parse_mode: "HTML" });
    return;
  }

  var name = user.first_name || "N/A";
  var username = user.username ? "@" + user.username : "N/A";

  var infoText = "<blockquote><b><tg-emoji emoji-id='5346024644635804737'>🔰</tg-emoji> MY RESELLER ACCOUNT INFO</b>\n\n" +
                 "• <b>Name:</b> " + name + "\n" +
                 "• <b>User ID:</b> <code>" + userId + "</code>\n" +
                 "• <b>Username:</b> " + username + "</blockquote>";

  Bot.sendMessage(infoText, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}