/**#command
name: /dashboard
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

function salesLogAdd(entry) {
  var slog = Bot.getProperty("sales_log") || [];
  if (typeof slog === "string") { try { slog = JSON.parse(slog); } catch (e) { slog = []; } }
  if (!Array.isArray(slog)) { slog = []; }
  slog.push(entry);
  if (slog.length > 2000) { slog = slog.slice(slog.length - 2000); }
  Bot.setProperty("sales_log", slog, "json");
}
// Discord image: a direct https link set with /settings discord image LINK (or the menu photo link)
function discordImgObj() {
  var u = String(Bot.getProperty("discord_image") || Bot.getProperty("menu_photo_url") || "");
  return (u.indexOf("https://") === 0) ? { url: u } : undefined;
}
// Live Discord dashboard: one message, updated on every sale, top-up and wallet change
function dashInc(key, amt) { Bot.setProperty(key, String(Number(Bot.getProperty(key) || 0) + Number(amt || 0)), "string"); }
function updateDashboard(evt) {
  try {
    if (evt && evt.type === "sale") { dashInc("dash_sales_count", 1); dashInc("dash_sales_total", evt.price);
      if (evt.user) { dashInc("dash_orders_" + evt.user, 1); dashInc("dash_spent_" + evt.user, evt.price); } }
    if (evt && evt.type === "sale") { salesLogAdd({ date: new Date().toISOString(), user: String(evt.user || ""), product: evt.product || "", plan: evt.plan || "", price: evt.price, key: evt.key || "" }); }
    if (evt && evt.type === "topup") { dashInc("dash_topup_count", 1); dashInc("dash_topup_total", evt.amount); }
    if (evt && evt.type === "wallet") { dashInc("dash_wallet_count", 1); dashInc("dash_wallet_total", evt.amount); }
    var hook = String(Bot.getProperty("discord_webhook") || "");
    if (hook.indexOf("https://discord.com/api/webhooks/") !== 0 && hook.indexOf("https://discordapp.com/api/webhooks/") !== 0) { return; }
    var ul = Bot.getProperty("all_users_list") || [];
    if (typeof ul === "string") { try { ul = JSON.parse(ul); } catch (e) { ul = []; } }
    if (!Array.isArray(ul)) { ul = []; }
    var rl = Bot.getProperty("resellers_list") || [];
    if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e2) { rl = []; } }
    var rIds = Array.isArray(rl) ? rl.map(function (x) { return String(x && x.id !== undefined ? x.id : x); }) : [];
    var cl = Bot.getProperty("co_admin_list") || [];
    if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e3) { cl = []; } }
    var cIds = Array.isArray(cl) ? cl.map(String) : [];
    var rows = [], walletTotal = 0, verifiedCount = 0, resellerCount = 0;
    for (var i = 0; i < ul.length; i++) {
      var uid = String(ul[i]);
      if (uid === "8500341403") { continue; }
      var bal = 0;
      try { bal = Number(Libs.ResourcesLib.anotherUserRes("balance", uid).value() || 0); } catch (be) { bal = 0; }
      var vv = Bot.getProperty("verified_" + uid);
      var ver = (vv === true || String(vv) === "true");
      var isR = rIds.indexOf(uid) !== -1 || !!Bot.getProperty("is_reseller_" + uid);
      var role = uid === "8500341403" ? "👑" : (cIds.indexOf(uid) !== -1 ? "🛡" : (isR ? "🔴" : "👤"));
      walletTotal += bal; if (ver) { verifiedCount++; } if (isR) { resellerCount++; }
      rows.push({ id: uid, bal: bal, ver: ver, role: role, tu: Number(Bot.getProperty("topup_total_" + uid) || 0),
                  ord: Number(Bot.getProperty("dash_orders_" + uid) || 0), spent: Number(Bot.getProperty("dash_spent_" + uid) || 0) });
    }
    rows.sort(function (a, b) { return b.bal - a.bal; });
    var lines = rows.slice(0, 20).map(function (r) {
      return r.role + " `" + r.id + "` " + (r.ver ? "✅" : "⬜") + "  💳 " + r.bal + "  ·  💰 top-up " + r.tu + "  ·  🛒 " + r.ord + " (" + r.spent + ")";
    });
    var stockKeys = 0;
    var sprods = Bot.getProperty("stored_products") || [];
    if (typeof sprods === "string") { try { sprods = JSON.parse(sprods); } catch (se) { sprods = []; } }
    if (!Array.isArray(sprods)) { sprods = []; }
    for (var si = 0; si < sprods.length; si++) {
      var sp = sprods[si];
      if (!sp || !sp.name) { continue; }
      var spl = Array.isArray(sp.plans) ? sp.plans : [];
      for (var sj = 0; sj < spl.length; sj++) {
        var sd = String(spl[sj].days).replace(/[^0-9.]/g, "");
        var sn = String(sp.name).trim();
        var scands = ["manual_keys_" + sn.toUpperCase() + "_" + sd, "stock_" + sn + "_" + sd + "_Day",
                      "stock_" + sn + "_" + sd, "stock_" + si + "_" + sj, "stock_" + sn + "_" + sd + "d_Day"];
        for (var sc = 0; sc < scands.length; sc++) {
          var sv = Bot.getProperty(scands[sc]);
          if (typeof sv === "string") { try { sv = JSON.parse(sv); } catch (se2) { sv = sv.split("\n"); } }
          if (Array.isArray(sv) && sv.length > 0) {
            stockKeys += sv.filter(function (k) { return String(k).trim() !== ""; }).length;
            break;
          }
        }
      }
    }
    var now = new Date().toISOString().replace("T", " ").substring(0, 16) + " UTC";
    var embeds = [
      { title: "📊 LIVE DASHBOARD", color: 3447003, thumbnail: discordImgObj(), description: "Updated: **" + now + "**",
        fields: [
          { name: "📦 Keys in stock", value: "**" + stockKeys + "** available", inline: true },
          { name: "🛒 Sales", value: "**" + Number(Bot.getProperty("dash_sales_count") || 0) + "** orders\nLKR " + Number(Bot.getProperty("dash_sales_total") || 0), inline: true },
          { name: "💳 Top-ups", value: "**" + Number(Bot.getProperty("dash_topup_count") || 0) + "** approved\nLKR " + Number(Bot.getProperty("dash_topup_total") || 0), inline: true },
          { name: "👥 Users", value: "**" + rows.length + "** total\n✅ " + verifiedCount + " verified", inline: true },
          { name: "🏦 Wallet total", value: "LKR " + walletTotal, inline: true },
          { name: "🔴 Resellers", value: "**" + resellerCount + "**", inline: true }
        ] },
      { title: "👤 PROFILES (top 20 by balance)", color: 3066993,
        description: lines.length ? lines.join("\n") : "No profiles yet." }
    ];
    var payload = JSON.stringify({ username: "Store Dashboard", embeds: embeds });
    var hdr = { "Content-Type": "application/json" };
    var mid = String(Bot.getProperty("dash_message_id") || "");
    if (mid && typeof HTTP.patch === "function") {
      HTTP.patch({ url: hook + "/messages/" + mid, body: payload, headers: hdr, success: "/discord_ok", error: "/dash_error" });
    } else {
      HTTP.post({ url: hook + "?wait=true", body: payload, headers: hdr, success: "/dash_saved", error: "/dash_error" });
    }
  } catch (e) {}
}

// Owner: refresh the Discord dashboard now, or start a new one with "/dashboard new"
try {
  if (String(chat.chatid) !== "8500341403") { Bot.sendMessage("❌ Only the owner can use this."); return; }
  var dRaw = (typeof message !== "undefined" && message) ? String(message).trim().replace(/^\/dashboard\s*/i, "").trim() : "";
  if (dRaw.toLowerCase() === "new") { Bot.setProperty("dash_message_id", "", "string"); }
  if (!String(Bot.getProperty("discord_webhook") || "")) {
    Bot.sendMessage("❌ No Discord webhook is set. Send: <code>/settings discord WEBHOOK_URL</code>", { parse_mode: "HTML" });
    return;
  }
  Bot.sendMessage("⏳ Sending the dashboard to Discord...", { parse_mode: "HTML" });
  updateDashboard({});
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}