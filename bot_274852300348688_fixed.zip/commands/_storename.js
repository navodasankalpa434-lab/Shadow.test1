/**#command
name: /storename
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Change the shop name shown to customers. Owner and co-admins only.
// Usage: /storename NEW SHOP NAME
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var callerId = String(chat.chatid);
  if (!isCoAdminId(callerId)) {
    Bot.sendMessage("❌ Only the owner and co-admins can change the store name.");
    return;
  }

  var esc = function (x) { return String(x).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); };
  var current = String(Bot.getProperty("store_name") || "Shadow and Scrapy Panel Store");
  var raw = (typeof message !== "undefined" && message) ? String(message).trim() : "";
  var newName = raw.replace(/^\/storename\s*/i, "").trim();

  if (!newName) {
    Bot.sendMessage(
      "🏪 <b>Store name</b>\n\nCurrent: <code>" + current + "</code>\n\n" +
      "Change it with:\n<code>/storename Your New Store Name</code>",
      { parse_mode: "HTML" }
    );
    return;
  }
  if (newName.length < 1 || newName.length > 60) {
    Bot.sendMessage("❌ The store name must be between 1 and 60 characters.", { parse_mode: "HTML" });
    return;
  }

  Bot.setProperty("store_name", newName, "string");
  Bot.sendMessage(
    "✅ <b>Store name changed!</b>\n\nOld: <code>" + current + "</code>\nNew: <code>" + newName + "</code>\n\n" +
    "<i>New menus and receipts will show the new name.</i>",
    { parse_mode: "HTML" }
  );
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}