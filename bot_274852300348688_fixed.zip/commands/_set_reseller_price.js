/**#command
name: /set_reseller_price
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 👑 ADMIN/CO-ADMIN — Set Reseller Upgrade Price
// Usage: /set_reseller_price 500
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "8500341403";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = isCoAdminId(currentChatId);

  if (currentChatId !== ownerId && !isCoAdmin) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  if (!params || params.trim() === "") {
    var current = Bot.getProperty("reseller_upgrade_price") || "Not set";
    Bot.sendMessage("⚠️ <b>Format:</b> <code>/set_reseller_price 500</code>\n\n<b>Current price:</b> LKR " + current, { parse_mode: "HTML" });
    return;
  }

  var price = parseFloat(params.trim());
  if (isNaN(price) || price <= 0) {
    Bot.sendMessage("❌ A valid price (number) is required!");
    return;
  }

  Bot.setProperty("reseller_upgrade_price", price, "number");
  Bot.sendMessage("✅ <b>Reseller Upgrade Price set:</b> LKR " + price.toFixed(2), { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}