/**#command
name: /confirm_rem_stock
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  if (!params) return;
  
  // Split the params (to get the slug and stock index)
  var parts = params.split(" ");
  var slug = parts[0];
  var stockIndex = parseInt(parts[1]);

  var currentStock = Bot.getProperty("ff_stock_" + slug) || [];
  if (!Array.isArray(currentStock) || stockIndex >= currentStock.length) {
    Bot.sendMessage("❌ The account was already deleted or not found.");
    return;
  }

  // Store the target account's data for the report
  var deletedAccount = currentStock[stockIndex];

  // Delete that specific index from the array
  currentStock.splice(stockIndex, 1);

  // Save the updated array to the database
  Bot.setProperty("ff_stock_" + slug, currentStock, "json");

  // Success message with confirmation
  Bot.sendMessage("🗑 <b>Stock Deleted Successfully!</b>\n\n• <b>Category:</b> " + slug.toUpperCase() + "\n• <b>Removed Data:</b> <code>" + deletedAccount + "</code>", {parse_mode: "HTML"});

  // Run automatically to refresh the stock list so the updated list is shown
  Bot.run({
    command: "/view_rem_stock",
    options: { params: slug }
  });

} catch (e) {
  Bot.sendMessage("Error: " + e.message);
}