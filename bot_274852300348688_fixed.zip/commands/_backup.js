/**#command
name: /backup
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Owner backup: every setting, product, plan, stock key, discount, coupon, rank level,
// customer record (ID, phone, registration, balance, top-ups, rank, purchases, keys sold, spent) and sales log.
try {
  if (String(chat.chatid) !== "8500341403") { Bot.sendMessage("❌ Only the owner can make a backup."); return; }

  var users = Bot.getProperty("all_users_list") || [];
  if (typeof users === "string") { try { users = JSON.parse(users); } catch (e) { users = []; } }
  if (!Array.isArray(users)) { users = []; }

  var keys = ["stored_products", "resellers_list", "coupon_list", "co_admin_list", "menu_photo_url", "menu_photo_file_id",
              "store_name", "credit_text", "topup_bank_name", "topup_bank_acc", "topup_bank_holder", "topup_ezcash",
              "topup_tiers", "topup_counter", "maintenance_mode", "auto_discount_global", "reseller_upgrade_price",
              "discord_webhook", "discord_image", "sales_log", "dash_sales_count", "dash_sales_total", "dash_topup_count",
              "dash_topup_total", "dash_wallet_count", "dash_wallet_total", "update_link"];
  var data = { version: "SHADOW-BACKUP-3", settings: {}, stock: {}, discounts: {}, coupons: {}, users: [], pending: {} };
  for (var k = 0; k < keys.length; k++) {
    var kv = Bot.getProperty(keys[k]);
    if (kv !== null && kv !== undefined && kv !== "") { data.settings[keys[k]] = kv; }
  }

  // Products, plans, stock keys and discounts
  var bprods = Bot.getProperty("stored_products") || [];
  if (typeof bprods === "string") { try { bprods = JSON.parse(bprods); } catch (e) { bprods = []; } }
  if (!Array.isArray(bprods)) { bprods = []; }
  for (var bi = 0; bi < bprods.length; bi++) {
    var bp = bprods[bi];
    if (!bp || !bp.name) { continue; }
    var bn = String(bp.name).trim();
    var bupper = bn.toUpperCase();
    var dk = "auto_discount_" + bupper + "_ALL";
    if (Bot.getProperty(dk)) { data.discounts[dk] = Bot.getProperty(dk); }
    var bplans = Array.isArray(bp.plans) ? bp.plans : [];
    for (var bj = 0; bj < bplans.length; bj++) {
      var bd = String(bplans[bj].days).replace(/[^0-9.]/g, "");
      var pdk = "auto_discount_" + bupper + "_" + bd + "_" + String(bplans[bj].unit || "day").toUpperCase();
      if (Bot.getProperty(pdk)) { data.discounts[pdk] = Bot.getProperty(pdk); }
      var bcands = ["manual_keys_" + bupper + "_" + bd, "stock_" + bn + "_" + bd + "_Day",
                    "stock_" + bn + "_" + bd, "stock_" + bi + "_" + bj, "stock_" + bn + "_" + bd + "d_Day"];
      for (var bk = 0; bk < bcands.length; bk++) {
        var bv = Bot.getProperty(bcands[bk]);
        if (bv !== null && bv !== undefined && bv !== "" && !(Array.isArray(bv) && bv.length === 0)) { data.stock[bcands[bk]] = bv; }
      }
    }
  }

  // Coupons
  var bcoup = Bot.getProperty("coupon_list") || [];
  if (typeof bcoup === "string") { try { bcoup = JSON.parse(bcoup); } catch (e) { bcoup = []; } }
  if (!Array.isArray(bcoup)) { bcoup = []; }
  for (var ci = 0; ci < bcoup.length; ci++) {
    var code = String(bcoup[ci] && bcoup[ci].code !== undefined ? bcoup[ci].code : bcoup[ci]);
    var cv = Bot.getProperty("coupon_" + code);
    if (cv) { data.coupons["coupon_" + code] = cv; }
  }

  // Customers: everything we know about each one
  for (var u = 0; u < users.length; u++) {
    var uid = String(users[u]);
    var bal = 0;
    try { bal = Libs.ResourcesLib.anotherUserRes("balance", uid).value() || 0; } catch (be) { bal = 0; }
    var hist = Bot.getProperty("history_" + uid) || [];
    data.users.push({ id: uid, balance: bal,
      verified: Bot.getProperty("verified_" + uid) || false,
      phone: Bot.getProperty("phone_" + uid) || "",
      joined: Bot.getProperty("joined_date_" + uid) || "",
      topup_total: Bot.getProperty("topup_total_" + uid) || 0,
      reseller: Bot.getProperty("is_reseller_" + uid) || false,
      co_admin: Bot.getProperty("co_admin_" + uid) || false,
      orders: Bot.getProperty("dash_orders_" + uid) || 0,
      keys_sold: Bot.getProperty("keys_sold_" + uid) || 0,
      spent: Bot.getProperty("dash_spent_" + uid) || 0,
      history: hist });
  }

  // Pending top-up requests
  var tCount = Number(Bot.getProperty("topup_counter") || 0);
  for (var t = 1; t <= tCount; t++) {
    var tv = Bot.getProperty("topup_req_" + t);
    if (tv) { data.pending["topup_req_" + t] = tv; }
  }

  var text = JSON.stringify(data);
  var esc = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  var chunks = [];
  for (var p = 0; p < esc.length; p += 3000) { chunks.push(esc.substring(p, p + 3000)); }
  var total = chunks.length;
  Bot.sendMessage("💾 <b>BACKUP</b>\nCustomers: " + users.length + "\nParts: " + total +
                  "\n\nSend each part to the bot, in order. Copy the whole part, including /restore, and send it as one message.", { parse_mode: "HTML" });
  for (var q = 0; q < total; q++) {
    Api.sendMessage({ chat_id: "8500341403", parse_mode: "HTML",
      text: "<pre>/restore " + (q + 1) + "/" + total + " " + chunks[q] + "</pre>" });
  }
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}