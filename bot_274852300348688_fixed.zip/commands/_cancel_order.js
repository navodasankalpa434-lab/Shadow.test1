/**#command
name: /cancel_order
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var userId = user.telegramid;

  Api.deleteMessage({
    chat_id: chat.chatid,
    message_id: request.message.message_id
  });

  User.setProperty("pending_order_id", null);
  User.setProperty("pending_pay_amount", null);

  // ✅ Disable the expiry watcher so a wrong message is not edited later
  Bot.setProperty("qr_order_id_" + userId, null, "string");
  User.setProperty("qr_order_id_" + userId, null, "string");
  Bot.setProperty("qr_watch_order_" + userId, null, "string");
  User.setProperty("qr_watch_order_" + userId, null, "string");
  Bot.setProperty("verifying_lock_" + userId, false, "boolean");
  User.setProperty("verifying_lock_" + userId, false, "boolean");

  var cancelMsg = "✖ <tg-emoji emoji-id='6082547652556233400'>❌</tg-emoji> <b>ORDER CANCELLED</b>\n" +
                  "━━━━━━━━━━━━━━━━━━━━━━\n" +
                  "<i>Your payment request has been cancelled successfully.</i>";

  Api.sendMessage({
    chat_id: chat.chatid,
    text: cancelMsg,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: [[
        { text: "Back to Menu", callback_data: "/back", style: "primary", icon_custom_emoji_id: "6057415823222379852" }
      ]]
    })
  });

  Api.answerCallbackQuery({
    callback_query_id: request.id,
    text: "Order Cancelled",
    show_alert: false
  });

} catch (err) {
  Bot.sendMessage("✖ <b>Order Cancelled.</b>", { parse_mode: "HTML" });
}