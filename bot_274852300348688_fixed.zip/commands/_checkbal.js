/**#command
name: /checkbal
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403"; // Your Admin ID
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  // Expected Usage: /checkbalance USER_ID
  var targetId = params ? params.trim() : null;

  // ✅ FIXED: same button-click bug as /addbal — the prompt now appears.
  if (!targetId || isNaN(targetId)) {
    User.setProperty("checkbal_step", "waiting_input", "string");
    Bot.sendMessage(
      "<tg-emoji emoji-id='6039605143601680423'>📊</tg-emoji> <b>Check Balance</b>\n\n" +
      "<i>Reply with the User ID of the user whose balance you want to check:</i>\n<code>8500341403</code>",
      { parse_mode: "HTML" }
    );
    return;
  }

  // 👤 NAME & USERNAME DEFAULT FALLBACKS
  var name = "N/A";
  var username = "N/A";

  // User metadata will load directly only if the admin is checking their own ID
  if (String(targetId) === String(user.telegramid)) {
    name = user.first_name || "N/A";
    username = user.username ? "@" + user.username : "N/A";
  }

  // 💰 WALLET BALANCE REGISTERS FETCH
  var userResBalance = Libs.ResourcesLib.anotherUserRes("balance", targetId).value() || 0;
  var adminCustomBal = Bot.getProperty("balance" + targetId) || 0;
  var totalUserBal = (Number(userResBalance) + Number(adminCustomBal)).toFixed(2);

  // 📉 TOTAL EXPENSE NODE TRACKING (Total Invest mapping)
  var totalSpent = Bot.getProperty("total_spent_by_" + targetId) || 0;
  var formattedSpent = Number(totalSpent).toFixed(2);

  // 📄 FINAL RESPONSE BOX
  var messageText = "<blockquote><b><tg-emoji emoji-id='6039605143601680423'>📞</tg-emoji> USER ACCOUNT DETAILS</b>\n\n" +
                    "• <b>Name:</b> " + name + "\n" +
                    "• <b>Username:</b> " + username + "\n" +
                    "• <b>User ID:</b> <code>" + targetId + "</code>\n" +
                    "• <b>Balance:</b> <code>LKR " + totalUserBal + "</code>\n" +
                    "• <b>Total Invest:</b> <code>LKR " + formattedSpent + "</code></blockquote>";

  Bot.sendMessage(messageText, { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}