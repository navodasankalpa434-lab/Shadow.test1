/**#command
name: /onContactRecieved
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Role: Admin, Reseller, Customer (unverified shows as Visitor)
function roleFor(id) {
  id = String(id);
  if (id === "8500341403") { return "🛡 Admin"; }
  var cl = Bot.getProperty("co_admin_list") || [];
  if (typeof cl === "string") { try { cl = JSON.parse(cl); } catch (e) { cl = []; } }
  var isAdmin = String(Bot.getProperty("co_admin_" + id)) === "true" || (Array.isArray(cl) && cl.map(String).indexOf(id) !== -1);
  if (isAdmin) { return "🛡 Admin"; }
  var rl = Bot.getProperty("resellers_list") || [];
  if (typeof rl === "string") { try { rl = JSON.parse(rl); } catch (e2) { rl = []; } }
  var isRes = String(Bot.getProperty("is_reseller_" + id)) === "true" ||
              (Array.isArray(rl) && rl.some(function (x) { return String(x && x.id !== undefined ? x.id : x) === id; }));
  if (isRes) { return "🔴 Reseller"; }
  var vv = Bot.getProperty("verified_" + id);
  if (!(vv === true || String(vv) === "true")) { return "👀 Visitor"; }
  return "✅ Customer";
}
// Rank: the best top-up tier the customer has reached
function rankFor(id) {
  var total = Number(Bot.getProperty("topup_total_" + id) || 0);
  var tiers = Bot.getProperty("topup_tiers") || [];
  if (typeof tiers === "string") { try { tiers = JSON.parse(tiers); } catch (e) { tiers = []; } }
  if (!Array.isArray(tiers)) { tiers = []; }
  var best = null;
  for (var t = 0; t < tiers.length; t++) {
    if (total >= Number(tiers[t].min) && (!best || Number(tiers[t].pct) > Number(best.pct))) { best = tiers[t]; }
  }
  return best ? (best.name + " · " + best.pct + "% off") : "None · 0% off";
}
// Menu header: role, verification and rank
function statusBlockFor() {
  var sid = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
  var vv = Bot.getProperty("verified_" + sid);
  var ver = (vv === true || String(vv) === "true") ? "✅ Verified account" : "🔴 Not verified (tap Verify Account)";
  return "<blockquote><b>" + roleFor(sid) + "</b>\n" + ver + "\n🏅 Rank: " + rankFor(sid) + "</blockquote>\n";
}
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// Status line shown at the top of the menu: role + verified / not verified
var SHOP_NAME = String(Bot.getProperty("store_name") || "Shadow and Scrapy Panel Store").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");

try {
  var userId = user.telegramid;
  var contactData = request && request.message ? request.message.contact : null;

  if (!contactData) {
    Bot.sendMessage("⚠️ Contact data not found, please try again.");
    return;
  }

  if (String(contactData.user_id) !== String(userId)) {
    Api.sendMessage({
      chat_id: chat.chatid,
      text: "⚠️ <b>Please share your own contact</b> to verify.",
      parse_mode: "HTML",
      reply_markup: JSON.stringify({
        keyboard: [[{ text: "✅ Verify Account", request_contact: true }]],
        resize_keyboard: true,
        one_time_keyboard: true
      })
    });
    return;
  }

  Bot.setProperty("verified_" + userId, true, "boolean");
  User.setProperty("verified_" + userId, true, "boolean");
  // ✅ NEW: Save the joined date (to show in the Profile section)
  if (!Bot.getProperty("joined_date_" + userId)) {
    Bot.setProperty("joined_date_" + userId, new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }), "string");
  }

  var phone = contactData.phone_number || "N/A";

  Api.sendMessage({
    chat_id: chat.chatid,
    text: "<blockquote><tg-emoji emoji-id='5330237710655306682'>✅</tg-emoji> <b>Account Verified Successfully!</b>\n<tg-emoji emoji-id='6266994443262367483'>😊</tg-emoji> <i>Welcome! Loading your menu...</i></blockquote>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ remove_keyboard: true })
  });

  var adminId = "8500341403";
  var uName = (user && user.first_name) ? user.first_name : "Unknown";
  var uUsername = (user && user.username) ? "@" + user.username : "No Username";

  var adminAlert = "<blockquote>" +
    "<tg-emoji emoji-id='6113743082358841933'>🔰</tg-emoji> <b>NEW USER VERIFIED</b>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "👤 <b>Name:</b> " + uName + " (" + uUsername + ")\n" +
    "🆔 <b>User ID:</b> <code>" + userId + "</code>\n" +
    "📞 <b>Phone:</b> <code>" + phone + "</code>\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
    "✅ <i>Status: Verified via Contact Share</i>" +
    "</blockquote>";

  Api.sendMessage({ chat_id: adminId, text: adminAlert, parse_mode: "HTML" });

  // 🔗 PENDING DEEP LINK -> LOADING THEN SHOW PRODUCT PLANS (via HTTP delay)
  var pendingSlug = Bot.getProperty("pending_deeplink_" + userId) || User.getProperty("pending_deeplink_" + userId) || "";

  if (pendingSlug !== "") {
    var productList = Bot.getProperty("stored_products") || [];
    var matchedIdx = -1;

    for (var p = 0; p < productList.length; p++) {
      var slug = String(productList[p].name || "").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
      if (slug === pendingSlug.toLowerCase()) {
        matchedIdx = p;
        break;
      }
    }

    Bot.setProperty("pending_deeplink_" + userId, null, "string");
    User.setProperty("pending_deeplink_" + userId, null, "string");

    if (matchedIdx > -1) {
      // ⏳ STEP 1: LOADING MESSAGE
      var loadingText = "<blockquote>" +
        "<tg-emoji emoji-id='6147936236125298267'>⏳</tg-emoji> <b>Loading your product</b><tg-emoji emoji-id='6193006377389005214'>...</tg-emoji>\n" +
        "<i>Please wait a moment</i>" +
        "</blockquote>";

      var loadingMsg = Api.sendMessage({
        chat_id: chat.chatid,
        text: loadingText,
        parse_mode: "HTML"
      });

      var loadingMsgId = (loadingMsg && loadingMsg.result && loadingMsg.result.message_id) ? loadingMsg.result.message_id : null;

      // 💾 STEP 2: Save state for the delayed callback
      User.setProperty("dl_wait_msgid", loadingMsgId, "number");
      User.setProperty("dl_wait_prodidx", matchedIdx, "number");
      User.setProperty("dl_wait_chatid", String(chat.chatid), "string");

      // ⏳ STEP 3: 4-SECOND DELAY VIA HTTP CALLBACK (instead of setTimeout)
      HTTP.get({
        url: "https://httpbin.org/delay/4",
        success: "/onDeepLinkPlanShow",
        error: "/onDeepLinkPlanShow"
      });

      return;
    }
  }

  // ✅ No pending deep-link -> DIRECT MAIN MENU
  var userBal2 = "0.00";
  try {
    var res2 = 0;
    if (Libs && Libs.ResourcesLib) { res2 = Libs.ResourcesLib.userRes("balance").value() || 0; }
    var adminBal2 = Bot.getProperty("balance" + userId) || 0;
    userBal2 = (Number(res2) + Number(adminBal2)).toFixed(2);
  } catch (balErr2) {
    var fallbackBal2 = Bot.getProperty("balance" + userId) || 0;
    userBal2 = Number(fallbackBal2).toFixed(2);
  }

  var welcomeMessage2 =
    "<tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <b>— " + SHOP_NAME + " —</b> <tg-emoji emoji-id=\"5866053971960929280\">🏪</tg-emoji> <tg-emoji emoji-id=\"6266967801580231067\">💎</tg-emoji>\n\n" +
    "<tg-emoji emoji-id=\"6093677128295914531\">🎉</tg-emoji> <b>Hello, " + ((user && user.first_name) ? user.first_name.toUpperCase() : "RESELLER") + "!</b>\n\n" +
    "<tg-emoji emoji-id=\"6080228009439141516\">💧</tg-emoji> <b>Genuine, limited-stock Free Fire panels. Instant delivery.</b>\n\n" +
    "<tg-emoji emoji-id=\"6093591495237967001\">🌐</tg-emoji> Wide product catalog\n" +
    "<tg-emoji emoji-id=\"6215386799133433653\">🔑</tg-emoji> Instant delivery on payment\n" +
    "<tg-emoji emoji-id=\"6312263493051489212\">💰</tg-emoji> Multiple payment gateways\n" +
    "<tg-emoji emoji-id=\"6100170496077204999\">👑</tg-emoji> 24/7 admin support\n\n" +
    "<i>Balance: LKR " + userBal2 + "</i>\n\n" +
    "<i>Tap any button below to begin:</i> <tg-emoji emoji-id='6057415823222379852'>👇</tg-emoji>";

  var multiColorKeyboard2 = [
    [{ text: "Shop Now", callback_data: "/buy_hack", style: "primary", icon_custom_emoji_id: "5866053971960929280" }],
    [
      { text: "Profile", callback_data: "/profile", style: "primary", icon_custom_emoji_id: "5260399854500191689" },
      { text: "Add Top Up", callback_data: "/addfund", style: "success", icon_custom_emoji_id: "6147815702163102310" }
    ],
    [
      { text: "My Keys", callback_data: "/mykey", style: "primary", icon_custom_emoji_id: "6113743082358841933" },
      { text: "How to use", callback_data: "/how", style: "danger", icon_custom_emoji_id: "6080214566191505147" }
    ],
    [{ text: "Payment Proofs", url: "https://chat.whatsapp.com/JR898GeUCjiKPXF25jDW2D?s=cl&p=a&mlu=4&ilr=4", style: "success", icon_custom_emoji_id: "5330237710655306682" }],
    [{ text: "Support", callback_data: "/support", style: "danger", icon_custom_emoji_id: "5436113877181941026" }]
  ];

  // Shop banner photo: set this to a DIRECT image link (ends in .jpg or .png), not a Google Photos page link
  var MENU_PHOTO_URL = String(Bot.getProperty("menu_photo_file_id") || Bot.getProperty("menu_photo_url") || "");
  if (MENU_PHOTO_URL.indexOf("http") === 0 || /^[A-Za-z0-9_\-]{20,}$/.test(MENU_PHOTO_URL)) {
    try { Api.sendPhoto({ chat_id: chat.chatid, photo: MENU_PHOTO_URL }); } catch (photoErr) {}
  }
  Api.sendMessage({
    chat_id: chat.chatid,
    text: statusBlockFor() + welcomeMessage2,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: multiColorKeyboard2 })
  });

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}