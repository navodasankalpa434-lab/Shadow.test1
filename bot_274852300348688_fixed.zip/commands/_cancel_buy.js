/**#command
name: /cancel_buy
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var userId = user.telegramid;
  var callbackId = request ? request.id : (request.callback_query && request.callback_query.id);

  var qrMsgId = Bot.getProperty("buy_qr_msg_id_" + userId) || User.getProperty("buy_qr_msg_id_" + userId);

  if (qrMsgId) {
    try { Api.deleteMessage({ chat_id: chat.chatid, message_id: qrMsgId }); } catch (e) {}
  }

  User.setProperty("buy_pending_order_id", null);
  User.setProperty("buy_prod_idx", null);
  User.setProperty("buy_plan_idx", null);
  User.setProperty("buy_price", null);
  User.setProperty("buy_needpay", null);
  User.setProperty("buy_prod_name", null);
  User.setProperty("buy_plan_days", null);
  Bot.setProperty("buy_qr_msg_id_" + userId, null, "string");
  User.setProperty("buy_qr_msg_id_" + userId, null, "string");

  var cancelText = "<blockquote>" +
    "<tg-emoji emoji-id='6219547832169273793'>❌</tg-emoji> <b>ORDER CANCELLED</b>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    "<tg-emoji emoji-id='6266994443262367483'>😊</tg-emoji> <i>No problem, you can buy from the shop again whenever you like.</i>" +
    "</blockquote>";

  Api.sendMessage({
    chat_id: chat.chatid,
    text: cancelText,
    parse_mode: "HTML",
    reply_markup: JSON.stringify({
      inline_keyboard: [[
        { text: "Shop Menu", callback_data: "/buy_hack", style: "primary", icon_custom_emoji_id: "6057415823222379852" }
      ]]
    })
  });

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: String(callbackId) });
  }

} catch (err) {
  Bot.sendMessage("⚠️ System Error: " + err.message);
}