/**#command
name: /manage_coadmin
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// =========================================================
// 👑 OWNER-ONLY — Manage Co-Admins
// Usage: /manage_coadmin add USERID | /manage_coadmin remove USERID | /manage_coadmin list
// Co-Admins get full /admin panel access (product/plan/key/price/coupon/broadcast controls)
// but CANNOT manage other co-admins or transfer ownership — that stays Owner-only.
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "8500341403";
  var currentChatId = String(chat.chatid);

  if (currentChatId !== ownerId) {
    Bot.sendMessage("❌ Only the Owner can manage co-admins!");
    return;
  }

  if (!params || params.trim() === "") {
    var coAdminList = Bot.getProperty("co_admin_list") || [];
    Bot.sendMessage(
      "⚠️ <b>Format:</b>\n" +
      "<code>/manage_coadmin add USERID</code>\n" +
      "<code>/manage_coadmin remove USERID</code>\n" +
      "<code>/manage_coadmin list</code>\n\n" +
      "<b>Current Co-Admins:</b> " + (coAdminList.length ? coAdminList.join(", ") : "None"),
      { parse_mode: "HTML" }
    );
    return;
  }

  var parts = params.trim().split(" ");
  var action = parts[0].toLowerCase();
  var targetId = parts[1] ? parts[1].trim() : null;

  var coAdminList = Bot.getProperty("co_admin_list") || [];

  if (action === "list") {
    Bot.sendMessage(
      "<blockquote>👑 <b>CO-ADMIN LIST</b></blockquote>\n\n" + (coAdminList.length ? coAdminList.map(function (id) { return "• <code>" + id + "</code>"; }).join("\n") : "<i>There are no co-admins.</i>"),
      { parse_mode: "HTML" }
    );
    return;
  }

  if (!targetId || isNaN(Number(targetId))) {
    Bot.sendMessage("❌ A valid User ID is required! Example: <code>/manage_coadmin add 123456789</code>", { parse_mode: "HTML" });
    return;
  }

  if (action === "add") {
    if (targetId === ownerId) {
      Bot.sendMessage("❌ The Owner cannot make themselves a co-admin!");
      return;
    }
    Bot.setProperty("co_admin_" + targetId, true, "boolean");
    Bot.setProperty("verified_" + targetId, true, "boolean");
    if (coAdminList.indexOf(targetId) === -1) {
      coAdminList.push(targetId);
      Bot.setProperty("co_admin_list", coAdminList, "json");
    }
    Bot.sendMessage("✅ <b>Co-Admin Added!</b> User <code>" + targetId + "</code> can now access the full admin panel.", { parse_mode: "HTML" });
    try {
      Api.sendMessage({
        chat_id: targetId,
        text: "<blockquote>👑 <b>YOU ARE NOW A CO-ADMIN!</b></blockquote>\n\n<i>You have been given full access to this store's admin panel. Use the /admin command to access it.</i>",
        parse_mode: "HTML"
      });
    } catch (e) {}
  } else if (action === "remove") {
    if (["8865419308"].indexOf(targetId) !== -1) {
      Bot.sendMessage("❌ This is a permanent co-admin and cannot be removed.");
      return;
    }
    Bot.setProperty("co_admin_" + targetId, false, "boolean");
    var idx = coAdminList.indexOf(targetId);
    if (idx > -1) { coAdminList.splice(idx, 1); Bot.setProperty("co_admin_list", coAdminList, "json"); }
    Bot.sendMessage("✅ <b>Co-Admin Removed!</b> User <code>" + targetId + "</code>'s admin access has been removed.", { parse_mode: "HTML" });
  } else {
    Bot.sendMessage("❌ Action must be 'add', 'remove', or 'list'.");
  }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}