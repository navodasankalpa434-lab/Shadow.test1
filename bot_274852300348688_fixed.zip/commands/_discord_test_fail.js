/**#command
name: /discord_test_fail
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  Api.sendMessage({ chat_id: "8500341403", parse_mode: "HTML", text: "❌ Discord rejected the test alert. Check the webhook URL with /settings discord URL." });
} catch (e) {}
return;