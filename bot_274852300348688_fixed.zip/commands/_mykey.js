/**#command
name: /mykey
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 🔑 MY KEYS — shows all purchased keys
// ✅ BUG FIXES:
// 1. First, if it was a photo message (coming from Profile), it tried editMessageText
//    which fails on Telegram — that is why clicking "My Keys"
//    showed nothing at all.
// 2. the catch(err) block was SILENTLY hiding errors — no feedback
//    was given when something failed.
// 3. Raw HTTP.post was used without success/error handling — now
//    consistent Api.* wrapper functions are used (like the rest of the bot).
// =========================================================

try {
    let userKeys = User.getProperty("my_purchased_keys");
    let chatId = chat.chatid;

    let text = "";
    let keyboard = { inline_keyboard: [] };

    if (!userKeys || userKeys.length === 0) {
        text = "<blockquote>" +
            "<tg-emoji emoji-id='6192822213486321961'>🗣</tg-emoji> <b>No keys found!</b>\n" +
            "<tg-emoji emoji-id='5866053971960929280'>💎</tg-emoji> You haven't purchased anything yet." +
            "</blockquote>";

        keyboard.inline_keyboard = [
            [
                { text: "Shop Now", callback_data: "/buy_hack", style: "success", icon_custom_emoji_id: "5866053971960929280" },
                { text: "Back", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
            ]
        ];
    } else {
        text = "<b>📋 Your Active Keys:</b>\n\n";

        for (let i = 0; i < userKeys.length; i++) {
            let keyData = userKeys[i];
            let pName = keyData.productName || keyData.product || "N/A";
            let pPrice = keyData.cost || keyData.price || "0";
            let pKey = keyData.key || "No Key Found";
            let pDays = keyData.days || "N/A";
            let pDate = keyData.date || "N/A";

            text += "<blockquote>" +
                "<tg-emoji emoji-id='6192822213486321961'>🗣</tg-emoji> <b>Product Name:</b> " + pName + "\n" +
                "<tg-emoji emoji-id='6266967801580231067'>⏳</tg-emoji> <b>Days:</b> " + pDays + "\n" +
                "<tg-emoji emoji-id='6176966310920983412'>➡️</tg-emoji> <b>Key:</b> <code>" + pKey + "</code>\n" +
                "<tg-emoji emoji-id='6267068789146260253'>🛒</tg-emoji> <b>Price:</b> LKR " + pPrice + "\n" +
                "<tg-emoji emoji-id='5866053971960929280'>📅</tg-emoji> <b>Date:</b> " + pDate +
                "</blockquote>\n";
        }

        // Safety trim against Telegram caption/message length limits (very large history)
        if (text.length > 3800) {
            text = text.substring(0, 3800) + "\n\n<i>... (list truncated — download full receipt from History)</i>";
        }

        keyboard.inline_keyboard = [
            [
                { text: "🧾 Download Receipt", callback_data: "/history_receipt", style: "primary", icon_custom_emoji_id: "6100170496077204999" }
            ],
            [
                { text: "Back To Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
            ]
        ];
    }

    // ✅ FIX: if it is a photo message, delete and send fresh, otherwise edit; the Api.* wrapper is used
    if (request && request.message && request.message.message_id) {
        if (request.message.photo) {
            try { Api.deleteMessage({ chat_id: chatId, message_id: request.message.message_id }); } catch (delErr) {}
            Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify(keyboard) });
        } else {
            Api.editMessageText({
                chat_id: chatId,
                message_id: request.message.message_id,
                text: text,
                parse_mode: "HTML",
                reply_markup: JSON.stringify(keyboard)
            });
        }
    } else {
        Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify(keyboard) });
    }

    var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
    if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
    // ✅ FIX: errors are no longer hidden silently — the user sees them
    try { Bot.sendMessage("⚠️ My Keys Error: " + err.message, { parse_mode: "HTML" }); } catch (e) {}
}