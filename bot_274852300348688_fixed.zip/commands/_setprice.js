/**#command
name: /setprice
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
    // 1. Admin ID validation check
    if (String(user.telegramid) !== "8500341403" && !isCoAdminId(String(user.telegramid))) {
        Bot.sendMessage("❌ You are not authorized to use this command.");
        return;
    }

    // 2. Check whether the parameters are empty
    if (!params || params.trim() === "") {
        Bot.sendMessage("⚠️ *Wrong format!*\nUse it like this: `setprice 450` or `/setprice 450`", { parse_mode: "Markdown" });
        return;
    }

    // 3. Convert the string to a number and check it
    let newPrice = parseInt(params.trim(), 10);

    if (isNaN(newPrice) || newPrice <= 0) {
        Bot.sendMessage("⚠️ *Enter a valid price!* It must be a number.", { parse_mode: "Markdown" });
        return;
    }

    // 4. Save to the global property
    Bot.setProperty("reseller_price", newPrice, "integer");
    
    // Success feedback message
    Bot.sendMessage("<tg-emoji emoji-id='6102856637343600044'>👑</tg-emoji> <b>[Admin Panel]</b>\n\n✅ Reseller Price successfully updated to: <b>LKR " + newPrice + "</b>", { parse_mode: "HTML" });

} catch (err) {
    Bot.sendMessage("⚠️ Error: " + err.message);
}