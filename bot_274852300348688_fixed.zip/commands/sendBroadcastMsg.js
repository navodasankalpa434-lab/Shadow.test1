/**#command
name: sendBroadcastMsg
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

try {
  // Access the request data sent by the admin
  var mediaRequest = options.msg;

  // This will copy each message (Text/Media) and send it to every user
  Bot.sendMessage(mediaRequest); 
  
} catch (err) {
  // 
}