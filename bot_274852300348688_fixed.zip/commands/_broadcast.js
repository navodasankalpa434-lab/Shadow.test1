/**#command
name: /broadcast
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = Bot.getProperty("owner_id") || "8500341403";
  var isCoAdmin0 = isCoAdminId(String(chat.chatid));
  if (String(chat.chatid) !== adminId && !isCoAdmin0) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  // Activate the admin state
  User.setProperty("awaiting_broadcast_data", true, "boolean");
  Bot.sendMessage("📢 <b>BROADCAST SYSTEM ACTIVATED</b>\n\nEvery message you send now (Text, Photo, Video, Voice, Animation) will be sent to all users.\n\n<i>Please send your message now...</i>", { parse_mode: "HTML" });

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}