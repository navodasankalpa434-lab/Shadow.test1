/**#command
name: /normalprice_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (!chat || String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  // 🔥 CLEAR SPINNER IMMEDIATELY
  if (typeof request !== "undefined" && request) {
    let queryId = request.id || (request.callback_query && request.callback_query.id);
    if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: queryId }); } catch(qErr){} }
  }

  // Pure parameter context safe extraction
  var rawInput = (typeof message !== "undefined" && message) ? message.trim() : "";
  if (!rawInput && typeof params !== "undefined" && params) { rawInput = String(params).trim(); }

  // Command structural cleanup
  if (rawInput.indexOf("/normalprice_id") === 0) {
    rawInput = rawInput.replace("/normalprice_id", "").trim();
  }

  // 🛡️ NO REPLY CRASH FIX: Display input instruction explicitly if text is completely blank
  if (!rawInput) {
    Api.sendMessage({
      chat_id: adminId,
      text: "✍️ <b>Set Normal Price Node Matrix:</b>\n\nPlease copy this text, edit it, and send it back in a reply:\n\n<code>/normalprice_id [Category Name] [Price]</code>\n\n<b>Example:</b>\n<code>/normalprice_id Facebook Id 150</code>",
      parse_mode: "HTML"
    });
    return;
  }

  var parts = rawInput.split(" ");
  if (parts.length < 2) {
    Api.sendMessage({
      chat_id: adminId,
      text: "⚠️ <b>Wrong Format!</b>\nCorrect way: <code>Category_Name Price</code>\nExample: <code>Facebook Id 150</code>",
      parse_mode: "HTML"
    });
    return;
  }

  var price = parts[parts.length - 1].trim();
  var catName = parts.slice(0, -1).join(" ").trim();

  if (isNaN(price)) {
    Api.sendMessage({ chat_id: adminId, text: "⚠️ <b>The price must be a valid number!</b>" });
    return;
  }

  var catSlug = catName.toLowerCase().replace(/[^a-z0-9]/g, "");
  var categories = Bot.getProperty("ff_categories") || {};

  if (!categories[catSlug]) {
    Api.sendMessage({ chat_id: adminId, text: "❌ <b>Category [ " + catName + " ] was not found in the system records!</b>" });
    return;
  }

  categories[catSlug].normal_price = parseFloat(price);
  Bot.setProperty("ff_categories", categories, "json");

  Api.sendMessage({
    chat_id: adminId,
    text: "✅ <b>Normal Price Updated Successfully!</b>\n\n• <b>Category:</b> <code>" + categories[catSlug].name + "</code>\n• <b>New Normal Price:</b> <code>LKR " + price + "</code>",
    parse_mode: "HTML"
  });

} catch(e) {
  Bot.sendMessage("Error in Set Normal Price: " + e.message);
}