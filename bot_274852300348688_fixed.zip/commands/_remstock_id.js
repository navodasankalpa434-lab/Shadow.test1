/**#command
name: /remstock_id
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  var categories = Bot.getProperty("ff_categories") || {};
  var keyboard = [];
  var row = [];
  var count = 0;

  for (var slug in categories) {
    var catName = categories[slug].name || slug.toUpperCase();
    
    // To show 2 buttons in each row
    row.push({ 
      text: "📁 " + catName, 
      callback_data: "/view_rem_stock " + slug 
    });
    
    count++;
    if (count % 2 === 0) {
      keyboard.push(row);
      row = [];
    }
  }
  if (row.length > 0) keyboard.push(row);

  if (keyboard.length === 0) {
    Bot.sendMessage("❌ No category has been created in the system yet.");
    return;
  }

  Api.sendMessage({
    chat_id: adminId,
    text: "📂 <b>Select a Category to view stock for deletion:</b>",
    parse_mode: "HTML",
    reply_markup: JSON.stringify({ inline_keyboard: keyboard })
  });

} catch (e) {
  Bot.sendMessage("Error: " + e.message);
}