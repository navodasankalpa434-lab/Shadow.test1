/**#command
name: /onWebKeyError
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

var dataOptions = options;
var chatId = (dataOptions && dataOptions.chat_id) ? dataOptions.chat_id : ((typeof chat !== "undefined" && chat && chat.chatid) ? chat.chatid : Bot.getProperty("last_order_chat"));
var adminId = "8500341403";

var systemErrorText = "<blockquote>" +
  "❌ <b>ORDER FAILED</b>\n" +
  "━━━━━━━━━━━━━━━━━━━━━\n\n" +
  "⚠️ <b>Something went wrong. Please retry soon.</b>\n\n" +
  "⏳ <i>Wait some time, admin will stock refill soon.</i>\n" +
  "💰 <b>Status:</b> Your funds were not deducted.\n\n" +
  "━━━━━━━━━━━━━━━━━━━━━\n" +
  "🗣 <i>Feel free to check back in a few minutes!</i>" +
  "</blockquote>";

var errorInlineButtons = [[
  { text: "Back to Menu", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }
]];

// ✅ FIX: used sendMessage (editMessageText fails on a photo message)
if (chatId) Api.sendMessage({
  chat_id: String(chatId),
  text: systemErrorText,
  parse_mode: "HTML",
  reply_markup: JSON.stringify({ inline_keyboard: errorInlineButtons })
});

var info = {};
try { info = JSON.parse(Bot.getProperty("last_order_info") || "{}"); } catch (ie) { info = {}; }
var d = {};
for (var ik in info) { d[ik] = info[ik]; }
for (var dk in (dataOptions || {})) { if (dataOptions[dk] !== undefined) d[dk] = dataOptions[dk]; }

if (true) {
  var adminAlertText = "⚠️ <b>API Reseller Error Alert!</b>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    "👤 <b>User:</b> " + (d.first_name || "Unknown") + " (<code>" + d.user_id + "</code>)\n" +
    "📦 <b>Product:</b> <code>" + d.prod_name + "</code>\n" +
    "⏳ <b>Plan:</b> <code>" + d.plan_days + " Days</code>\n" +
    "💵 <b>Price Amount:</b> LKR " + Number(d.price).toFixed(2) + "\n" +
    "🚨 <b>Reason:</b> External Website API is down or connection timed out.";

  try { Api.sendMessage({ chat_id: adminId, text: adminAlertText, parse_mode: "HTML" }); } catch (alertErr) {}
}