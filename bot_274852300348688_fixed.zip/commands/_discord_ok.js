/**#command
name: /discord_ok
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Empty handler: receives the Discord webhook reply and does nothing
return;