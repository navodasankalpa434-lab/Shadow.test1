/**#command
name: /toggle_maintenance
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 🛠 ADMIN/CO-ADMIN — Toggle Maintenance Mode
// ON: regular users see a premium "Under Maintenance" screen instead of the bot.
// OFF: next time each user hits /start, they get a one-time premium
// "Maintenance Removed — Bot is Back!" welcome with /start + Buy Now buttons.
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "8500341403";
  var currentChatId = String(chat.chatid);
  var isCoAdmin = isCoAdminId(currentChatId);

  if (currentChatId !== ownerId && !isCoAdmin) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  var current = Bot.getProperty("maintenance_mode") || false;
  var newState = !current;
  Bot.setProperty("maintenance_mode", newState, "boolean");

  if (newState) {
    Bot.sendMessage(
      "<blockquote><tg-emoji emoji-id='6100657257605763582'>🛠</tg-emoji> <b>MAINTENANCE MODE ENABLED</b></blockquote>\n\n" +
      "<i>Regular users can no longer use the bot — they will see the premium maintenance screen. You and co-admins keep working normally rahenge.</i>",
      { parse_mode: "HTML" }
    );
  } else {
    Bot.setProperty("maintenance_removed_at", Date.now(), "number");
    Bot.sendMessage(
      "<blockquote><tg-emoji emoji-id='6102856637343600044'>✅</tg-emoji> <b>MAINTENANCE MODE DISABLED</b></blockquote>\n\n" +
      "<i>The bot is live again! The next time users send /start, they will see a premium 'We're Back!' welcome.</i>",
      { parse_mode: "HTML" }
    );
  }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}