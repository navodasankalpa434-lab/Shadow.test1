/**#command
name: /discord_test
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Owner: send a test alert to Discord and report whether Discord accepted it
try {
  if (String(chat.chatid) !== "8500341403") { Bot.sendMessage("❌ Only the owner can run this."); return; }
  var tHook = String(Bot.getProperty("discord_webhook") || "");
  if (!tHook) { Bot.sendMessage("❌ No Discord webhook is set. Send: <code>/settings discord WEBHOOK_URL</code>", { parse_mode: "HTML" }); return; }
  var tBody = JSON.stringify({ username: "Sales Bot", embeds: [{ title: "🧪 TEST ALERT", description: "If you can read this, Discord alerts are working.", color: 3447003 }] });
  HTTP.post({ url: tHook, body: tBody, headers: { "Content-Type": "application/json" },
              success: "/discord_test_ok", error: "/discord_test_fail" });
  Bot.sendMessage("⏳ Sending a test alert to Discord...", { parse_mode: "HTML" });
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}