/**#command
name: /reseller_upgrade
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 👑 "Reseller Upgrade" button — premium Join-as-Reseller screen
// =========================================================

try {
  var userId = String(user.telegramid);
  var chatId = chat.chatid;

  if (Bot.getProperty("is_reseller_" + userId)) {
    Bot.sendMessage("<blockquote>💎 <b>You are already a Reseller!</b></blockquote>", { parse_mode: "HTML" });
    return;
  }

  if (!Bot.getProperty("reseller_system_enabled")) {
    Bot.sendMessage("❌ The Reseller Upgrade system is not available right now.");
    return;
  }

  var price = Number(Bot.getProperty("reseller_upgrade_price") || 0);
  if (!price) {
    Bot.sendMessage("❌ The admin has not set the Reseller Upgrade price yet.");
    return;
  }

  var unifiedBal = (function () {
    var resBal = 0;
    try { resBal = Number(Libs.ResourcesLib.userRes("balance").value()) || 0; } catch (e) {}
    var bonusBal = Number(Bot.getProperty("balance" + userId) || 0);
    return resBal + bonusBal;
  })();

  var text =
    "<blockquote><tg-emoji emoji-id='6102856637343600044'>👑</tg-emoji> <b>JOIN AS A RESELLER</b></blockquote>\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n\n" +
    "<tg-emoji emoji-id='6312263493051489212'>💰</tg-emoji> <b>Upgrade Price:</b> LKR <code>" + price.toFixed(2) + "</code> <i>(one-time, permanent)</i>\n" +
    "<tg-emoji emoji-id='521095630692758910'>💳</tg-emoji> <b>Wallet Balance:</b> LKR <code>" + unifiedBal.toFixed(2) + "</code>\n\n" +
    "━━━━━━━━━━━━━━━━━━━━━\n" +
    "<b>🎁 Reseller Benefits:</b>\n" +
    "<tg-emoji emoji-id='6215386799133433653'>✔️</tg-emoji> Lower prices on every product & plan\n" +
    "<tg-emoji emoji-id='6215386799133433653'>✔️</tg-emoji> Priority order processing\n" +
    "<tg-emoji emoji-id='6215386799133433653'>✔️</tg-emoji> Access to reseller-only stock\n" +
    "<tg-emoji emoji-id='6215386799133433653'>✔️</tg-emoji> Permanent status — one upgrade, forever\n" +
    "━━━━━━━━━━━━━━━━━━━━━";

  var buttons = [];
  if (unifiedBal >= price) {
    buttons.push([{ text: "Confirm & Pay from Wallet", callback_data: "/confirm_reseller_upgrade", style: "success", icon_custom_emoji_id: "6102856637343600044" }]);
  } else {
    buttons.push([{ text: "Pay LKR " + (price - unifiedBal).toFixed(2) + " - contact admin", callback_data: "/confirm_reseller_upgrade", style: "success", icon_custom_emoji_id: "521095630692758910" }]);
  }
  buttons.push([{ text: "Cancel", callback_data: "/back", style: "danger", icon_custom_emoji_id: "5893163582194978381" }]);

  if (request && request.message) {
    Api.editMessageText({ chat_id: String(chatId), message_id: Number(request.message.message_id), text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  } else {
    Api.sendMessage({ chat_id: chatId, text: text, parse_mode: "HTML", reply_markup: JSON.stringify({ inline_keyboard: buttons }) });
  }

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}