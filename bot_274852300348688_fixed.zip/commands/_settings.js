/**#command
name: /settings
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Owner settings. Usage:
//   /settings                      show current settings and help
//   /settings photo LINK           set the menu banner (direct .jpg/.png link)
//   /settings photo show           send the current banner to you
//   /settings photo remove         remove the menu banner
try {
  var ownerChatId = "8500341403";
  if (String(chat.chatid) !== ownerChatId) {
    Bot.sendMessage("❌ Only the owner can change settings.");
    return;
  }

  var raw = (typeof message !== "undefined" && message) ? String(message).trim() : "";
  raw = raw.replace(/^\/settings\s*/i, "").trim();
  var parts = raw.split(/\s+/);
  var current = String(Bot.getProperty("menu_photo_url") || "");

  if (parts[0] === "photo" && parts[1] === "remove") {
    Bot.setProperty("menu_photo_url", "", "string");
    Bot.setProperty("menu_photo_file_id", "", "string");
    Bot.sendMessage("✅ <b>Menu photo removed.</b>\nThe start menu will now show text only.", { parse_mode: "HTML" });
    return;
  }

  if (parts[0] === "photo" && parts[1] === "show") {
    if (!current) {
      Bot.sendMessage("ℹ️ No menu photo is set. Use <code>/settings photo LINK</code>.", { parse_mode: "HTML" });
      return;
    }
    Api.sendPhoto({ chat_id: ownerChatId, photo: current, caption: "Current menu photo" });
    return;
  }

  if (parts[0] === "photo" && parts[1]) {
    var link = parts[1];
    if (!/^https?:\/\//i.test(link)) {
      Bot.sendMessage("❌ The link must start with https://", { parse_mode: "HTML" });
      return;
    }
    // Test the link first: only save it if Telegram can load it as a photo
    try {
      Api.sendPhoto({ chat_id: ownerChatId, photo: link, caption: "✅ New menu photo (test)" });
    } catch (testErr) {
      Bot.sendMessage("❌ Telegram could not load that link as a photo.\nUse a direct .jpg or .png link (not a Google Photos page).", { parse_mode: "HTML" });
      return;
    }
    Bot.setProperty("menu_photo_url", link, "string");
    Bot.sendMessage("✅ <b>Menu photo saved.</b>\nIt will show after customers verify and on /start.", { parse_mode: "HTML" });
    return;
  }

  if (parts[0] === "discord" && parts[1] === "image") {
    var dImg = raw.replace(/^discord\s+image\s*/i, "").trim();
    if (!/^https:\/\//i.test(dImg)) {
      Bot.sendMessage("❌ Send a direct https image link (ends in .jpg or .png).\nExample: <code>/settings discord image https://i.imgur.com/xxxx.jpg</code>", { parse_mode: "HTML" });
      return;
    }
    Bot.setProperty("discord_image", dImg, "string");
    Bot.sendMessage("✅ <b>Discord image saved.</b> It will show on sale alerts and the dashboard.", { parse_mode: "HTML" });
    return;
  }

  if (parts[0] === "discord") {
    var dUrl = raw.replace(/^discord\s*/i, "").trim();
    if (!dUrl) {
      Bot.sendMessage("🔔 <b>Discord sale alerts</b>\nSend: <code>/settings discord WEBHOOK_URL</code>\nTo turn off: <code>/settings discord off</code>", { parse_mode: "HTML" });
      return;
    }
    Bot.setProperty("discord_webhook", dUrl === "off" ? "" : dUrl, "string");
    Bot.sendMessage(dUrl === "off" ? "✅ Discord alerts turned off." : "✅ <b>Discord alerts saved.</b>", { parse_mode: "HTML" });
    return;
  }

  if (parts[0] === "tier") {
    var tiersNow = Bot.getProperty("topup_tiers") || [];
    if (typeof tiersNow === "string") { try { tiersNow = JSON.parse(tiersNow); } catch (e) { tiersNow = []; } }
    if (!Array.isArray(tiersNow)) { tiersNow = []; }
    if (parts[1] === "clear") {
      Bot.setProperty("topup_tiers", [], "json");
      Bot.sendMessage("✅ All rank levels removed.", { parse_mode: "HTML" });
      return;
    }
    var tierM = raw.match(/^tier\s+([0-9.]+)\s+([0-9.]+)\s+(.+)$/i);
    if (!tierM) {
      var shown = tiersNow.length ? tiersNow.map(function (x) { return "• Top-up " + x.min + "+ → " + x.pct + "% off (" + x.name + ")"; }).join("\n") : "None yet";
      Bot.sendMessage("🏅 <b>Rank levels</b>\n" + shown + "\n\nAdd: <code>/settings tier TOPUP_TOTAL PERCENT NAME</code>\nExample: <code>/settings tier 10000 5 Gold</code>\nClear: <code>/settings tier clear</code>", { parse_mode: "HTML" });
      return;
    }
    tiersNow.push({ min: Number(tierM[1]), pct: Number(tierM[2]), name: tierM[3].trim() });
    tiersNow.sort(function (x, y) { return x.min - y.min; });
    Bot.setProperty("topup_tiers", tiersNow, "json");
    Bot.sendMessage("✅ Rank level saved: <b>" + tierM[3].trim() + "</b> at LKR " + tierM[1] + " top-up = " + tierM[2] + "% off", { parse_mode: "HTML" });
    return;
  }

  if (parts[0] === "bank") {
    var bankRaw = raw.replace(/^bank\s*/i, "").trim();
    var bankParts = bankRaw.split("|").map(function (x) { return x.trim(); });
    if (bankParts.length < 3 || !bankParts[0] || !bankParts[1] || !bankParts[2]) {
      Bot.sendMessage("❌ Use this format:\n<code>/settings bank BANK NAME | ACCOUNT NUMBER | ACCOUNT NAME</code>\n\nExample:\n<code>/settings bank Commercial Bank | 1234567890 | John Silva</code>", { parse_mode: "HTML" });
      return;
    }
    Bot.setProperty("topup_bank_name", bankParts[0], "string");
    Bot.setProperty("topup_bank_acc", bankParts[1], "string");
    Bot.setProperty("topup_bank_holder", bankParts[2], "string");
    Bot.sendMessage("✅ <b>Bank details saved.</b>", { parse_mode: "HTML" });
    return;
  }

  if (parts[0] === "ezcash") {
    var ezRaw = raw.replace(/^ezcash\s*/i, "").trim();
    if (!ezRaw) {
      Bot.sendMessage("❌ Use this format:\n<code>/settings ezcash PHONE NUMBER</code>\n\nExample:\n<code>/settings ezcash 07XXXXXXXX</code>", { parse_mode: "HTML" });
      return;
    }
    Bot.setProperty("topup_ezcash", ezRaw, "string");
    Bot.sendMessage("✅ <b>EZ Cash number saved.</b>", { parse_mode: "HTML" });
    return;
  }

  Bot.sendMessage(
    "⚙️ <b>Settings</b>\n\n" +
    "<b>Menu photo:</b> " + (current ? "set" : "not set") + "\n\n" +
    "<code>/settings photo LINK</code> - set the photo\n" +
    "<code>/settings photo show</code> - show current photo\n" +
    "<code>/settings photo remove</code> - remove the photo\n" +
    "<code>/settings bank NAME | ACCOUNT NO | ACCOUNT NAME</code> - set bank\n" +
    "<code>/settings ezcash PHONE</code> - set EZ Cash number\n" +
    "<code>/settings tier TOPUP PERCENT NAME</code> - rank discount",
    { parse_mode: "HTML" }
  );
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}