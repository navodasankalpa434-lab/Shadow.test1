/**#command
name: /pause_coupon
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var ownerId = Bot.getProperty("owner_id") || "8500341403";
  var isCoAdmin = isCoAdminId(String(chat.chatid));
  if (String(chat.chatid) !== ownerId && !isCoAdmin) { return; }

  var code = params ? String(params).trim().toUpperCase() : "";
  var c = Bot.getProperty("coupon_" + code);
  if (!c) {
    Bot.sendMessage("❌ Coupon not found.");
    return;
  }

  c.isPaused = !c.isPaused;
  Bot.setProperty("coupon_" + code, c, "json");

  Bot.sendMessage("✅ Coupon <code>" + code + "</code> now " + (c.isPaused ? "⏸ Paused" : "✅ Active") + ".", { parse_mode: "HTML" });

  Bot.run({ command: "/coupons" });

  var queryId = request ? (request.id || (request.callback_query && request.callback_query.id)) : null;
  if (queryId) { try { Api.answerCallbackQuery({ callback_query_id: String(queryId) }); } catch (e) {} }

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}