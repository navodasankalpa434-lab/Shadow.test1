/**#command
name: /co_admin
answer: 
keyboard: 
parse_mode: markdown
aliases: /co-admin
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin admin panel: opens the reduced admin panel for co-admins only
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var coChatId = String(chat.chatid);
  if (coChatId !== "8500341403" && !isCoAdminId(coChatId)) {
    Bot.sendMessage("❌ This command is only for co-admins.");
    return;
  }
  Bot.run({ command: "/admin" });
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}