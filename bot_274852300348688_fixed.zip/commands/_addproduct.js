/**#command
name: /addproduct
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// Add a product by NAME only:  /addproduct PRODUCT NAME
try {
  var callerId = String(chat.chatid);
  if (!isCoAdminId(callerId)) { Bot.sendMessage("❌ Only the owner and co-admins can add products."); return; }

  var rawName = (typeof message !== "undefined" && message) ? String(message).trim() : "";
  var prodName = rawName.replace(/^\/addproduct\s*/i, "").trim();
  var prodParts = prodName.split("|").map(function (x) { return x.trim(); });
  prodName = prodParts[0];
  var prodEmoji = (prodParts[1] && /^[0-9]+$/.test(prodParts[1])) ? prodParts[1] : "5226656353744862682";
  var prodPid = prodParts[2] ? prodParts[2] : "";

  if (!prodName) {
    Bot.sendMessage("📦 <b>Add a product</b>\n\nSend: <code>/addproduct PRODUCT NAME</code>\nExample: <code>/addproduct Shadow</code>\n\nThen add plans with <code>/addplan</code>.", { parse_mode: "HTML" });
    return;
  }

  var products = Bot.getProperty("stored_products") || [];
  if (typeof products === "string") { try { products = JSON.parse(products); } catch (e) { products = []; } }
  if (!Array.isArray(products)) { products = []; }

  for (var k = 0; k < products.length; k++) {
    if (products[k] && String(products[k].name).trim().toLowerCase() === prodName.toLowerCase()) {
      Bot.sendMessage("ℹ️ <b>" + prodName + "</b> already exists. Use <code>/addplan</code> to add plans to it.", { parse_mode: "HTML" });
      return;
    }
  }

  products.push({ name: prodName, emoji: prodEmoji, id: prodPid, plans: [] });
  Bot.setProperty("stored_products", products, "json");
  Bot.sendMessage("✅ <b>Product added:</b> " + prodName + "\n\nNext: <code>/addplan</code> to add its plans.", { parse_mode: "HTML" });
} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}