/**#command
name: /deletekey_now
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  var callbackId = request ? request.id : null;
  
  // Get the data from the callback params
  var dataStr = params ? params.trim() : "";
  if (!dataStr) return;

  var parts = dataStr.split("|");
  var keyIndex = Number(parts[0]);
  var prodName = parts[1];
  var cleanPlanDays = parts[2];

  var stockKeyText = "stock_" + prodName + "_" + cleanPlanDays;
  var keyStock = Bot.getProperty(stockKeyText) || [];

  if (keyStock.length === 0 || keyIndex >= keyStock.length) {
    if (callbackId) {
      Api.answerCallbackQuery({ callback_query_id: callbackId, text: "❌ Key already deleted or missing!", show_alert: true });
    }
    return;
  }

  // Delete the key from the array
  var removedKeyText = keyStock[keyIndex];
  keyStock.splice(keyIndex, 1);
  
  // Save the updated text stock
  Bot.setProperty(stockKeyText, keyStock, "json");

  // 🔄 INDEX BACKUP PIPELINE SYNC (For /buyitem sync)
  var productList = Bot.getProperty("stored_products") || [];
  var prodIdx = -1;
  var planIdx = -1;
  var pDaysNumOnly = cleanPlanDays.replace("_Day", "").trim();

  for (var i = 0; i < productList.length; i++) {
    if (productList[i].name.trim().toLowerCase() === prodName.toLowerCase()) {
      prodIdx = i;
      break;
    }
  }
  if (prodIdx !== -1) {
    var plans = productList[prodIdx].plans || [];
    for (var j = 0; j < plans.length; j++) {
      if (String(plans[j].days).trim() === pDaysNumOnly) {
        planIdx = j;
        break;
      }
    }
  }
  if (prodIdx !== -1 && planIdx !== -1) {
    var stockKeyIndex = "stock_" + prodIdx + "_" + planIdx;
    Bot.setProperty(stockKeyIndex, keyStock, "json");
  }

  // Final Response & UI update
  var successText = "<blockquote><b>🗑️ KEY SUCCESSFULLY REMOVED</b>\n\n" +
                    "• <b>Product:</b> <code>" + prodName + "</code>\n" +
                    "• <b>Plan:</b> <code>" + cleanPlanDays + "</code>\n" +
                    "• <b>Removed Key:</b> <code>" + removedKeyText + "</code>\n" +
                    "• <b>Remaining Stock:</b> <code>" + keyStock.length + " Keys</code></blockquote>";

  // Edit the message text to confirm
  if (request && request.message) {
    HTTP.post({
      url: "https://api.telegram.org/bot" + bot.token + "/editMessageText",
      body: {
        chat_id: String(chat.chatid),
        message_id: Number(request.message.message_id),
        text: successText,
        parse_mode: "HTML"
      }
    });
  }

  if (callbackId) {
    Api.answerCallbackQuery({ callback_query_id: callbackId, text: "✅ Key Removed!" });
  }

} catch (err) {
  Bot.sendMessage("Error: " + err.message);
}