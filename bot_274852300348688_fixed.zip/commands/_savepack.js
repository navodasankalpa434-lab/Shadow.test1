/**#command
name: /savepack
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// Command: /savepack
// Admin check (your ID is set directly)
if (String(user.telegramid) !== "8500341403" && !isCoAdminId(String(user.telegramid))) {
  Bot.sendMessage("❌ Only Admin can use this.");
  return;
}

Bot.sendMessage("📦 **Emoji Pack Registration**\n\nFirst, send a short name for your new pack (e.g., `pubg`, `buttons`):");

// Controller for sending in the next step
try { Bot.run({ command: "/onGetPackName" }); } catch (runErr) {}