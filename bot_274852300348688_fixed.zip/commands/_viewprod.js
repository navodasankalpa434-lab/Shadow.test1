/**#command
name: /viewprod
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Best membership-rank discount for a customer (used to show the shop price)
function rankPctFor(id) {
  var total = Number(Bot.getProperty("topup_total_" + id) || 0);
  var tiers = Bot.getProperty("topup_tiers") || [];
  if (typeof tiers === "string") { try { tiers = JSON.parse(tiers); } catch (e) { tiers = []; } }
  var pct = 0;
  if (Array.isArray(tiers)) { for (var t = 0; t < tiers.length; t++) { if (total >= Number(tiers[t].min) && Number(tiers[t].pct) > pct) { pct = Number(tiers[t].pct); } } }
  return pct;
}
// 🔐 VERIFY GATE: customers must verify their phone (/start) before using the shop
function isVerifiedCustomer(id) {
  var v = Bot.getProperty("verified_" + id);
  if (v === true || String(v) === "true") return true;
  var u = User.getProperty("verified_" + id);
  return u === true || String(u) === "true";
}
var gateId = String((typeof user !== "undefined" && user && user.telegramid) ? user.telegramid : chat.chatid);
if (gateId !== "8500341403" && !isVerifiedCustomer(gateId)) {
  Api.sendMessage({
    chat_id: gateId,
    text: "<blockquote><b>🔰 Please verify your account first.</b>\nTap /start, then press <b>Verify Account</b>.</blockquote>",
    parse_mode: "HTML"
  });
  return;
}

function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 📦 Shows a product's plans (Step 2 of the buy flow)
// ✅ CRITICAL BUG FIX: previously "<tg-emoji emoji-id='X'></tg-emoji>" was an EMPTY
// tag (with no fallback character) — Telegram's HTML parser rejects
// the WHOLE MESSAGE on such a malformed tg-emoji tag. That is why
// clicking a product never showed the plan-list screen
// and the whole buy flow broke right there!
// ✅ Photo-message-edit bug also fixed, and the missing else-branch (fresh send) was added
// as well.
// =========================================================

try {
  var productList = Bot.getProperty("stored_products") || [];
  var callbackId = request ? request.id : null;
  var chatId = chat.chatid;
  var messageId = request && request.message ? request.message.message_id : (request ? request.message_id : null);
  var isPhotoMsg = !!(request && request.message && request.message.photo);

  var userId = user.telegramid;
  var isReseller = Bot.getProperty("is_reseller_" + userId) === true;

  var productIndex = params ? params.trim() : "";
  if (productIndex === "") {
    var cbData = request && request.callback_query ? request.callback_query.data : "";
    productIndex = cbData.replace("/viewprod ", "").replace("viewprod ", "");
  }

  var selectedProduct = productList[Number(productIndex)];

  if (!selectedProduct) {
    if (callbackId) {
      try { Api.answerCallbackQuery({ callback_query_id: String(callbackId), text: "⚠️ Product not found!", show_alert: true }); } catch (e) {}
    }
    return;
  }

  var planButtons = [];
  var plans = selectedProduct.plans || [];

  if (plans.length === 0) { Api.sendMessage({ chat_id: chat.chatid, text: "<blockquote>📭 <b>No plans yet for this product.</b></blockquote>", parse_mode: "HTML" }); return; }

  for (var j = 0; j < plans.length; j++) {
    var plan = plans[j];
    var planUnit = plan.unit || "day";

    var cleanProdName = selectedProduct.name.trim().toUpperCase();
    var cleanPlanDays = String(plan.days).replace(/[^0-9.]/g, "").trim();

    var priceKeySuffix = (planUnit === "day") ? cleanPlanDays : (cleanPlanDays + "_" + planUnit);
    var normalKey = "price_normal_" + cleanProdName + "_" + priceKeySuffix;
    var resellerKey = "price_reseller_" + cleanProdName + "_" + priceKeySuffix;

    var adminNormalPrice = Bot.getProperty(normalKey);
    var adminResellerPrice = Bot.getProperty(resellerKey);

    var currentNormal = (plan.normal_price !== undefined && plan.normal_price !== null) ? plan.normal_price : adminNormalPrice;
    var currentReseller = (plan.reseller_price !== undefined && plan.reseller_price !== null) ? plan.reseller_price : adminResellerPrice;

    var displayPrice = isReseller ? currentReseller : currentNormal;
    var shownPct = Math.max(rankPctFor(userId), Number(Bot.getProperty("auto_discount_" + cleanProdName + "_" + cleanPlanDays + "_" + planUnit.toUpperCase()) || Bot.getProperty("auto_discount_" + cleanProdName + "_ALL") || Bot.getProperty("auto_discount_global") || 0));
    if (shownPct > 0) { displayPrice = Math.round(Number(displayPrice) * (100 - shownPct)) / 100; }
    var unitLabelWord = (planUnit === "hour") ? (Number(cleanPlanDays) === 1 ? "Hour" : "Hours") :
                         (planUnit === "minute") ? (Number(cleanPlanDays) === 1 ? "Minute" : "Minutes") :
                         (Number(cleanPlanDays) === 1 ? "Day" : "Days");
    var dayLabel = plan.durationDisplay || (cleanPlanDays + " " + unitLabelWord);

    // 🎉 Discount badge preview (auto-discount only, coupon shown later on confirm screen)
    var discPreviewKey1 = "auto_discount_" + cleanProdName + "_" + cleanPlanDays + "_" + planUnit.toUpperCase();
    var discPreviewKey2 = "auto_discount_" + cleanProdName + "_ALL";
    var discPreview = Bot.getProperty(discPreviewKey1) || Bot.getProperty(discPreviewKey2) || Bot.getProperty("auto_discount_global") || 0;
    var badgeText = discPreview > 0 ? " 🎉-" + discPreview + "%" : "";

    planButtons.push([
      {
        text: dayLabel + " — LKR " + displayPrice + badgeText,
        callback_data: "/buyitem " + productIndex + " " + j,
        style: "primary",
        icon_custom_emoji_id: "6100657257605763582"
      }
    ]);
  }

  planButtons.push([
    {
      text: "Back to Shop",
      callback_data: "/buy_hack",
      style: "danger",
      icon_custom_emoji_id: "5893163582194978381"
    }
  ]);

  // ✅ FIX: removed the empty tg-emoji tag — now it is only the plain product emoji text
  var planText =
    "<blockquote><tg-emoji emoji-id='6102856637343600044'>👑</tg-emoji> <b>PRODUCT: " + selectedProduct.name.toUpperCase() + "</b></blockquote>\n\n" +
    "<tg-emoji emoji-id='6093677128295914531'>✏️</tg-emoji> <b>CHOOSE YOUR PLAN</b> <tg-emoji emoji-id='6093677128295914531'>✏️</tg-emoji>\n\n" +
    "<blockquote><tg-emoji emoji-id='6093854128193152827'>🎉</tg-emoji> Select your validity plan below to proceed with the secure order <tg-emoji emoji-id='6091571559233755994'>👉</tg-emoji></blockquote>";

  var replyMarkupStr = JSON.stringify({ inline_keyboard: planButtons });

  if (messageId) {
    if (isPhotoMsg) {
      try { Api.deleteMessage({ chat_id: chatId, message_id: messageId }); } catch (e) {}
      Api.sendMessage({ chat_id: chatId, text: planText, parse_mode: "HTML", reply_markup: replyMarkupStr });
    } else {
      Api.editMessageText({
        chat_id: chatId,
        message_id: Number(messageId),
        text: planText,
        parse_mode: "HTML",
        reply_markup: replyMarkupStr
      });
    }
  } else {
    // ✅ FIX: previously nothing was sent in this case
    Api.sendMessage({ chat_id: chatId, text: planText, parse_mode: "HTML", reply_markup: replyMarkupStr });
  }

  if (callbackId) {
    try { Api.answerCallbackQuery({ callback_query_id: String(callbackId) }); } catch (e) {}
  }

} catch (err) {
  Bot.sendMessage("⚠️ View Product Error: " + err.message, { parse_mode: "HTML" });
}