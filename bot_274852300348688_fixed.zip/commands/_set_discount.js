/**#command
name: /set_discount
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

// =========================================================
// 💸 ADMIN/CO-ADMIN — Auto-Discount System (no coupon code needed)
// Usage:
//   /set_discount global | 10                        → 10% off EVERYTHING
//   /set_discount PRODUCT NAME | all | 15             → 15% off entire product (all plans)
//   /set_discount PRODUCT NAME | 1d | 20               → 20% off just that one plan
//   /set_discount PRODUCT NAME | 1d | remove           → removes that specific discount
// Most SPECIFIC discount wins (plan > product > global). If the user also
// applies a coupon, the coupon takes priority over an auto-discount.
// =========================================================

try {
  var ownerId = Bot.getProperty("owner_id") || "8500341403";
  var isCoAdmin = isCoAdminId(String(chat.chatid));
  if (String(chat.chatid) !== ownerId && !isCoAdmin) {
    Bot.sendMessage("❌ Restricted command!");
    return;
  }

  if (!params || params.trim() === "") {
    Bot.sendMessage(
      "⚠️ <b>Format:</b>\n" +
      "<code>/set_discount global | 10</code>  (for all products, 10%)\n" +
      "<code>/set_discount PRODUCT NAME | all | 15</code>  (for the whole product)\n" +
      "<code>/set_discount PRODUCT NAME | 1d | 20</code>  (only the 1 Day plan)\n" +
      "<code>/set_discount PRODUCT NAME | 1d | remove</code>  (remove it)",
      { parse_mode: "HTML" }
    );
    return;
  }

  var parts = params.split("|").map(function (p) { return p.trim(); });

  if (parts[0].toLowerCase() === "global") {
    var pct = parts[1];
    if (!pct || pct.toLowerCase() === "remove") {
      Bot.setProperty("auto_discount_global", null, "number");
      Bot.sendMessage("✅ Global discount removed.", { parse_mode: "HTML" });
      return;
    }
    var pctVal = parseFloat(pct);
    if (isNaN(pctVal) || pctVal <= 0 || pctVal > 100) { Bot.sendMessage("❌ A valid % is required (1-100)."); return; }
    Bot.setProperty("auto_discount_global", pctVal, "number");
    Bot.sendMessage("✅ <b>Global Discount set:</b> -" + pctVal + "% (applies to all products/plans)", { parse_mode: "HTML" });
    return;
  }

  if (parts.length < 3) {
    Bot.sendMessage("⚠️ Format: <code>/set_discount PRODUCT NAME | DURATION | PERCENT</code>", { parse_mode: "HTML" });
    return;
  }

  var prodNameUpper = parts[0].toUpperCase();
  var scopeKey;
  if (parts[1].toLowerCase() === "all") {
    scopeKey = "ALL";
  } else {
    var durMatch = parts[1].toLowerCase().match(/^([0-9]+(?:\.[0-9]+)?)\s*(h|hr|hrs|hour|hours|m|min|mins|minute|minutes|d|day|days)?$/);
    var dVal = durMatch ? durMatch[1] : parts[1].replace(/[^0-9.]/g, "");
    var uRaw = durMatch ? (durMatch[2] || "d") : "d";
    var uNorm = /^h/.test(uRaw) ? "HOUR" : /^m/.test(uRaw) ? "MINUTE" : "DAY";
    scopeKey = dVal + "_" + uNorm;
  }
  var pctOrRemove = parts[2];

  var propKey = "auto_discount_" + prodNameUpper + "_" + scopeKey;

  if (pctOrRemove.toLowerCase() === "remove") {
    Bot.setProperty(propKey, null, "number");
    Bot.sendMessage("✅ Discount removed: <code>" + parts[0] + " (" + parts[1] + ")</code>", { parse_mode: "HTML" });
    return;
  }

  var pctVal2 = parseFloat(pctOrRemove);
  if (isNaN(pctVal2) || pctVal2 <= 0 || pctVal2 > 100) { Bot.sendMessage("❌ A valid % is required (1-100)."); return; }

  Bot.setProperty(propKey, pctVal2, "number");
  Bot.sendMessage(
    "<blockquote>✅ <b>Discount Set!</b></blockquote>\n\n" +
    "📦 <b>Product:</b> " + parts[0] + "\n" +
    "⏳ <b>Scope:</b> " + (scopeKey === "ALL" ? "Entire Product (all plans)" : parts[1]) + "\n" +
    "💸 <b>Discount:</b> -" + pctVal2 + "%",
    { parse_mode: "HTML" }
  );

} catch (err) {
  Bot.sendMessage("⚠️ Error: " + err.message);
}