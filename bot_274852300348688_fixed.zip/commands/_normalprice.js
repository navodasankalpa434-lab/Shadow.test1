/**#command
name: /normalprice
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: false
case_insensitive: false
is_web: 0
#command**/

// Update a plan's price inside the product list (used by the price-change commands)
function updatePlanPrice(prodName, planName, kind, price) {
  var list = Bot.getProperty("stored_products") || [];
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  if (!Array.isArray(list)) { return false; }
  var pn = String(prodName).trim().toLowerCase();
  var plainPlan = String(planName).trim().toLowerCase();
  var plannum = String(planName).replace(/[^0-9.]/g, "");
  for (var i = 0; i < list.length; i++) {
    if (!list[i] || String(list[i].name).trim().toLowerCase() !== pn) { continue; }
    var plans = Array.isArray(list[i].plans) ? list[i].plans : [];
    for (var j = 0; j < plans.length; j++) {
      var pl = plans[j];
      var label = String(pl.durationDisplay || "").trim().toLowerCase();
      var days = String(pl.days).replace(/[^0-9.]/g, "");
      if (label === plainPlan || (plannum !== "" && days === plannum)) {
        if (kind === "normal") { pl.normal_price = Number(price); } else { pl.reseller_price = Number(price); }
        Bot.setProperty("stored_products", list, "json");
        return true;
      }
    }
  }
  return false;
}

// Co-admin check: true if the ID is flagged as co-admin OR is in the co_admin_list
function isCoAdminId(id) {
  id = String(id);
  // OWNER = 8500341403. PERMANENT CO-ADMINS: add new co-admin chat IDs to this list.
  var STAFF_IDS = ["8500341403", "8865419308"];
  if (STAFF_IDS.indexOf(id) !== -1) return true;
  if (String(Bot.getProperty("co_admin_" + id)) === "true") return true;
  var list = Bot.getProperty("co_admin_list");
  if (typeof list === "string") { try { list = JSON.parse(list); } catch (e) { list = []; } }
  return Array.isArray(list) && list.map(String).indexOf(id) !== -1;
}

try {
  var adminId = "8500341403";
  if (String(chat.chatid) !== adminId && !isCoAdminId(String(chat.chatid))) return;

  // Expected Format: pubg_mobile | 1_Day | 120
  if (!params) {
    Bot.sendMessage("❌ <b>Usage:</b>\n<code>/normalprice product_name | days | price</code>\n\n<i>Example: pubg_mobile | 1_Day | 120</i>", { parse_mode: "HTML" });
    return;
  }

  // Split the text by the pipe '|' symbol
  var args = params.split("|");

  if (args.length < 3) {
    Bot.sendMessage("❌ <b>Incorrect Format!</b> Use Pipe symbol:\n<code>/setnormalprice product_name | days | price</code>", { parse_mode: "HTML" });
    return;
  }

  // Remove spaces using trim()
  var prodName = args[0].trim();
  var planName = args[1].trim();
  var price = args[2].trim();

  if (!prodName || !planName || !price || isNaN(price)) {
    Bot.sendMessage("❌ Invalid price number or structure. Double check inputs!", { parse_mode: "HTML" });
    return;
  }

  if (!updatePlanPrice(prodName, planName, "normal", price)) {
    Bot.sendMessage("❌ Plan not found. Use the product name and the plan label exactly, for example: <code>/normalprice Shadow 1 Day 500</code>", { parse_mode: "HTML" });
    return;
  }
  // Save to the standard database configurations
  Bot.setProperty("price_normal_" + prodName + "_" + planName, Number(price), "float");

  var successText = "<blockquote><b><tg-emoji emoji-id='6064514463564831610'>💟</tg-emoji> NORMAL PRICE UPDATED</b>\n\n" +
                    "• <b>Product:</b> <code>" + prodName + "</code>\n" +
                    "• <b>Validity/Days:</b> <code>" + planName + "</code>\n" +
                    "• <b>New Price:</b> <code>LKR " + Number(price).toFixed(2) + "</code></blockquote>";

  Bot.sendMessage(successText, { parse_mode: "HTML" });

} catch (err) { 
  Bot.sendMessage("Error: " + err.message); 
}