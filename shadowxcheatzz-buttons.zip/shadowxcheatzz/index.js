import * as baileys from 'baileys';
import { Boom } from '@hapi/boom';
import pino from 'pino';
import { config } from './lib/config.js';
import { connectDB } from './lib/db.js';
import { useMongoAuthState } from './lib/mongoAuth.js';
import { handleMessage, startExpiryReminder } from './lib/handler.js';
import { toJid, sentIds, rememberSent } from './lib/helpers.js';
import { startWeb } from './lib/web.js';

const makeWASocket = baileys.makeWASocket || baileys.default;
const { DisconnectReason, fetchLatestBaileysVersion, Browsers, makeCacheableSignalKeyStore } = baileys;

const logger = pino({ level: process.env.LOG_LEVEL || 'silent' });

let sock = null;
let reminderStarted = false;
const processed = new Set(); // message IDs already handled (avoids double replies)

async function start() {
  const { state, saveCreds, clear } = await useMongoAuthState();
  const { version } = await fetchLatestBaileysVersion().catch(() => ({ version: undefined }));

  sock = makeWASocket({
    version,
    logger,
    browser: Browsers.macOS('Chrome'),
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    markOnlineOnConnect: false,
    syncFullHistory: false,
    generateHighQualityLinkPreview: false,
  });

  // Remember IDs of messages the bot sends
  const originalSend = sock.sendMessage.bind(sock);
  sock.sendMessage = async (...a) => {
    const r = await originalSend(...a);
    rememberSent(r?.key?.id);
    return r;
  };

  // ---------- Pairing code login ----------
  if (!state.creds.registered) {
    if (!config.BOT_NUMBER) {
      console.log('Not linked yet. Open the app URL in your browser to get a pairing code.');
    } else {
      setTimeout(async () => {
        try {
          const code = await sock.requestPairingCode(config.BOT_NUMBER);
          console.log('\n==============================');
          console.log(`  PAIRING CODE: ${code?.match(/.{1,4}/g)?.join('-') || code}`);
          console.log('==============================');
          console.log('WhatsApp > Linked devices > Link a device > Link with phone number instead\n');
        } catch (e) {
          console.error('Could not get pairing code:', e.message);
        }
      }, 4000);
    }
  }

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      console.log(`✅ ${config.BOT_NAME} connected as ${sock.user?.id}`);
      if (!reminderStarted) {
        startExpiryReminder(() => sock);
        reminderStarted = true;
      }
      for (const o of config.OWNER_NUMBERS) {
        sock.sendMessage(toJid(o), { text: `✅ *${config.BOT_NAME}* is online.\nType *${config.PREFIX}admin* for the admin panel.` }).catch(() => {});
      }
    }
    if (connection === 'close') {
      const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
      console.log('Connection closed. Reason code:', code);
      if (code === DisconnectReason.loggedOut) {
        console.log('Logged out. Clearing session – restart the bot and pair again.');
        await clear();
        process.exit(1);
      }
      setTimeout(start, 3000);
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    for (const m of messages) {
      try {
        if (!m.message || m.key.remoteJid === 'status@broadcast') continue;
        // Skip messages the bot itself sent (Baileys message IDs start with 3EB0)
        if (m.key.fromMe && (sentIds.has(m.key.id) || m.key.id?.startsWith('3EB0'))) continue;
        // Messages typed on the bot's own phone (e.g. the "You" chat) can arrive as
        // type "append". Accept those only if they are fresh, so old history is ignored.
        if (type !== 'notify') {
          const ts = Number(m.messageTimestamp || 0) * 1000;
          if (!m.key.fromMe || Date.now() - ts > 60000) continue;
        }
        if (processed.has(m.key.id)) continue;
        processed.add(m.key.id);
        if (processed.size > 2000) processed.delete(processed.values().next().value);
        await handleMessage(sock, m);
      } catch (e) {
        console.error('Message handler error:', e);
      }
    }
  });
}

process.on('unhandledRejection', (e) => console.error('Unhandled rejection:', e));
process.on('uncaughtException', (e) => console.error('Uncaught exception:', e));

await connectDB(config.MONGODB_URI);
startWeb(() => sock);
await start();
