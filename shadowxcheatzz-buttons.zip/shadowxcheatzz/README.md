# ShadowXcheatZz – WhatsApp Panel Reseller Bot

Baileys v7 + Node.js 20 + MongoDB. Session is stored in MongoDB, so it survives Heroku/Kurox restarts.

## Features
- **Buttons + number menus**: tap a button or reply with a number. Send *hi* or *menu* to start
- **Step-by-step guides**: send any admin command without details (e.g. `.addplan`) and the bot asks for each value
- **One-tap approve/reject** on payment slips
- Shop with products and plans (**any number of days**, any price)
- Key stock per plan, auto key delivery after purchase, low-stock alerts
- Wallet system: users pay from their wallet
- Top-up with payment slip → admin **approves** → payment verified and wallet credited automatically
- Owner/admin can add, deduct and check wallet balance of any user
- Extend or reduce days on any order
- Logo on menus and orders; admins can change it with `.setlogo`
- Expiry reminders 24h before a key expires
- Sales stats, user info, ban/unban, broadcast, multiple admins

## Setup (Heroku / Kurox)
1. Push this folder to a private GitHub repo.
2. Create the app and add **Config Vars** from `.env.example` (at least `OWNER_NUMBER`, `MONGODB_URI`, `PAIR_PASSWORD`).
3. Deploy and turn on the **web** dyno (`Procfile`: `web: node index.js`).
4. Open the app URL (e.g. `https://your-app.herokuapp.com`) → enter the bot number and password → **GET PAIR CODE**.
5. On the bot's phone: WhatsApp → Linked devices → Link a device → *Link with phone number instead* → enter the code.
6. When the bot says it is online, send `.admin`.

## First things to do (as owner)
```
.setpay
Bank: ...
Name: ...
Account: ...
eZ Cash: ...

.addproduct Drip Client | Safe Android panel
.addplan Drip Client | 12 | 600
.addkey P1
KEY-AAAA-1111
KEY-BBBB-2222
```

## User commands
| Command | What it does |
|---|---|
| `.menu` | Main menu with logo |
| `.shop` | Products, plans, prices, stock |
| `.buy P1` | Buy plan P1 from wallet |
| `.mykeys` | Your keys and days left |
| `.wallet` | Balance and history |
| `.pay` | Payment details |
| `.topup 1000` | Send with slip image (caption) or reply to slip |
| `.mytopups` | Your top-up requests |

## Admin commands
| Command | What it does |
|---|---|
| `.admin` | Admin panel |
| `.addproduct name \| desc` / `.delproduct name` | Products |
| `.addplan product \| days \| price` | New plan, any days |
| `.editplan P1 \| days \| price` / `.delplan P1` | Change/remove plan |
| `.addkey P1` + keys on new lines | Add stock |
| `.stock` / `.stock P1` / `.delkey P1 KEY` | Stock |
| `.pending` | Pending top-ups |
| `.approve T1001` / `.approve T1001 900` | Verify payment and credit wallet |
| `.reject T1001 reason` | Reject payment |
| `.addbal 9477xxxxxxx 1000` | Add money to wallet |
| `.deductbal 9477xxxxxxx 500` | Remove money |
| `.checkbal 9477xxxxxxx` | Check balance |
| `.extend O1001 5` / `.extend O1001 -2` | Add/remove days on an order |
| `.orders` / `.orders 9477xxxxxxx` | Orders |
| `.userinfo` `.ban` `.unban` `.users` `.stats` | Users and stats |
| `.broadcast message` | Message all users |
| `.setlogo` (with/reply image) / `.resetlogo` | Logo |
| `.buttons on` / `.buttons off` | Turn buttons off if users can't see them (numbers still work) |
| `.addadmin` `.deladmin` `.admins` | Admins (owner only) |
